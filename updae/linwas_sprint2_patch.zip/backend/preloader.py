"""Startup/live data preloader for linwas.

Policy:
- Fast live data refreshes every 2s from UI timer.
- Medium data is collected once at app startup.
- Heavy scans are user-triggered only.
"""
from __future__ import annotations

import threading
from PySide6.QtCore import QObject, Signal

from ui.components.worker import run_in_thread


class DataPreloader(QObject):
    data_ready = Signal(str, object)  # key, data

    _instance = None
    _instance_lock = threading.Lock()

    @classmethod
    def instance(cls) -> "DataPreloader":
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls()
        return cls._instance

    def __init__(self):
        super().__init__()
        self._cache: dict = {}
        self._cache_lock = threading.Lock()
        self._started = False

    def start(self):
        if self._started:
            return
        self._started = True

        from services.system_service import SystemService
        from services.gpu_service import GPUService
        from services.network_service import NetworkService
        from services.security_service import SecurityService

        sys_s = SystemService()
        gpu_s = GPUService()
        net_s = NetworkService()
        sec_s = SecurityService()

        def startup_collect():
            system_startup = sys_s.get_startup()
            gpu_startup = gpu_s.get_startup()
            network_startup = net_s.get_startup()
            security_startup = sec_s.get_startup(system_startup.get("updates", {}).get("count", -1))
            return {
                "system_startup": system_startup,
                "gpu_startup": gpu_startup,
                "network_startup": network_startup,
                "security_startup": security_startup,
            }

        def on_startup(data: dict):
            for key, value in data.items():
                self._store(key, value)

        run_in_thread(startup_collect, on_done=on_startup, on_error=lambda e: self._store("preload_error", e))

    def refresh_live(self):
        from services.system_service import SystemService
        from services.gpu_service import GPUService
        from services.network_service import NetworkService

        sys_s = SystemService()
        gpu_s = GPUService()
        net_s = NetworkService()

        def live_collect():
            return {
                "live_system": sys_s.get_live(),
                "live_gpu": gpu_s.get_live(),
                "live_network": net_s.get_live(),
            }

        def on_live(data: dict):
            for key, value in data.items():
                self._store(key, value)

        run_in_thread(live_collect, on_done=on_live, on_error=lambda e: self._store("live_error", e))

    def _store(self, key: str, data):
        with self._cache_lock:
            self._cache[key] = data
        try:
            from core.app_state import APP_STATE
            APP_STATE.set(key, data)
        except Exception:
            pass
        self.data_ready.emit(key, data)

    def get(self, key, default=None):
        with self._cache_lock:
            return self._cache.get(key, default)

    def has(self, key) -> bool:
        with self._cache_lock:
            return key in self._cache
