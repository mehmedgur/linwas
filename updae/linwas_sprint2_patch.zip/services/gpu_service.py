"""GPU detection and driver/session checks for linwas Sprint 2."""
from __future__ import annotations

import os
import re
import shutil
import subprocess


class GPUService:
    def _run(self, cmd: list[str], timeout: int = 5) -> tuple[int, str, str]:
        try:
            env = os.environ.copy()
            env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env)
            return r.returncode, r.stdout, r.stderr
        except Exception as e:
            return 127, "", str(e)

    def detect_gpus(self) -> list[dict]:
        gpus: list[dict] = []
        if shutil.which("lspci"):
            code, out, err = self._run(["lspci", "-nnk"], timeout=6)
            blocks = re.split(r"\n(?=[0-9a-fA-F:.]+\s)", out)
            for block in blocks:
                first = block.splitlines()[0] if block.splitlines() else ""
                if any(x in first for x in ["VGA compatible controller", "3D controller", "Display controller"]):
                    vendor = self._vendor_from_text(block)
                    driver = self._active_driver_from_block(block)
                    gpus.append({
                        "name": first.split(":", 2)[-1].strip(),
                        "vendor": vendor,
                        "driver": driver,
                        "raw": block.strip(),
                    })
        if not gpus and shutil.which("nvidia-smi"):
            code, out, err = self._run(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"], timeout=4)
            for line in out.splitlines():
                if line.strip():
                    gpus.append({"name": line.strip(), "vendor": "nvidia", "driver": "nvidia", "raw": line.strip()})
        return gpus

    def _vendor_from_text(self, text: str) -> str:
        low = text.lower()
        if "nvidia" in low:
            return "nvidia"
        if "amd" in low or "advanced micro devices" in low or "ati" in low:
            return "amd"
        if "intel" in low:
            return "intel"
        return "unknown"

    def _active_driver_from_block(self, block: str) -> str:
        for line in block.splitlines():
            if "Kernel driver in use:" in line:
                return line.split(":", 1)[1].strip()
        return "bilinmiyor"

    def get_nvidia_live(self) -> dict:
        if not shutil.which("nvidia-smi"):
            return {"available": False}
        code, out, err = self._run([
            "nvidia-smi",
            "--query-gpu=utilization.gpu,temperature.gpu,memory.used,memory.total",
            "--format=csv,noheader,nounits",
        ], timeout=4)
        if code != 0 or not out.strip():
            return {"available": False, "error": err.strip()}
        parts = [p.strip() for p in out.splitlines()[0].split(",")]
        try:
            return {
                "available": True,
                "util_percent": float(parts[0]),
                "temperature_c": float(parts[1]),
                "vram_used_mb": float(parts[2]),
                "vram_total_mb": float(parts[3]),
            }
        except Exception:
            return {"available": False, "raw": out.strip()}

    def get_session(self) -> dict:
        session = os.environ.get("XDG_SESSION_TYPE", "bilinmiyor")
        return {
            "type": session,
            "human": "Wayland" if session == "wayland" else "X11" if session == "x11" else "Bilinmiyor",
            "note": self._session_note(session),
        }

    def _session_note(self, session: str) -> str:
        if session == "wayland":
            return "Wayland modern ve akıcıdır; bazı sürücü/ekran paylaşımı senaryolarında uyumluluk farkı olabilir."
        if session == "x11":
            return "X11 eski ama uyumluluğu yüksektir; bazı sistemlerde güç tüketimi ve akıcılık Wayland'a göre farklı olabilir."
        return "Oturum türü algılanamadı."

    def check_vulkan(self) -> dict:
        if not shutil.which("vulkaninfo"):
            return {"available": False, "message": "Vulkan aracı kurulu değil"}
        code, out, err = self._run(["vulkaninfo", "--summary"], timeout=8)
        return {"available": code == 0, "message": "Vulkan hazır" if code == 0 else "Vulkan kontrolünde sorun var", "raw": (out or err)[-3000:]}

    def check_opengl(self) -> dict:
        if not shutil.which("glxinfo"):
            return {"available": False, "message": "OpenGL aracı kurulu değil"}
        code, out, err = self._run(["glxinfo", "-B"], timeout=6)
        renderer = ""
        for line in out.splitlines():
            if "OpenGL renderer" in line:
                renderer = line.split(":", 1)[1].strip()
        return {"available": code == 0, "renderer": renderer, "message": "OpenGL çalışıyor" if code == 0 else "OpenGL kontrolünde sorun var", "raw": (out or err)[-3000:]}

    def detect_hybrid(self, gpus: list[dict] | None = None) -> dict:
        gpus = gpus if gpus is not None else self.detect_gpus()
        vendors = {g.get("vendor") for g in gpus}
        hybrid = len([v for v in vendors if v and v != "unknown"]) > 1 or len(gpus) > 1
        return {"hybrid": hybrid, "gpu_count": len(gpus), "vendors": sorted(vendors)}

    def get_startup(self) -> dict:
        gpus = self.detect_gpus()
        return {
            "gpus": gpus,
            "primary": gpus[0] if gpus else {"name": "Algılanamadı", "vendor": "unknown", "driver": "bilinmiyor"},
            "session": self.get_session(),
            "hybrid": self.detect_hybrid(gpus),
            "vulkan": self.check_vulkan(),
            "opengl": self.check_opengl(),
        }

    def get_live(self) -> dict:
        return {"nvidia": self.get_nvidia_live()}
