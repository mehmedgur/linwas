"""Network read-only service for linwas Sprint 2."""
from __future__ import annotations

import os
import shutil
import subprocess


class NetworkService:
    def _run(self, cmd: list[str], timeout: int = 6) -> tuple[int, str, str]:
        try:
            env = os.environ.copy()
            env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env)
            return r.returncode, r.stdout, r.stderr
        except Exception as e:
            return 127, "", str(e)

    def list_connections(self) -> list[dict]:
        if not shutil.which("nmcli"):
            return []
        code, out, err = self._run(["nmcli", "-t", "-f", "NAME,TYPE,STATE,DEVICE", "connection", "show", "--active"])
        results = []
        for line in out.splitlines():
            parts = line.split(":")
            if len(parts) >= 4:
                results.append({"name": parts[0], "type": parts[1], "state": parts[2], "device": parts[3]})
        return results

    def get_ip_info(self) -> dict:
        code, out, err = self._run(["ip", "-brief", "addr"])
        interfaces = {}
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 2 and parts[0] != "lo":
                interfaces[parts[0]] = {
                    "state": parts[1],
                    "ip": parts[2].split("/")[0] if len(parts) > 2 else "",
                }
        return interfaces

    def get_wifi_status(self) -> dict:
        if not shutil.which("nmcli"):
            return {"available": False, "connected": False, "message": "NetworkManager aracı bulunamadı"}
        code, out, err = self._run(["nmcli", "-t", "-f", "ACTIVE,SSID,SIGNAL,SECURITY", "dev", "wifi"], timeout=8)
        active = None
        networks = []
        for line in out.splitlines():
            parts = line.split(":")
            if len(parts) >= 4:
                item = {"active": parts[0].lower() == "yes", "ssid": parts[1], "signal": int(parts[2]) if parts[2].isdigit() else 0, "security": parts[3]}
                networks.append(item)
                if item["active"]:
                    active = item
        return {
            "available": True,
            "connected": active is not None,
            "active": active,
            "networks_count": len(networks),
            "message": f"{active['ssid']} ağına bağlı" if active else "Wi‑Fi bağlı değil",
        }

    def check_rfkill(self) -> dict:
        if not shutil.which("rfkill"):
            return {"available": False, "blocked": False, "raw": "rfkill yok"}
        code, out, err = self._run(["rfkill", "list"], timeout=5)
        raw = out or err
        blocked = "Soft blocked: yes" in raw or "Hard blocked: yes" in raw
        return {"available": True, "blocked": blocked, "raw": raw[-3000:]}

    def check_internet(self) -> dict:
        code, out, err = self._run(["ping", "-c", "1", "-W", "2", "8.8.8.8"], timeout=4)
        return {"connected": code == 0, "raw": (out or err)[-1500:]}

    def get_startup(self) -> dict:
        return {
            "connections": self.list_connections(),
            "interfaces": self.get_ip_info(),
            "wifi": self.get_wifi_status(),
            "rfkill": self.check_rfkill(),
        }

    def get_live(self) -> dict:
        return {"wifi": self.get_wifi_status(), "internet": self.check_internet()}
