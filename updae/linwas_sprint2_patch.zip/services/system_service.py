"""Lightweight system service for linwas Sprint 2.

This layer talks to local Linux/system APIs and returns raw-but-safe data.
UI/backend layers should convert this into human language.
"""
from __future__ import annotations

import platform
import subprocess
import time
from pathlib import Path

import psutil


class SystemService:
    def get_cpu(self) -> dict:
        try:
            percent = psutil.cpu_percent(interval=0.15)
            freq = psutil.cpu_freq()
            return {
                "percent": float(percent),
                "cores": psutil.cpu_count(logical=True) or 0,
                "name": self._cpu_name(),
                "freq_mhz": round(freq.current) if freq else 0,
            }
        except Exception:
            return {"percent": 0.0, "cores": 0, "name": "Bilinmiyor", "freq_mhz": 0}

    def _cpu_name(self) -> str:
        try:
            for line in Path("/proc/cpuinfo").read_text(errors="ignore").splitlines():
                if line.startswith("model name"):
                    return line.split(":", 1)[1].strip()
        except Exception:
            pass
        return platform.processor() or "Bilinmeyen CPU"

    def get_memory(self) -> dict:
        try:
            m = psutil.virtual_memory()
            return {
                "used_gb": round(m.used / 1024**3, 1),
                "total_gb": round(m.total / 1024**3, 1),
                "percent": float(m.percent),
            }
        except Exception:
            return {"used_gb": 0, "total_gb": 0, "percent": 0}

    def get_disk_root(self) -> dict:
        try:
            d = psutil.disk_usage("/")
            return {
                "used_gb": round(d.used / 1024**3, 1),
                "total_gb": round(d.total / 1024**3, 1),
                "percent": float(d.percent),
                "mountpoint": "/",
            }
        except Exception:
            return {"used_gb": 0, "total_gb": 0, "percent": 0, "mountpoint": "/"}

    def get_os(self) -> dict:
        data = {}
        try:
            for line in Path("/etc/os-release").read_text(errors="ignore").splitlines():
                if "=" in line:
                    k, v = line.split("=", 1)
                    data[k] = v.strip('"')
        except Exception:
            pass
        return {
            "name": data.get("PRETTY_NAME", platform.system()),
            "id": data.get("ID", "linux"),
            "version": data.get("VERSION_ID", ""),
            "kernel": platform.release(),
            "host": platform.node(),
            "session": self.get_session_type(),
        }

    def get_session_type(self) -> str:
        import os
        return os.environ.get("XDG_SESSION_TYPE", "bilinmiyor")

    def get_uptime(self) -> dict:
        try:
            secs = max(0, time.time() - psutil.boot_time())
            return {"hours": int(secs // 3600), "minutes": int((secs % 3600) // 60)}
        except Exception:
            return {"hours": 0, "minutes": 0}

    def check_internet(self) -> dict:
        try:
            r = subprocess.run(["ping", "-c", "1", "-W", "2", "8.8.8.8"], capture_output=True, text=True, timeout=4)
            return {"connected": r.returncode == 0, "method": "ping", "raw": r.stderr.strip() or r.stdout.strip()}
        except Exception as e:
            return {"connected": False, "method": "ping", "raw": str(e)}

    def get_updates_count(self) -> dict:
        # Medium-weight: run once at app start, not every 2 seconds.
        try:
            r = subprocess.run(["apt", "list", "--upgradable"], capture_output=True, text=True, timeout=20, env={"LANG": "C", "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"})
            count = sum(1 for line in r.stdout.splitlines() if "/" in line and "Listing" not in line)
            return {"count": count, "available": count > 0, "raw": r.stdout[-3000:]}
        except Exception as e:
            return {"count": -1, "available": False, "raw": str(e)}

    def get_live(self) -> dict:
        return {
            "cpu": self.get_cpu(),
            "memory": self.get_memory(),
            "internet": self.check_internet(),
        }

    def get_startup(self) -> dict:
        return {
            "os": self.get_os(),
            "disk": self.get_disk_root(),
            "uptime": self.get_uptime(),
            "updates": self.get_updates_count(),
        }
