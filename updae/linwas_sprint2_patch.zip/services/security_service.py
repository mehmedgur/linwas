"""Read-only security status for linwas Sprint 2."""
from __future__ import annotations

import os
import shutil
import subprocess


class SecurityService:
    def _run(self, cmd: list[str], timeout: int = 8) -> tuple[int, str, str]:
        try:
            env = os.environ.copy()
            env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env)
            return r.returncode, r.stdout, r.stderr
        except Exception as e:
            return 127, "", str(e)

    def get_open_ports(self) -> dict:
        if not shutil.which("ss"):
            return {"ports": [], "raw": "ss komutu bulunamadı"}
        code, out, err = self._run(["ss", "-tulpen"], timeout=8)
        ports = []
        for line in out.splitlines()[1:]:
            parts = line.split()
            if len(parts) < 5:
                continue
            local = parts[4]
            if ":" in local:
                port = local.rsplit(":", 1)[-1]
                if port.isdigit() and port not in [p.get("port") for p in ports]:
                    ports.append({"port": port, "proto": parts[0], "state": parts[1], "local": local})
        return {"ports": ports, "raw": out or err}

    def risk_score(self, updates_count: int = -1, open_port_count: int | None = None) -> dict:
        score = 100
        notes = []
        if updates_count and updates_count > 0:
            penalty = min(20, updates_count * 2)
            score -= penalty
            notes.append(f"{updates_count} paket güncellemesi bekliyor")
        if open_port_count is not None and open_port_count > 0:
            penalty = min(20, open_port_count * 5)
            score -= penalty
            notes.append(f"{open_port_count} açık port algılandı")
        level = "İyi" if score >= 80 else "Orta" if score >= 60 else "Dikkat"
        return {"score": max(0, score), "level": level, "notes": notes}

    def get_startup(self, updates_count: int = -1) -> dict:
        # Port scan is user-triggered only. Startup risk uses update state only.
        return {"risk": self.risk_score(updates_count=updates_count, open_port_count=None)}
