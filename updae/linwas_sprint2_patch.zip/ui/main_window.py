from PySide6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QStackedWidget, QLabel
from PySide6.QtGui import QFont

from ui.components.sidebar import Sidebar
from ui.pages.home_page import HomePage
from ui.pages.ai_page import AIPage
from ui.pages.system_page import SystemPage
from ui.pages.gpu_page import GPUPage
from ui.pages.network_page import NetworkPage
from ui.pages.programs_page import ProgramsPage
from ui.pages.wine_page import WinePage
from ui.pages.documents_page import DocumentsPage
from ui.pages.troubleshoot_page import TroubleshootPage
from ui.pages.security_page import SecurityPage
from ui.pages.settings_page import SettingsPage

PAGES = [
    ("Ana Sayfa",        "home",         HomePage),
    ("AI Asistan",       "ai",           AIPage),
    ("Sistem",           "system",       SystemPage),
    ("GPU & Sürücüler",  "gpu",          GPUPage),
    ("Ağ & İnternet",    "network",      NetworkPage),
    ("Programlar",       "programs",     ProgramsPage),
    ("Windows Uyg.",     "wine",         WinePage),
    ("Belgeler",         "documents",    DocumentsPage),
    ("Sorun Giderme",    "troubleshoot", TroubleshootPage),
    ("Güvenlik",         "security",     SecurityPage),
    ("Ayarlar",          "settings",     SettingsPage),
]

WINDOW_QSS = """
QMainWindow { background: #07111F; }
#content {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 #08111F, stop:0.45 #0B1830, stop:1 #101B36);
}
#titleBar {
    background: rgba(8,16,31,170);
    border-bottom: 1px solid rgba(120,160,210,30);
}
#pageTitle { color: #EAF2FF; font-size: 15px; font-weight: 700; }
"""


class MainWindow(QMainWindow):
    def __init__(self, config):
        super().__init__()
        self._config = config
        self.setWindowTitle("Linwas — Linux Yardım Merkezi")
        self.setMinimumSize(1080, 680)
        self.resize(config.get("window_width", 1280), config.get("window_height", 800))
        self._build()
        self.setStyleSheet(WINDOW_QSS)

    def _build(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self._sidebar = Sidebar(PAGES)
        self._sidebar.page_changed.connect(self._on_page)
        layout.addWidget(self._sidebar)

        right = QWidget(); right.setObjectName("content")
        rv = QVBoxLayout(right); rv.setContentsMargins(0, 0, 0, 0); rv.setSpacing(0)
        self._title_bar = self._make_title_bar(); rv.addWidget(self._title_bar)
        self._stack = QStackedWidget()
        self._page_map: dict[str, QWidget] = {}

        for name, key, PageClass in PAGES:
            page = PageClass(self._config)
            self._page_map[key] = page
            self._stack.addWidget(page)

        home: HomePage = self._page_map["home"]
        home.navigate = self._navigate_to_key

        # AI approval is still kept here until Sprint 4 orchestrator finalization.
        ai: AIPage = self._page_map["ai"]
        if hasattr(ai, "request_approval"):
            ai.request_approval.connect(self._show_approval)

        rv.addWidget(self._stack)
        layout.addWidget(right, 1)

    def _make_title_bar(self) -> QWidget:
        bar = QWidget(); bar.setObjectName("titleBar"); bar.setFixedHeight(52)
        h = QHBoxLayout(bar); h.setContentsMargins(24, 0, 24, 0)
        self._page_title = QLabel("Ana Sayfa"); self._page_title.setObjectName("pageTitle")
        font = self._page_title.font(); font.setWeight(QFont.Weight.Medium); self._page_title.setFont(font)
        h.addWidget(self._page_title); h.addStretch()
        return bar

    def _on_page(self, index: int, name: str, key: str):
        self._stack.setCurrentIndex(index)
        self._page_title.setText(name)

    def _navigate_to_key(self, key: str):
        self._sidebar.select_key(key)

    def _show_approval(self, plan):
        from ui.dialogs.approval_dialog import ApprovalDialog
        from backend.command_executor import CommandExecutor
        from ui.components.worker import run_in_thread
        from PySide6.QtWidgets import QMessageBox

        dlg = ApprovalDialog(plan, self)
        if dlg.exec() != dlg.DialogCode.Accepted:
            return

        executor = CommandExecutor()

        def execute_all():
            results = []
            for cmd in plan.commands:
                ok, out, err = executor.run(cmd, use_pkexec=plan.requires_sudo, timeout=120)
                results.append((ok, out, err))
            return results

        def on_done(results):
            success = all(r[0] for r in results)
            msg = "Tüm işlemler tamamlandı." if success else "Bir veya daha fazla işlem başarısız oldu."
            QMessageBox.information(self, "Sonuç", msg)

        run_in_thread(execute_all, on_done=on_done)

    def closeEvent(self, event):
        self._config.set("window_width", self.width())
        self._config.set("window_height", self.height())
        for page in self._page_map.values():
            if hasattr(page, "cleanup"):
                try:
                    page.cleanup()
                except Exception:
                    pass
        from ui.components.worker import stop_all_threads
        stop_all_threads(timeout_ms=3000)
        super().closeEvent(event)
