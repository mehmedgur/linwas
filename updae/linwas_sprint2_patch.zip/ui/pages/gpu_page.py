from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QTextEdit, QScrollArea
from PySide6.QtCore import Qt
from ui.components.card import Card
from backend.preloader import DataPreloader

PAGE_QSS = """
QScrollArea { border: none; background: transparent; }
QWidget#pageRoot { background: transparent; }
#Title { color:#EAF2FF; font-size:24px; font-weight:800; }
#Muted { color:#9FB3C8; font-size:12px; }
#Good { color:#56D364; font-weight:700; }
#Warn { color:#FBBF24; font-weight:700; }
QTextEdit { background:rgba(255,255,255,14); border:1px solid rgba(160,190,230,35); border-radius:14px; color:#DCE7F7; }
QPushButton { background:rgba(255,255,255,20); border:1px solid rgba(160,190,230,35); border-radius:12px; padding:10px; }
"""


class GPUPage(QWidget):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self._config = config
        self._preloader = DataPreloader.instance()
        self._setup_ui()
        self._preloader.data_ready.connect(self._on_data)
        if self._preloader.has("gpu_startup"):
            self._render(self._preloader.get("gpu_startup"))
        self.setStyleSheet(PAGE_QSS)

    def _setup_ui(self):
        scroll = QScrollArea(self); scroll.setWidgetResizable(True); scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        root = QWidget(); root.setObjectName("pageRoot"); scroll.setWidget(root)
        outer = QVBoxLayout(self); outer.setContentsMargins(0,0,0,0); outer.addWidget(scroll)
        self.main = QVBoxLayout(root); self.main.setContentsMargins(26,24,26,24); self.main.setSpacing(16)
        title = QLabel("Ekran Kartı ve Sürücüler"); title.setObjectName("Title")
        self.main.addWidget(title)
        self.summary = Card("GPU Durumu")
        self.summary_l = QVBoxLayout(); self.summary.add_layout(self.summary_l)
        self.main.addWidget(self.summary)
        self.session = Card("Wayland / X11")
        self.session_l = QVBoxLayout(); self.session.add_layout(self.session_l)
        self.main.addWidget(self.session)
        self.graphics = Card("Vulkan / OpenGL")
        self.graphics_l = QVBoxLayout(); self.graphics.add_layout(self.graphics_l)
        self.main.addWidget(self.graphics)
        self.raw = QTextEdit(); self.raw.setReadOnly(True); self.raw.setVisible(False)
        btn = QPushButton("Ayrıntıları Göster / Gizle"); btn.clicked.connect(lambda: self.raw.setVisible(not self.raw.isVisible()))
        self.main.addWidget(btn); self.main.addWidget(self.raw)
        self.main.addStretch()

    def _clear(self, layout):
        for i in reversed(range(layout.count())):
            w = layout.itemAt(i).widget()
            if w: w.deleteLater()

    def _on_data(self, key, data):
        if key == "gpu_startup":
            self._render(data)

    def _render(self, data: dict):
        self._clear(self.summary_l); self._clear(self.session_l); self._clear(self.graphics_l)
        primary = data.get("primary", {})
        hybrid = data.get("hybrid", {})
        session = data.get("session", {})
        vulkan = data.get("vulkan", {})
        opengl = data.get("opengl", {})
        self.summary_l.addWidget(QLabel(f"Ekran kartı: {primary.get('name', 'Algılanamadı')}"))
        self.summary_l.addWidget(QLabel(f"Marka: {primary.get('vendor', 'bilinmiyor').upper()}"))
        self.summary_l.addWidget(QLabel(f"Aktif sürücü: {primary.get('driver', 'bilinmiyor')}"))
        h = QLabel("Hibrit GPU algılandı" if hybrid.get("hybrid") else "Tek GPU yapısı görünüyor")
        h.setObjectName("Warn" if hybrid.get("hybrid") else "Good")
        self.summary_l.addWidget(h)
        self.session_l.addWidget(QLabel(f"Oturum: {session.get('human', 'Bilinmiyor')}"))
        note = QLabel(session.get("note", "")); note.setWordWrap(True); note.setObjectName("Muted")
        self.session_l.addWidget(note)
        self.graphics_l.addWidget(QLabel(vulkan.get("message", "Vulkan kontrolü bekleniyor")))
        self.graphics_l.addWidget(QLabel(opengl.get("message", "OpenGL kontrolü bekleniyor")))
        if opengl.get("renderer"):
            self.graphics_l.addWidget(QLabel(f"Renderer: {opengl.get('renderer')}"))
        raw = []
        for g in data.get("gpus", []):
            raw.append(g.get("raw", ""))
        raw.append(vulkan.get("raw", "")); raw.append(opengl.get("raw", ""))
        self.raw.setPlainText("\n\n".join(x for x in raw if x))
