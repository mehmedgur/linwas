import os
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QGridLayout, QFrame, QLineEdit,
)
from PySide6.QtCore import Qt, QTimer

from backend.preloader import DataPreloader
from ui.components.card import Card

PAGE_QSS = """
QScrollArea { border: none; background: transparent; }
QWidget#pageRoot { background: transparent; }
#welcomeTitle { color: #EAF2FF; font-size: 28px; font-weight: 800; }
#welcomeSub   { color: #9FB3C8; font-size: 13px; }
#sectionTitle { color: #9FB3C8; font-size: 11px; font-weight: 800; letter-spacing: 1.2px; }
#aiBox {
    background: rgba(25,35,60,210);
    border: 1px solid rgba(110,170,255,55);
    border-radius: 18px;
}
#aiInput {
    background: rgba(255,255,255,18);
    border: 1px solid rgba(160,190,230,45);
    border-radius: 16px;
    padding: 10px 14px;
    color: #EAF2FF;
}
#primaryBtn {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #06B6D4, stop:1 #2563EB);
    color: white;
    border: none;
    border-radius: 13px;
    padding: 10px 18px;
    font-weight: 800;
}
#quickBtn {
    background: rgba(255,255,255,20);
    border: 1px solid rgba(160,190,230,35);
    border-radius: 14px;
    color: #EAF2FF;
    font-size: 13px;
    padding: 14px;
}
#quickBtn:hover { background: rgba(37,99,235,60); }
#metricTitle { color: #9FB3C8; font-size: 12px; }
#metricValue { color: #EAF2FF; font-size: 25px; font-weight: 800; }
#metricSub   { color: #9FB3C8; font-size: 11px; }
#Good { color: #56D364; font-weight: 700; }
#Warn { color: #FBBF24; font-weight: 700; }
#Muted { color: #9FB3C8; font-size: 12px; }
"""


def _row(left: str, right: str, right_obj: str = ""):
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 0, 0, 0)
    l = QLabel(left); l.setObjectName("Muted")
    r = QLabel(right); r.setObjectName(right_obj or "")
    h.addWidget(l); h.addStretch(); h.addWidget(r)
    return w


class MiniMetric(Card):
    def __init__(self, icon: str, title: str, accent: str):
        super().__init__()
        self._icon = QLabel(icon)
        self._icon.setAlignment(Qt.AlignCenter)
        self._icon.setFixedSize(44, 44)
        self._icon.setStyleSheet(f"background:{accent}; border-radius:13px; font-size:22px;")
        self._title = QLabel(title); self._title.setObjectName("metricTitle")
        self._value = QLabel("-"); self._value.setObjectName("metricValue")
        self._sub = QLabel("Bekleniyor"); self._sub.setObjectName("metricSub")

        row = QHBoxLayout()
        col = QVBoxLayout(); col.setSpacing(2)
        col.addWidget(self._title); col.addWidget(self._value); col.addWidget(self._sub)
        row.addWidget(self._icon); row.addLayout(col); row.addStretch()
        self.add_layout(row)

    def update_metric(self, value: str, sub: str = ""):
        self._value.setText(value)
        self._sub.setText(sub)


class HomePage(QWidget):
    navigate = None

    def __init__(self, config, parent=None):
        super().__init__(parent)
        self._config = config
        self._preloader = DataPreloader.instance()
        self._live_refreshing = False
        self._setup_ui()
        self._connect_preloader()
        self._apply_cached_data()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._refresh_live)
        self._timer.start(2000)
        self.setStyleSheet(PAGE_QSS)

    def cleanup(self):
        if hasattr(self, "_timer"):
            self._timer.stop()

    def _setup_ui(self):
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        root = QWidget(); root.setObjectName("pageRoot")
        scroll.setWidget(root)
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(scroll)
        self._main = QVBoxLayout(root); self._main.setContentsMargins(26, 24, 26, 24); self._main.setSpacing(18)

        top = QHBoxLayout()
        title_col = QVBoxLayout()
        user = os.environ.get("USER", os.environ.get("LOGNAME", "Kullanıcı"))
        title = QLabel(f"Merhaba, {user}! 👋"); title.setObjectName("welcomeTitle")
        sub = QLabel("Sistem kontrol merkezi hazır. Canlı veriler 2 saniyede bir yenilenir."); sub.setObjectName("welcomeSub")
        title_col.addWidget(title); title_col.addWidget(sub)
        top.addLayout(title_col); top.addStretch()
        self._main.addLayout(top)

        metrics = QGridLayout(); metrics.setSpacing(16)
        self.cpu_card = MiniMetric("⚙", "İşlemci", "#2563EB")
        self.ram_card = MiniMetric("🧠", "Bellek", "#7C3AED")
        self.gpu_card = MiniMetric("🎮", "GPU", "#16A34A")
        self.net_card = MiniMetric("📶", "Ağ", "#0891B2")
        metrics.addWidget(self.cpu_card, 0, 0)
        metrics.addWidget(self.ram_card, 0, 1)
        metrics.addWidget(self.gpu_card, 0, 2)
        metrics.addWidget(self.net_card, 0, 3)
        self._main.addLayout(metrics)

        mid = QGridLayout(); mid.setSpacing(16)
        self.system_card = Card("Sistem Özeti")
        self.system_layout = QVBoxLayout(); self.system_card.add_layout(self.system_layout)
        self._fill_system_placeholder()

        actions = Card("Hızlı İşlemler")
        ag = QGridLayout(); ag.setSpacing(12)
        for i, (label, key) in enumerate([
            ("Sistem Güncelle", "system"),
            ("Sürücü Kontrolü", "gpu"),
            ("Ağ Teşhis Aracı", "network"),
            ("Port Tara", "security"),
            ("Program Kur", "programs"),
            ("Geri Al Merkezi", "settings"),
        ]):
            b = QPushButton(label); b.setObjectName("quickBtn"); b.setMinimumHeight(54)
            b.clicked.connect(lambda _, k=key: self._navigate(k))
            ag.addWidget(b, i // 2, i % 2)
        actions.add_layout(ag)

        ai = QFrame(); ai.setObjectName("aiBox")
        ai_l = QVBoxLayout(ai); ai_l.setContentsMargins(18, 16, 18, 16); ai_l.setSpacing(10)
        t = QLabel("AI Asistan"); t.setObjectName("sectionTitle")
        ai_l.addWidget(t)
        msg = QLabel("Linux sorununu yaz; Gemini ile analiz edip çözüm planı çıkarayım.")
        msg.setWordWrap(True); msg.setObjectName("Muted")
        ai_l.addWidget(msg)
        inp = QLineEdit(); inp.setObjectName("aiInput"); inp.setPlaceholderText("Örn: Wi‑Fi çalışmıyor...")
        ai_l.addWidget(inp)
        ask = QPushButton("Sor"); ask.setObjectName("primaryBtn"); ask.clicked.connect(lambda: self._navigate("ai"))
        ai_l.addWidget(ask)

        mid.addWidget(self.system_card, 0, 0, 1, 2)
        mid.addWidget(actions, 0, 2, 1, 2)
        mid.addWidget(ai, 0, 4, 1, 1)
        self._main.addLayout(mid)

        lower = QGridLayout(); lower.setSpacing(16)
        self.live_card = Card("Canlı İzleme")
        self.live_layout = QHBoxLayout(); self.live_card.add_layout(self.live_layout)
        for name in ["CPU", "RAM", "İnternet", "GPU"]:
            m = QLabel(f"{name}\nBekleniyor")
            m.setAlignment(Qt.AlignCenter)
            m.setObjectName("Muted")
            m.setStyleSheet("background:rgba(255,255,255,14); border-radius:14px; padding:14px;")
            self.live_layout.addWidget(m)
        self.recent_card = Card("Son İşlemler / Geri Al")
        self.recent_card.add_widget(QLabel("Tam geri alınabilir ✓  Discord paketi kuruldu"))
        self.recent_card.add_widget(QLabel("Kısmen geri alınabilir ⚠  NVIDIA sürücüsü kontrol edildi"))
        self.recent_card.add_widget(QPushButton("Tüm Geçmişi Gör"))
        lower.addWidget(self.live_card, 0, 0, 1, 3)
        lower.addWidget(self.recent_card, 0, 3, 1, 2)
        self._main.addLayout(lower)

        suggestions = Card("Önerilenler")
        sr = QHBoxLayout()
        for title, desc, key in [
            ("GPU Kontrolü", "Sürücü ve Wayland/X11 durumu incelensin.", "gpu"),
            ("Linux’a Güvenli Aktar", "Office belgeni yedekleyip uyumluluk kontrolü yap.", "documents"),
            ("Ağ Analizi", "Wi‑Fi ve DNS bağlantı durumunu kontrol et.", "network"),
        ]:
            c = Card()
            c.add_widget(QLabel(title))
            d = QLabel(desc); d.setObjectName("Muted"); d.setWordWrap(True)
            c.add_widget(d)
            b = QPushButton("Aç"); b.setObjectName("quickBtn"); b.clicked.connect(lambda _, k=key: self._navigate(k))
            c.add_widget(b)
            sr.addWidget(c)
        suggestions.add_layout(sr)
        self._main.addWidget(suggestions)
        self._main.addStretch()

    def _fill_system_placeholder(self):
        for i in reversed(range(self.system_layout.count())):
            item = self.system_layout.itemAt(i)
            w = item.widget()
            if w:
                w.deleteLater()
        for a, b in [("Dağıtım", "Bekleniyor"), ("Oturum", "Bekleniyor"), ("Güncellemeler", "Bekleniyor"), ("Güvenlik Skoru", "Bekleniyor")]:
            self.system_layout.addWidget(_row(a, b))

    def _connect_preloader(self):
        self._preloader.data_ready.connect(self._on_preload)

    def _apply_cached_data(self):
        for key in ["system_startup", "gpu_startup", "network_startup", "security_startup", "live_system", "live_gpu", "live_network"]:
            if self._preloader.has(key):
                self._on_preload(key, self._preloader.get(key))

    def _on_preload(self, key: str, data):
        if key == "system_startup":
            self._apply_system_startup(data)
        elif key == "gpu_startup":
            self._apply_gpu_startup(data)
        elif key == "network_startup":
            self._apply_network_startup(data)
        elif key == "security_startup":
            self._apply_security_startup(data)
        elif key == "live_system":
            self._apply_live_system(data)
        elif key == "live_gpu":
            self._apply_live_gpu(data)
        elif key == "live_network":
            self._apply_live_network(data)

    def _apply_system_startup(self, data: dict):
        for i in reversed(range(self.system_layout.count())):
            w = self.system_layout.itemAt(i).widget()
            if w:
                w.deleteLater()
        os_info = data.get("os", {})
        updates = data.get("updates", {})
        disk = data.get("disk", {})
        self.system_layout.addWidget(_row("Dağıtım", os_info.get("name", "Linux")))
        self.system_layout.addWidget(_row("Oturum", os_info.get("session", "bilinmiyor")))
        self.system_layout.addWidget(_row("Disk", f"{disk.get('used_gb', 0)} / {disk.get('total_gb', 0)} GB"))
        count = updates.get("count", -1)
        self.system_layout.addWidget(_row("Güncellemeler", "Kontrol edilemedi" if count < 0 else f"{count} paket"))

    def _apply_security_startup(self, data: dict):
        risk = data.get("risk", {})
        self.system_layout.addWidget(_row("Güvenlik Skoru", f"{risk.get('score', '-')} / 100", "Good" if risk.get("score", 0) >= 80 else "Warn"))

    def _apply_gpu_startup(self, data: dict):
        primary = data.get("primary", {})
        session = data.get("session", {})
        name = primary.get("name", "Algılanamadı")
        self.gpu_card.update_metric(primary.get("vendor", "GPU").upper(), name[:34])
        # Add a human-readable session note to system summary once.
        if session.get("human"):
            self.system_layout.addWidget(_row("Grafik oturumu", session.get("human")))

    def _apply_network_startup(self, data: dict):
        wifi = data.get("wifi", {})
        self.net_card.update_metric("Bağlı" if wifi.get("connected") else "Kapalı", wifi.get("message", "Ağ durumu"))

    def _apply_live_system(self, data: dict):
        cpu = data.get("cpu", {})
        mem = data.get("memory", {})
        net = data.get("internet", {})
        self.cpu_card.update_metric(f"{cpu.get('percent', 0):.0f}%", cpu.get("name", "CPU")[:34])
        self.ram_card.update_metric(f"{mem.get('used_gb', 0):.1f} GB", f"{mem.get('total_gb', 0)} GB içinde")
        # live labels
        labels = [self.live_layout.itemAt(i).widget() for i in range(self.live_layout.count())]
        if len(labels) >= 3:
            labels[0].setText(f"CPU\n{cpu.get('percent', 0):.0f}%")
            labels[1].setText(f"RAM\n{mem.get('percent', 0):.0f}%")
            labels[2].setText("İnternet\nBağlı" if net.get("connected") else "İnternet\nYok")

    def _apply_live_gpu(self, data: dict):
        nvidia = data.get("nvidia", {})
        labels = [self.live_layout.itemAt(i).widget() for i in range(self.live_layout.count())]
        if len(labels) >= 4 and nvidia.get("available"):
            labels[3].setText(f"GPU\n{nvidia.get('util_percent', 0):.0f}% / {nvidia.get('temperature_c', 0):.0f}°C")
            self.gpu_card.update_metric(f"{nvidia.get('temperature_c', 0):.0f}°C", f"Kullanım %{nvidia.get('util_percent', 0):.0f}")

    def _apply_live_network(self, data: dict):
        wifi = data.get("wifi", {})
        internet = data.get("internet", {})
        if wifi:
            self.net_card.update_metric("Bağlı" if wifi.get("connected") else "Yok", wifi.get("message", "Ağ durumu"))

    def _refresh_live(self):
        if self._live_refreshing:
            return
        self._live_refreshing = True

        def done(_=None):
            self._live_refreshing = False

        self._preloader.refresh_live()
        QTimer.singleShot(500, done)

    def _navigate(self, key: str):
        if self.navigate:
            self.navigate(key)
