from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton, QScrollArea
from PySide6.QtCore import Qt
from ui.components.card import Card
from backend.preloader import DataPreloader

PAGE_QSS = """
QScrollArea { border:none; background:transparent; }
QWidget#pageRoot { background:transparent; }
#Title { color:#EAF2FF; font-size:24px; font-weight:800; }
#Muted { color:#9FB3C8; font-size:12px; }
#Good { color:#56D364; font-weight:700; }
#Warn { color:#FBBF24; font-weight:700; }
QTextEdit { background:rgba(255,255,255,14); border:1px solid rgba(160,190,230,35); border-radius:14px; color:#DCE7F7; }
QPushButton { background:rgba(255,255,255,20); border:1px solid rgba(160,190,230,35); border-radius:12px; padding:10px; }
"""

class NetworkPage(QWidget):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self._preloader = DataPreloader.instance()
        self._setup_ui()
        self._preloader.data_ready.connect(self._on_data)
        if self._preloader.has("network_startup"):
            self._render(self._preloader.get("network_startup"))
        self.setStyleSheet(PAGE_QSS)

    def _setup_ui(self):
        scroll = QScrollArea(self); scroll.setWidgetResizable(True); scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        root = QWidget(); root.setObjectName("pageRoot"); scroll.setWidget(root)
        outer = QVBoxLayout(self); outer.setContentsMargins(0,0,0,0); outer.addWidget(scroll)
        self.main = QVBoxLayout(root); self.main.setContentsMargins(26,24,26,24); self.main.setSpacing(16)
        title = QLabel("Ağ ve İnternet"); title.setObjectName("Title")
        self.main.addWidget(title)
        self.status = Card("Bağlantı Durumu"); self.status_l = QVBoxLayout(); self.status.add_layout(self.status_l); self.main.addWidget(self.status)
        self.iface = Card("Ağ Arayüzleri"); self.iface_l = QVBoxLayout(); self.iface.add_layout(self.iface_l); self.main.addWidget(self.iface)
        self.raw = QTextEdit(); self.raw.setReadOnly(True); self.raw.setVisible(False)
        btn = QPushButton("Ayrıntıları Göster / Gizle"); btn.clicked.connect(lambda: self.raw.setVisible(not self.raw.isVisible()))
        self.main.addWidget(btn); self.main.addWidget(self.raw); self.main.addStretch()

    def _clear(self, layout):
        for i in reversed(range(layout.count())):
            w = layout.itemAt(i).widget()
            if w: w.deleteLater()

    def _on_data(self, key, data):
        if key == "network_startup":
            self._render(data)
        elif key == "live_network":
            wifi = data.get("wifi", {})
            if wifi:
                self._clear(self.status_l)
                lbl = QLabel(wifi.get("message", "Ağ durumu")); lbl.setObjectName("Good" if wifi.get("connected") else "Warn")
                self.status_l.addWidget(lbl)

    def _render(self, data: dict):
        self._clear(self.status_l); self._clear(self.iface_l)
        wifi = data.get("wifi", {})
        rfkill = data.get("rfkill", {})
        lbl = QLabel(wifi.get("message", "Wi‑Fi durumu bilinmiyor")); lbl.setObjectName("Good" if wifi.get("connected") else "Warn")
        self.status_l.addWidget(lbl)
        if rfkill.get("blocked"):
            warn = QLabel("Kablosuz bağlantı rfkill tarafından engellenmiş görünüyor."); warn.setObjectName("Warn")
            self.status_l.addWidget(warn)
        for name, info in data.get("interfaces", {}).items():
            self.iface_l.addWidget(QLabel(f"{name}: {info.get('state')} — {info.get('ip', 'IP yok')}"))
        self.raw.setPlainText(str(data))
