from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QFrame
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont

SIDEBAR_QSS = """
#sidebar {
    background: rgba(8,16,31,220);
    border-right: 1px solid rgba(120,160,210,35);
}
#appName {
    color: #EAF2FF;
    font-size: 25px;
    font-weight: 900;
    letter-spacing: 1px;
}
#appSub { color: #9FB3C8; font-size: 11px; }
#navBtn {
    text-align: left;
    padding: 11px 15px;
    border: none;
    border-radius: 14px;
    color: #B8C7D9;
    font-size: 13px;
    background: transparent;
}
#navBtn:hover  { background: rgba(60,130,240,40); color: white; }
#navBtn:checked {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2563EB, stop:1 #0891B2);
    color: white;
    font-weight: 800;
}
#statusBox {
    background: rgba(255,255,255,14);
    border: 1px solid rgba(160,190,230,30);
    border-radius: 16px;
}
#statusText { color: #9FB3C8; font-size: 11px; }
"""


class Sidebar(QWidget):
    page_changed = Signal(int, str, str)

    def __init__(self, pages: list, parent=None):
        super().__init__(parent)
        self.setObjectName("sidebar")
        self.setFixedWidth(260)
        self._pages = pages
        self._buttons: list[QPushButton] = []
        self._build()
        self.setStyleSheet(SIDEBAR_QSS)

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 20, 16, 18)
        layout.setSpacing(10)

        brand = QVBoxLayout()
        logo = QLabel("linwas")
        logo.setObjectName("appName")
        logo.setAlignment(Qt.AlignLeft)
        font = logo.font(); font.setWeight(QFont.Weight.ExtraBold); logo.setFont(font)
        sub = QLabel("Linux’u Kolaylaştırır")
        sub.setObjectName("appSub")
        brand.addWidget(logo); brand.addWidget(sub)
        layout.addLayout(brand)
        layout.addSpacing(12)

        for idx, (name, key, _cls) in enumerate(self._pages):
            btn = QPushButton(self._label_for(key, name))
            btn.setObjectName("navBtn")
            btn.setCheckable(True)
            btn.setMinimumHeight(42)
            btn.clicked.connect(lambda checked=False, i=idx, n=name, k=key: self._select(i, n, k))
            self._buttons.append(btn)
            layout.addWidget(btn)

        layout.addStretch()
        status = QFrame(); status.setObjectName("statusBox")
        sv = QVBoxLayout(status); sv.setContentsMargins(14, 12, 14, 12)
        sv.addWidget(QLabel("✅ Sistem Durumu"))
        st = QLabel("Her şey yolunda!"); st.setObjectName("statusText")
        sv.addWidget(st)
        layout.addWidget(status)
        version = QLabel("linwas v1.0")
        version.setObjectName("statusText")
        layout.addWidget(version)

        if self._buttons:
            self._buttons[0].setChecked(True)

    def _label_for(self, key: str, name: str) -> str:
        icons = {
            "home": "🏠", "ai": "🤖", "system": "🖥", "gpu": "🎮", "network": "📶",
            "programs": "📦", "wine": "🪟", "documents": "📄", "troubleshoot": "🛠",
            "security": "🛡", "settings": "⚙",
        }
        return f"{icons.get(key, '•')}  {name}"

    def _select(self, index: int, name: str, key: str):
        for b in self._buttons:
            b.setChecked(False)
        self._buttons[index].setChecked(True)
        self.page_changed.emit(index, name, key)

    def select_key(self, key: str):
        for i, (name, k, _cls) in enumerate(self._pages):
            if k == key:
                self._select(i, name, k)
                return
