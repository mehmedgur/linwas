from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel
from PySide6.QtGui import QFont

CARD_STYLE = """
    QFrame#linwasCard {
        background: rgba(255,255,255,16);
        border-radius: 18px;
        border: 1px solid rgba(160,190,230,35);
    }
    QLabel#cardTitle {
        color: #EAF2FF;
        font-size: 15px;
        font-weight: 800;
    }
"""


class Card(QFrame):
    def __init__(self, title: str = "", parent=None):
        super().__init__(parent)
        self.setObjectName("linwasCard")
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(18, 16, 18, 16)
        self._layout.setSpacing(10)
        self.setStyleSheet(CARD_STYLE)

        if title:
            lbl = QLabel(title)
            lbl.setObjectName("cardTitle")
            font = lbl.font()
            font.setPointSize(11)
            font.setWeight(QFont.Weight.Bold)
            lbl.setFont(font)
            self._layout.addWidget(lbl)

    def content_layout(self):
        return self._layout

    def add_widget(self, widget):
        self._layout.addWidget(widget)

    def add_layout(self, layout):
        self._layout.addLayout(layout)
