# linwas Sprint 2 — Test Talimatı

Bu yama Sprint 2A + Sprint 2B başlangıcıdır:

- Canlı dashboard verileri
- Yeni modern sidebar/dashboard tasarımı
- Services katmanı başlangıcı
- GPU sayfası
- Ağ & İnternet sayfası
- Güvenlik risk puanı için servis temeli

## Uygulama

Patch'i mevcut proje klasörünün üstüne çıkar:

```bash
unzip linwas_sprint2_patch.zip
cd linwas
sudo bash setup.sh
```

Normal kullanıcıyla çalıştır:

```bash
linwas
```

Geliştirme klasöründe test:

```bash
python3 main.py
```

## Raporlanacaklar

1. Uygulama açılıyor mu?
2. Ana sayfada CPU/RAM gerçek değerleri geliyor mu?
3. Dashboard 2 saniyede bir değişiyor mu?
4. GPU kartı ekran kartını gösteriyor mu?
5. GPU & Sürücüler sayfası açılıyor mu?
6. Ağ & İnternet sayfasında Wi‑Fi / IP bilgisi geliyor mu?
7. Kapatırken QThread hatası var mı?
8. Terminalde hata çıktısı var mı?

## Notlar

- Vulkan/OpenGL için `vulkaninfo` ve `glxinfo` yoksa hata değildir; UI “araç kurulu değil” diye gösterir.
- NVIDIA yoksa GPU canlı kullanım boş kalabilir; bu normaldir.
- Ağ sayfası NetworkManager/nmcli yoksa sınırlı veri gösterir.
