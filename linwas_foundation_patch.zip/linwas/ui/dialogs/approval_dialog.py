import shlex
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTextEdit, QFrame,
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from backend.permission_manager import ActionPlan

RISK_COLORS = {
    "low":    ("#98c379", "#1a3a1a"),
    "medium": ("#e5c07b", "#4a3a00"),
    "high":   ("#e06c75", "#4a1a1a"),
}

DIALOG_QSS = """
    QDialog { background: #21252b; }
    #title { color: #dcdfe4; font-size: 16px; font-weight: 700; }
    #desc  { color: #9da5b4; font-size: 13px; }
    #cmdBox {
        background: #1e2127; color: #abb2bf;
        border: 1px solid #2c313a; border-radius: 6px;
        font-family: monospace; font-size: 12px;
    }
    QPushButton#approveBtn {
        background: #0078d4; color: white; border: none;
        border-radius: 8px; padding: 10px 24px; font-size: 13px; font-weight: 600;
    }
    QPushButton#approveBtn:hover { background: #106ebe; }
    QPushButton#cancelBtn {
        background: #3a3f4b; color: #dcdfe4; border: none;
        border-radius: 8px; padding: 10px 24px; font-size: 13px;
    }
    QPushButton#cancelBtn:hover { background: #4a4f5b; }
    #warnLabel { color: #e5c07b; font-size: 12px; }
    #sudoLabel { color: #e06c75; font-size: 12px; }
"""


class ApprovalDialog(QDialog):
    def __init__(self, plan: ActionPlan, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Onay Gerekiyor")
        self.setMinimumWidth(500)
        self.setModal(True)
        self._plan = plan
        self._build()
        self.setStyleSheet(DIALOG_QSS)

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # Risk badge
        fg, bg = RISK_COLORS.get(self._plan.risk_level, RISK_COLORS["low"])
        risk_lbl = QLabel(f"Risk: {self._plan.risk_level.upper()}")
        risk_lbl.setAlignment(Qt.AlignCenter)
        risk_lbl.setFixedWidth(100)
        risk_lbl.setStyleSheet(
            f"color:{fg};background:{bg};border-radius:4px;padding:3px 10px;"
            f"font-size:11px;font-weight:600;"
        )
        layout.addWidget(risk_lbl)

        # Title
        title = QLabel(self._plan.title)
        title.setObjectName("title")
        layout.addWidget(title)

        # Description
        desc = QLabel(self._plan.description)
        desc.setObjectName("desc")
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # Sudo warning
        if self._plan.requires_sudo:
            sudo_lbl = QLabel("Bu islem yonetici (sudo/pkexec) yetkisi gerektirir.")
            sudo_lbl.setObjectName("sudoLabel")
            layout.addWidget(sudo_lbl)

        # Commands
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("background:#2c313a;max-height:1px;border:none;")
        layout.addWidget(sep)

        cmd_label = QLabel("Calistirilacak komutlar:")
        cmd_label.setStyleSheet("color:#9da5b4;font-size:11px;font-weight:600;letter-spacing:1px;")
        layout.addWidget(cmd_label)

        cmd_text = QTextEdit()
        cmd_text.setObjectName("cmdBox")
        cmd_text.setReadOnly(True)
        cmd_text.setFixedHeight(min(80 + len(self._plan.commands) * 20, 160))
        cmd_text.setPlainText("\n".join(shlex.join(cmd) for cmd in self._plan.commands))
        layout.addWidget(cmd_text)

        # Warnings
        for w in self._plan.warnings:
            wl = QLabel(f"Uyari: {w}")
            wl.setObjectName("warnLabel")
            wl.setWordWrap(True)
            layout.addWidget(wl)

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        cancel = QPushButton("Iptal")
        cancel.setObjectName("cancelBtn")
        cancel.clicked.connect(self.reject)
        btn_row.addWidget(cancel)

        approve = QPushButton("Onayliyorum, devam et")
        approve.setObjectName("approveBtn")
        approve.clicked.connect(self.accept)
        btn_row.addWidget(approve)
        layout.addLayout(btn_row)
