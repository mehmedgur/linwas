from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QListWidget, QListWidgetItem, QTabWidget,
    QScrollArea, QMessageBox, QSizePolicy,
)
from PySide6.QtCore import Qt, QTimer

from ui.components.card import Card
from ui.components.worker import run_in_thread
from backend.packages import PackageManager
from backend.command_executor import CommandExecutor
from backend.task_manager import TaskManager
from backend.permission_manager import PermissionManager
from backend.action_planner import ActionPlanner
from services.apt_service import AptService
from services.flatpak_service import FlatpakService

PAGE_QSS = """
    QScrollArea { border: none; background: transparent; }
    #searchInput {
        background: #282c34; color: #dcdfe4; border: 1px solid #3a3f4b;
        border-radius: 8px; padding: 10px 14px; font-size: 13px;
    }
    #searchInput:focus { border-color: #0078d4; }
    QPushButton#actionBtn {
        background: #0078d4; color: white; border: none;
        border-radius: 6px; padding: 7px 14px; font-size: 12px;
    }
    QPushButton#actionBtn:hover { background: #106ebe; }
    QPushButton#removeBtn {
        background: #3a3f4b; color: #e06c75; border: none;
        border-radius: 6px; padding: 7px 14px; font-size: 12px;
    }
    QPushButton#removeBtn:hover { background: #4a2020; }
    QListWidget {
        background: #282c34; border: 1px solid #2c313a; border-radius: 8px;
        color: #dcdfe4; font-size: 13px; outline: none;
    }
    QListWidget::item { padding: 8px 12px; border-bottom: 1px solid #2c313a; }
    QListWidget::item:selected { background: #0078d4; color: white; }
    QListWidget::item:hover { background: #2c313a; }
    QTabWidget::pane { border: none; }
    QTabBar::tab {
        background: #21252b; color: #9da5b4;
        padding: 8px 20px; border: none; border-bottom: 2px solid transparent;
    }
    QTabBar::tab:selected { color: #dcdfe4; border-bottom-color: #0078d4; background: #282c34; }
"""

POPULAR_APPS = [
    ("Firefox",            "firefox",          "apt"),
    ("VLC",                "vlc",              "apt"),
    ("GIMP",               "gimp",             "apt"),
    ("LibreOffice",        "libreoffice",      "apt"),
    ("VS Code",            "com.visualstudio.code", "flatpak"),
    ("Spotify",            "com.spotify.Client",    "flatpak"),
    ("Discord",            "com.discordapp.Discord", "flatpak"),
    ("Telegram",           "org.telegram.desktop",  "flatpak"),
    ("Inkscape",           "inkscape",         "apt"),
    ("VirtualBox",         "virtualbox",       "apt"),
]


class ProgramsPage(QWidget):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self._config = config
        self._pkg    = PackageManager()
        self._exec   = CommandExecutor()
        self._tm     = TaskManager()
        self._perm   = PermissionManager()
        self._planner = ActionPlanner()
        self._apt_svc = AptService(self._exec, self._tm)
        self._fp_svc  = FlatpakService(self._exec, self._tm)
        self._setup_ui()
        self._perm.approval_callback = self._ask_approval
        self.setStyleSheet(PAGE_QSS)

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # Search
        search_card = Card()
        sh = QHBoxLayout()
        self._search = QLineEdit()
        self._search.setObjectName("searchInput")
        self._search.setPlaceholderText("Paket ara... (orn: vlc, firefox, python3)")
        self._search.setFixedHeight(44)
        self._search.returnPressed.connect(self._do_search)
        sh.addWidget(self._search, 1)
        sb = QPushButton("Ara")
        sb.setObjectName("actionBtn")
        sb.setFixedHeight(44)
        sb.clicked.connect(self._do_search)
        sh.addWidget(sb)
        search_card.add_layout(sh)
        layout.addWidget(search_card)

        # Tabs
        self._tabs = QTabWidget()
        self._tabs.addTab(self._make_search_tab(),    "Arama Sonuclari")
        self._tabs.addTab(self._make_popular_tab(),   "Populer Uygulamalar")
        self._tabs.addTab(self._make_installed_tab(), "Kurulu Paketler")
        layout.addWidget(self._tabs, 1)

        # Status
        self._status = QLabel("")
        self._status.setStyleSheet("color:#9da5b4;font-size:12px;")
        layout.addWidget(self._status)

    def _make_search_tab(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 12, 0, 0)
        self._search_list = QListWidget()
        self._search_list.itemDoubleClicked.connect(self._on_search_item_action)
        v.addWidget(self._search_list)

        btn_row = QHBoxLayout()
        install_btn = QPushButton("Kur (APT)")
        install_btn.setObjectName("actionBtn")
        install_btn.clicked.connect(lambda: self._install_selected("apt"))
        btn_row.addWidget(install_btn)

        fp_btn = QPushButton("Kur (Flatpak)")
        fp_btn.setObjectName("actionBtn")
        fp_btn.clicked.connect(lambda: self._install_selected("flatpak"))
        btn_row.addWidget(fp_btn)
        btn_row.addStretch()
        v.addLayout(btn_row)
        return w

    def _make_popular_tab(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 12, 0, 0)

        for name, pkg, mgr in POPULAR_APPS:
            row = QWidget()
            h = QHBoxLayout(row)
            h.setContentsMargins(0, 4, 0, 4)
            lbl = QLabel(f"<b>{name}</b>  <span style='color:#9da5b4;font-size:11px;'>{pkg} ({mgr})</span>")
            lbl.setStyleSheet("color:#dcdfe4;")
            h.addWidget(lbl, 1)
            btn = QPushButton("Kur")
            btn.setObjectName("actionBtn")
            btn.clicked.connect(lambda _, p=pkg, m=mgr: self._install_package(p, m))
            h.addWidget(btn)
            v.addWidget(row)
        v.addStretch()
        return w

    def _make_installed_tab(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 12, 0, 0)

        ref = QPushButton("Listeyi Yenile")
        ref.setObjectName("actionBtn")
        ref.clicked.connect(self._load_installed)
        v.addWidget(ref)

        self._installed_list = QListWidget()
        v.addWidget(self._installed_list, 1)

        remove_btn = QPushButton("Secileni Kaldir")
        remove_btn.setObjectName("removeBtn")
        remove_btn.clicked.connect(self._remove_selected)
        v.addWidget(remove_btn)
        return w

    def _do_search(self):
        query = self._search.text().strip()
        if not query:
            return
        self._search_list.clear()
        self._status.setText("Aranıyor...")
        run_in_thread(
            lambda: self._pkg.apt_search(query),
            on_done=self._on_search_results
        )

    def _on_search_results(self, results: list):
        self._search_list.clear()
        for r in results:
            item = QListWidgetItem(f"{r['name']}  —  {r['description']}")
            item.setData(Qt.UserRole, r['name'])
            self._search_list.addItem(item)
        self._status.setText(f"{len(results)} sonuç bulundu")
        self._tabs.setCurrentIndex(0)

    def _on_search_item_action(self, item: QListWidgetItem):
        pkg = item.data(Qt.UserRole)
        self._install_package(pkg, "apt")

    def _install_selected(self, manager: str):
        item = self._search_list.currentItem()
        if not item:
            return
        pkg = item.data(Qt.UserRole)
        self._install_package(pkg, manager)

    def _install_package(self, package: str, manager: str):
        plan = self._planner.from_package_install(package, manager)
        if not self._ask_approval(plan):
            return
        self._status.setText(f"Kuruluyor: {package}...")
        def do_install():
            if manager == "flatpak":
                return self._fp_svc.install(package)
            return self._apt_svc.install(package)
        run_in_thread(do_install,
                      on_done=lambda r: self._status.setText(
                          f"'{package}' kuruldu." if r[0] else f"Hata: {r[1][:100]}"
                      ))

    def _load_installed(self):
        self._installed_list.clear()
        self._status.setText("Kurulu paketler listeleniyor...")
        run_in_thread(self._pkg.apt_list_installed, on_done=self._on_installed)

    def _on_installed(self, packages: list):
        self._installed_list.clear()
        for p in packages:
            item = QListWidgetItem(f"{p['name']}  {p['version']}")
            item.setData(Qt.UserRole, p['name'])
            self._installed_list.addItem(item)
        self._status.setText(f"{len(packages)} paket kurulu")

    def _remove_selected(self):
        item = self._installed_list.currentItem()
        if not item:
            return
        pkg = item.data(Qt.UserRole)
        plan = self._planner.from_package_remove(pkg)
        if not self._ask_approval(plan):
            return
        self._status.setText(f"Kaldırılıyor: {pkg}...")
        run_in_thread(
            lambda: self._apt_svc.remove(pkg),
            on_done=lambda r: self._status.setText(
                f"'{pkg}' kaldırıldı." if r[0] else f"Hata: {r[1][:100]}"
            )
        )

    def _ask_approval(self, plan) -> bool:
        from ui.dialogs.approval_dialog import ApprovalDialog
        dlg = ApprovalDialog(plan, self)
        return dlg.exec() == dlg.DialogCode.Accepted
