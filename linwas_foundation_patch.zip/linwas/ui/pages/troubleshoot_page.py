from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTextEdit, QScrollArea, QGridLayout,
)
from PySide6.QtCore import Qt

from ui.components.card import Card
from ui.components.status_badge import StatusBadge
from ui.components.worker import run_in_thread
from backend.troubleshoot import TroubleshootBackend
from backend.preloader import DataPreloader

PAGE_QSS = """
    QScrollArea { border: none; background: transparent; }
    QWidget#pageRoot { background: transparent; }
    QPushButton#scanBtn {
        background: #0078d4; color: white; border: none;
        border-radius: 8px; padding: 12px 28px; font-size: 14px; font-weight: 600;
    }
    QPushButton#scanBtn:hover { background: #106ebe; }
    QPushButton#scanBtn:disabled { background: #3a3f4b; color: #5c6370; }
    QPushButton#fixBtn {
        background: #98c379; color: #1a2010; border: none;
        border-radius: 6px; padding: 6px 14px; font-size: 12px; font-weight: 600;
    }
    QTextEdit {
        background: #282c34; color: #abb2bf; border: 1px solid #2c313a;
        border-radius: 8px; font-size: 12px; font-family: monospace;
    }
    #checkTitle { color: #dcdfe4; font-size: 13px; font-weight: 600; }
    #checkDesc  { color: #9da5b4; font-size: 12px; }
"""

CHECKS = [
    ("internet",  "Internet Baglantisi", "Ag ve DNS kontrolu"),
    ("disk",      "Disk Alani",          "Doluluk orani kontrolu"),
    ("updates",   "Guncellemeler",       "Bekleyen guncelleme kontrolu"),
    ("audio",     "Ses Sistemi",         "PulseAudio/PipeWire kontrolu"),
    ("bluetooth", "Bluetooth",           "Bluetooth servis durumu"),
    ("services",  "Sistem Servisleri",   "Basarisiz servis kontrolu"),
]


class TroubleshootPage(QWidget):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self._config  = config
        self._backend = TroubleshootBackend()
        self._badges: dict[str, StatusBadge] = {}
        self._descs:  dict[str, QLabel]      = {}
        self._setup_ui()
        self.setStyleSheet(PAGE_QSS)

        preloader = DataPreloader.instance()
        if preloader.has("troubleshoot"):
            self._on_results(preloader.get("troubleshoot"))
        else:
            preloader.data_ready.connect(self._on_preload)

    def _setup_ui(self):
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        root = QWidget()
        root.setObjectName("pageRoot")
        scroll.setWidget(root)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

        main = QVBoxLayout(root)
        main.setContentsMargins(24, 24, 24, 24)
        main.setSpacing(20)

        # Scan button
        top = QHBoxLayout()
        self._scan_btn = QPushButton("Sistemi Tara")
        self._scan_btn.setObjectName("scanBtn")
        self._scan_btn.clicked.connect(self._run_scan)
        top.addWidget(self._scan_btn)
        top.addStretch()
        main.addLayout(top)

        # Check cards grid
        checks_card = Card("Kontrol Listesi")
        grid = QGridLayout()
        grid.setSpacing(12)

        for row_idx, (key, title, desc) in enumerate(CHECKS):
            badge = StatusBadge("Bekleniyor", "neutral")
            badge.setFixedWidth(120)
            self._badges[key] = badge

            title_lbl = QLabel(title)
            title_lbl.setObjectName("checkTitle")

            desc_lbl = QLabel(desc)
            desc_lbl.setObjectName("checkDesc")
            self._descs[key] = desc_lbl

            col = QVBoxLayout()
            col.setSpacing(2)
            col.addWidget(title_lbl)
            col.addWidget(desc_lbl)

            grid.addWidget(badge, row_idx, 0)
            w = QWidget()
            w.setLayout(col)
            grid.addWidget(w, row_idx, 1)

        checks_card.add_layout(grid)
        main.addWidget(checks_card)

        # Journal errors
        log_card = Card("Sistem Hata Kayitlari (Son 20)")
        self._log = QTextEdit()
        self._log.setReadOnly(True)
        self._log.setFixedHeight(200)
        self._log.setPlaceholderText("Tarama yapildiktan sonra hatalar burada gorunur.")
        log_card.add_widget(self._log)

        log_btn = QPushButton("Hata Kayitlarini Goster")
        log_btn.setStyleSheet("QPushButton{background:#3a3f4b;color:#dcdfe4;border:none;border-radius:6px;padding:7px 14px;font-size:12px;}")
        log_btn.clicked.connect(self._load_logs)
        log_card.add_widget(log_btn)
        main.addWidget(log_card)

        main.addStretch()

    def _on_preload(self, key: str, data):
        if key == "troubleshoot":
            self._on_results(data)
            DataPreloader.instance().data_ready.disconnect(self._on_preload)

    def _run_scan(self):
        self._scan_btn.setEnabled(False)
        self._scan_btn.setText("Taraniyor...")
        for badge in self._badges.values():
            badge.set_status("neutral", "Kontrol ediliyor...")

        run_in_thread(
            self._backend.run_all_checks,
            on_done=self._on_results,
            on_error=lambda e: (
                self._scan_btn.setEnabled(True),
                self._scan_btn.setText("Sistemi Tara"),
            )
        )

    def _on_results(self, results: dict):
        self._scan_btn.setEnabled(True)
        self._scan_btn.setText("Yeniden Tara")

        net = results.get("internet", {})
        self._badges["internet"].set_status(net.get("status", "neutral"), net.get("message", "-"))

        disk_issues = results.get("disk", [])
        if disk_issues:
            worst = max(disk_issues, key=lambda x: x.get("percent", 0))
            self._badges["disk"].set_status(worst["severity"], worst["message"])
        else:
            self._badges["disk"].set_status("good", "Disk alani normal")

        upd = results.get("updates", {})
        self._badges["updates"].set_status(upd.get("status", "neutral"), upd.get("message", "-"))

        audio = results.get("audio", {})
        self._badges["audio"].set_status(audio.get("status", "neutral"), audio.get("message", "-"))

        bt = results.get("bluetooth", {})
        self._badges["bluetooth"].set_status(bt.get("status", "neutral"), bt.get("message", "-"))

        failed = results.get("services", [])
        if failed:
            names = ", ".join(s["service"] for s in failed[:3])
            self._badges["services"].set_status("error", f"Basarisiz: {names}")
        else:
            self._badges["services"].set_status("good", "Tum servisler calisiyor")

    def _load_logs(self):
        run_in_thread(
            self._backend.get_journal_errors,
            on_done=lambda lines: self._log.setPlainText("\n".join(lines) or "Hata kaydi bulunamadi.")
        )
