from pathlib import Path
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QTextEdit,
)
from PySide6.QtCore import Qt

from ui.components.card import Card
from ui.components.status_badge import StatusBadge
from ui.components.worker import run_in_thread
from backend.wine_helper import WineHelper
from backend.command_executor import CommandExecutor
from backend.task_manager import TaskManager
from services.wine_service import WineService

PAGE_QSS = """
    QWidget { background: transparent; }
    QPushButton#mainBtn {
        background: #0078d4; color: white; border: none;
        border-radius: 8px; padding: 10px 20px; font-size: 13px;
    }
    QPushButton#mainBtn:hover { background: #106ebe; }
    QPushButton#secBtn {
        background: #3a3f4b; color: #dcdfe4; border: none;
        border-radius: 8px; padding: 10px 20px; font-size: 13px;
    }
    QPushButton#secBtn:hover { background: #4a4f5b; }
    QTextEdit {
        background: #282c34; color: #abb2bf; border: 1px solid #2c313a;
        border-radius: 8px; font-size: 12px; font-family: monospace;
    }
    #bigLabel { color: #dcdfe4; font-size: 14px; font-weight: 600; }
    #subLabel  { color: #9da5b4; font-size: 12px; }
    #altName   { color: #dcdfe4; font-size: 13px; font-weight: 600; }
"""


class WinePage(QWidget):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self._config = config
        self._helper = WineHelper()
        self._exec   = CommandExecutor()
        self._tm     = TaskManager()
        self._svc    = WineService(self._exec, self._tm)
        self._setup_ui()
        self._check_wine()
        self.setStyleSheet(PAGE_QSS)

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(20)

        # Wine status card
        status_card = Card("Wine Durumu")
        sv = QVBoxLayout()
        self._wine_badge = StatusBadge("Kontrol ediliyor...", "neutral")
        self._wine_version = QLabel("")
        self._wine_version.setObjectName("subLabel")
        sv.addWidget(self._wine_badge)
        sv.addWidget(self._wine_version)

        btn_row = QHBoxLayout()
        self._install_wine_btn = QPushButton("Wine Kur")
        self._install_wine_btn.setObjectName("mainBtn")
        self._install_wine_btn.setEnabled(False)
        self._install_wine_btn.clicked.connect(self._install_wine)
        btn_row.addWidget(self._install_wine_btn)
        btn_row.addStretch()
        sv.addLayout(btn_row)
        status_card.add_layout(sv)
        layout.addWidget(status_card)

        # Run EXE card
        run_card = Card("Windows Programi Calistir")
        rv = QVBoxLayout()
        info = QLabel("Bir .exe dosyasi secin — Wine ile calistirmayi deneyecegiz.")
        info.setObjectName("subLabel")
        info.setWordWrap(True)
        rv.addWidget(info)

        self._exe_label = QLabel("Secilen dosya: yok")
        self._exe_label.setObjectName("subLabel")
        rv.addWidget(self._exe_label)

        rb = QHBoxLayout()
        sel_btn = QPushButton("EXE Sec")
        sel_btn.setObjectName("secBtn")
        sel_btn.clicked.connect(self._select_exe)
        rb.addWidget(sel_btn)

        self._run_btn = QPushButton("Calistir")
        self._run_btn.setObjectName("mainBtn")
        self._run_btn.setEnabled(False)
        self._run_btn.clicked.connect(self._run_exe)
        rb.addWidget(self._run_btn)
        rb.addStretch()
        rv.addLayout(rb)

        self._output = QTextEdit()
        self._output.setReadOnly(True)
        self._output.setFixedHeight(120)
        rv.addWidget(self._output)
        run_card.add_layout(rv)
        layout.addWidget(run_card)

        # Alternative suggestions card
        alt_card = Card("Linux Alternatifleri")
        av = QVBoxLayout()
        note = QLabel("EXE sectikten sonra Linux alternatifi onerilir.")
        note.setObjectName("subLabel")
        av.addWidget(note)
        self._alt_widget = QWidget()
        self._alt_layout = QVBoxLayout(self._alt_widget)
        av.addWidget(self._alt_widget)
        alt_card.add_layout(av)
        layout.addWidget(alt_card)

        layout.addStretch()
        self._exe_path: str | None = None

    def _check_wine(self):
        def check():
            installed = self._helper.is_wine_installed()
            version   = self._helper.wine_version() if installed else ""
            prefix    = self._helper.get_wine_prefix_info()
            return {"installed": installed, "version": version, "prefix": prefix}
        run_in_thread(check, on_done=self._on_wine_status)

    def _on_wine_status(self, data: dict):
        if data["installed"]:
            self._wine_badge.set_status("good", f"Wine kurulu ({data['version']})")
            self._install_wine_btn.setEnabled(False)
        else:
            self._wine_badge.set_status("warning", "Wine kurulu degil")
            self._install_wine_btn.setEnabled(True)
        prefix = data.get("prefix", {})
        if prefix.get("exists"):
            self._wine_version.setText(f"Wine prefix: {prefix['path']} ({prefix['size_mb']} MB)")

    def _install_wine(self):
        self._install_wine_btn.setEnabled(False)
        self._output.append("Wine kuruluyor...")
        run_in_thread(
            self._svc.install_wine,
            on_done=lambda r: (
                self._output.append("Wine kuruldu!" if r[0] else f"Hata: {r[1][:200]}"),
                self._check_wine()
            )
        )

    def _select_exe(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "EXE Dosyasi Sec", str(Path.home()), "Windows Executables (*.exe *.msi)"
        )
        if path:
            self._exe_path = path
            self._exe_label.setText(f"Secilen dosya: {Path(path).name}")
            self._run_btn.setEnabled(True)
            self._suggest_alternative(Path(path).stem)

    def _run_exe(self):
        if not self._exe_path:
            return
        self._output.clear()
        self._output.append(f"Calistiriliyor: {self._exe_path}")
        self._run_btn.setEnabled(False)

        def run():
            return self._helper.run_exe(self._exe_path)

        run_in_thread(
            run,
            on_done=lambda r: (
                self._output.append(r[1]),
                self._run_btn.setEnabled(True)
            )
        )

    def _suggest_alternative(self, exe_name: str):
        for i in reversed(range(self._alt_layout.count())):
            w = self._alt_layout.itemAt(i).widget()
            if w:
                w.deleteLater()

        alt = self._helper.suggest_alternative(exe_name)
        if alt:
            row = QWidget()
            h = QHBoxLayout(row)
            h.setContentsMargins(0, 0, 0, 0)
            lbl = QLabel(f"Linux alternatifi: <b>{alt['name']}</b>")
            lbl.setObjectName("altName")
            lbl.setStyleSheet("color:#dcdfe4;")
            h.addWidget(lbl, 1)
            btn = QPushButton("Kur")
            btn.setStyleSheet("QPushButton{background:#0078d4;color:white;border:none;border-radius:6px;padding:6px 14px;}")
            btn.clicked.connect(lambda: self._output.append(
                f"Kurmak icin Programlar sayfasina gidin: {alt['package']}"
            ))
            h.addWidget(btn)
            self._alt_layout.addWidget(row)
        else:
            self._alt_layout.addWidget(QLabel("Bu program icin bilinen bir Linux alternatifi bulunamadi."))
