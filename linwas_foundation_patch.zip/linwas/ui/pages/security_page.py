import subprocess
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QTextEdit,
)
from PySide6.QtCore import Qt

from ui.components.card import Card
from ui.components.status_badge import StatusBadge
from ui.components.worker import run_in_thread

PAGE_QSS = """
    QScrollArea { border: none; background: transparent; }
    QWidget#pageRoot { background: transparent; }
    QPushButton#scanBtn {
        background: #0078d4; color: white; border: none;
        border-radius: 8px; padding: 10px 24px; font-size: 13px;
    }
    QPushButton#scanBtn:hover { background: #106ebe; }
    QTextEdit {
        background: #282c34; color: #abb2bf; border: 1px solid #2c313a;
        border-radius: 8px; font-size: 12px; font-family: monospace;
    }
    #checkTitle { color: #dcdfe4; font-size: 13px; font-weight: 600; }
    #checkDesc  { color: #9da5b4; font-size: 12px; }
"""


class SecurityPage(QWidget):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self._config = config
        self._setup_ui()
        self.setStyleSheet(PAGE_QSS)

    def _setup_ui(self):
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        root = QWidget()
        root.setObjectName("pageRoot")
        scroll.setWidget(root)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

        main = QVBoxLayout(root)
        main.setContentsMargins(24, 24, 24, 24)
        main.setSpacing(20)

        top = QHBoxLayout()
        self._scan_btn = QPushButton("Guvenlik Taramasi Yap")
        self._scan_btn.setObjectName("scanBtn")
        self._scan_btn.clicked.connect(self._run_scan)
        top.addWidget(self._scan_btn)
        top.addStretch()
        main.addLayout(top)

        # UFW Card
        ufw_card = Card("Guvenlik Duvari (UFW)")
        uv = QVBoxLayout()
        self._ufw_badge = StatusBadge("Kontrol edilmedi", "neutral")
        uv.addWidget(self._ufw_badge)

        ub = QHBoxLayout()
        enable_btn = QPushButton("Etkinlestir")
        enable_btn.setStyleSheet("QPushButton{background:#98c379;color:#1a2010;border:none;border-radius:6px;padding:7px 14px;}")
        enable_btn.clicked.connect(self._enable_ufw)
        ub.addWidget(enable_btn)
        ub.addStretch()
        uv.addLayout(ub)
        ufw_card.add_layout(uv)
        main.addWidget(ufw_card)

        # Open ports
        ports_card = Card("Acik Portlar")
        pv = QVBoxLayout()
        self._ports_text = QTextEdit()
        self._ports_text.setReadOnly(True)
        self._ports_text.setFixedHeight(150)
        self._ports_text.setPlaceholderText("Tarama yapilmadi.")
        pv.addWidget(self._ports_text)
        ports_card.add_layout(pv)
        main.addWidget(ports_card)

        # Recommendations
        rec_card = Card("Guvenlik Onerileri")
        rv = QVBoxLayout()
        recs = [
            "Guvenlik duvarini (UFW) etkin tutun.",
            "Duzensiz guncelleme yapmayin, sistemi guncel tutun.",
            "Bilinmeyen .exe ve .deb dosyalarini calistirmayin.",
            "Guclü sifre kullanin ve SSH anahtari tercih edin.",
            "Kamuya acik Wi-Fi'de VPN kullanin.",
        ]
        for r in recs:
            lbl = QLabel(f"• {r}")
            lbl.setStyleSheet("color:#9da5b4;font-size:12px;")
            lbl.setWordWrap(True)
            rv.addWidget(lbl)
        rec_card.add_layout(rv)
        main.addWidget(rec_card)

        main.addStretch()

    def _run_scan(self):
        self._scan_btn.setEnabled(False)
        self._ufw_badge.set_status("neutral", "Kontrol ediliyor...")
        self._ports_text.setPlainText("Taranıyor...")

        def scan():
            ufw = self._check_ufw()
            ports = self._check_ports()
            return {"ufw": ufw, "ports": ports}

        run_in_thread(scan, on_done=self._on_results,
                      on_error=lambda _: self._scan_btn.setEnabled(True))

    def _check_ufw(self) -> dict:
        try:
            r = subprocess.run(["ufw", "status"], capture_output=True, text=True, timeout=5)
            active = "active" in r.stdout.lower()
            return {"active": active, "output": r.stdout.strip()}
        except Exception as e:
            return {"active": False, "output": str(e)}

    def _check_ports(self) -> str:
        try:
            r = subprocess.run(
                ["ss", "-tlnp"],
                capture_output=True, text=True, timeout=5
            )
            return r.stdout
        except Exception as e:
            return str(e)

    def _on_results(self, data: dict):
        self._scan_btn.setEnabled(True)
        ufw = data.get("ufw", {})
        if ufw.get("active"):
            self._ufw_badge.set_status("good", "Guvenlik duvari aktif")
        else:
            self._ufw_badge.set_status("warning", "Guvenlik duvari kapali — etkinlestirmeniz onerilir")
        self._ports_text.setPlainText(data.get("ports", ""))

    def _enable_ufw(self):
        from backend.command_executor import CommandExecutor
        ex = CommandExecutor()
        run_in_thread(
            lambda: ex.run(["ufw", "enable"], use_pkexec=True, timeout=15),
            on_done=lambda r: self._ufw_badge.set_status(
                "good" if r[0] else "error",
                "Guvenlik duvari etkinlestirildi" if r[0] else f"Hata: {r[2][:80]}"
            )
        )
