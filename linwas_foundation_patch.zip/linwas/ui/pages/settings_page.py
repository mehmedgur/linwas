from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QLineEdit, QScrollArea, QFrame,
)
from PySide6.QtCore import Qt

from ui.components.card import Card
from ai.providers import SUPPORTED_MODELS as PROVIDER_MODELS

PAGE_QSS = """
    QScrollArea { border: none; background: transparent; }
    QWidget#pageRoot { background: transparent; }
    QPushButton#saveBtn {
        background: #0078d4; color: white; border: none;
        border-radius: 8px; padding: 10px 24px; font-size: 13px;
    }
    QPushButton#saveBtn:hover { background: #106ebe; }
    QComboBox {
        background: #282c34; color: #dcdfe4; border: 1px solid #3a3f4b;
        border-radius: 6px; padding: 6px 10px; min-width: 180px;
    }
    QLineEdit {
        background: #282c34; color: #dcdfe4; border: 1px solid #3a3f4b;
        border-radius: 6px; padding: 6px 10px; min-width: 300px;
    }
    QLineEdit:focus { border-color: #0078d4; }
    #settingLabel { color: #9da5b4; font-size: 12px; min-width: 160px; }
    #settingDesc  { color: #5c6370; font-size: 11px; }
    #savedMsg { color: #98c379; font-size: 12px; }
"""


def _sep():
    f = QFrame()
    f.setFrameShape(QFrame.HLine)
    f.setStyleSheet("background:#2c313a;max-height:1px;border:none;")
    return f


class SettingsPage(QWidget):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self._config = config
        self._setup_ui()
        self.setStyleSheet(PAGE_QSS)

    def _setup_ui(self):
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        root = QWidget()
        root.setObjectName("pageRoot")
        scroll.setWidget(root)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

        main = QVBoxLayout(root)
        main.setContentsMargins(24, 24, 24, 24)
        main.setSpacing(20)

        # Appearance
        app_card = Card("Gorunum")
        av = QVBoxLayout()
        row = QHBoxLayout()
        lbl = QLabel("Tema:")
        lbl.setObjectName("settingLabel")
        self._theme_combo = QComboBox()
        self._theme_combo.addItems(["dark", "light"])
        self._theme_combo.setCurrentText(self._config.get("theme", "dark"))
        row.addWidget(lbl)
        row.addWidget(self._theme_combo)
        row.addStretch()
        av.addLayout(row)
        app_card.add_layout(av)
        main.addWidget(app_card)

        # AI Settings
        ai_card = Card("AI Saglayicisi")
        aiv = QVBoxLayout()
        aiv.setSpacing(12)

        # Provider
        pr = QHBoxLayout()
        pl = QLabel("Saglayici:")
        pl.setObjectName("settingLabel")
        self._provider = QComboBox()
        self._provider.addItems(["", "gemini"])
        self._provider.setCurrentText(self._config.get("ai_provider", ""))
        self._provider.currentTextChanged.connect(self._on_provider_change)
        pr.addWidget(pl)
        pr.addWidget(self._provider)
        pr.addStretch()
        aiv.addLayout(pr)

        # Model
        mr = QHBoxLayout()
        ml = QLabel("Model:")
        ml.setObjectName("settingLabel")
        self._model = QComboBox()
        mr.addWidget(ml)
        mr.addWidget(self._model)
        mr.addStretch()
        aiv.addLayout(mr)

        self._key_rows: dict[str, tuple[QLabel, QLineEdit]] = {}
        for prov in ("gemini",):
            kr = QHBoxLayout()
            kl = QLabel(f"{prov.capitalize()} API Key:")
            kl.setObjectName("settingLabel")
            ki = QLineEdit()
            ki.setEchoMode(QLineEdit.Password)
            ki.setPlaceholderText("sk-...")
            ki.setText(self._config.get(f"{prov}_api_key", ""))
            kr.addWidget(kl)
            kr.addWidget(ki)
            kr.addStretch()
            aiv.addLayout(kr)
            self._key_rows[prov] = (kl, ki)

        ai_card.add_layout(aiv)
        main.addWidget(ai_card)

        # Save button
        btn_row = QHBoxLayout()
        save_btn = QPushButton("Kaydet")
        save_btn.setObjectName("saveBtn")
        save_btn.clicked.connect(self._save)
        btn_row.addWidget(save_btn)
        self._saved_lbl = QLabel("")
        self._saved_lbl.setObjectName("savedMsg")
        btn_row.addWidget(self._saved_lbl)
        btn_row.addStretch()
        main.addLayout(btn_row)

        # About
        about_card = Card("Hakkinda")
        abt = QVBoxLayout()
        for line in [
            "linwas v1.1",
            "Linux'a yeni gecenler icin masaustu yardimcisi.",
            "github.com/mehmedgur/linwas",
        ]:
            l = QLabel(line)
            l.setStyleSheet("color:#9da5b4;font-size:12px;")
            abt.addWidget(l)
        about_card.add_layout(abt)
        main.addWidget(about_card)

        main.addStretch()

        # Init model list
        self._on_provider_change(self._provider.currentText())
        saved_model = self._config.get("ai_model", "")
        if saved_model:
            idx = self._model.findText(saved_model)
            if idx >= 0:
                self._model.setCurrentIndex(idx)

    def _on_provider_change(self, provider: str):
        self._model.clear()
        if provider in PROVIDER_MODELS:
            self._model.addItems(PROVIDER_MODELS[provider])

    def _save(self):
        self._config.set("theme", self._theme_combo.currentText())
        provider = self._provider.currentText()
        self._config.set("ai_provider", provider)
        self._config.set("ai_model",    self._model.currentText())
        for prov, (_, ki) in self._key_rows.items():
            val = ki.text().strip()
            if val:
                self._config.set(f"{prov}_api_key", val)
        self._saved_lbl.setText("Kaydedildi.")
        from PySide6.QtCore import QTimer
        QTimer.singleShot(2000, lambda: self._saved_lbl.setText(""))
