import os
from backend.preloader import DataPreloader
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QGridLayout, QFrame,
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont

from ui.components.card import Card
from ui.components.metric_widget import MetricWidget
from ui.components.worker import run_in_thread
from backend.system import SystemInfo

PAGE_QSS = """
    QScrollArea { border: none; background: transparent; }
    QWidget#pageRoot { background: transparent; }
    #welcomeTitle { color: #dcdfe4; font-size: 22px; font-weight: 700; }
    #welcomeSub   { color: #9da5b4; font-size: 13px; }
    #quickBtn {
        background: #282c34; border: 1px solid #2c313a; border-radius: 8px;
        color: #dcdfe4; font-size: 12px; padding: 12px 8px;
    }
    #quickBtn:hover { background: #2c313a; border-color: #0078d4; }
    #statusOk      { color: #98c379; font-size: 12px; }
    #statusWarn    { color: #e5c07b; font-size: 12px; }
    #statusErr     { color: #e06c75; font-size: 12px; }
    #sectionTitle  { color: #9da5b4; font-size: 11px; font-weight: 600; letter-spacing: 1px; }
"""

QUICK_ACTIONS = [
    ("Sistem Guncelle",   "system",      "updates"),
    ("Program Kur",       "programs",    "programs"),
    ("AI Sor",            "ai",          "ai"),
    ("Sorun Gider",       "troubleshoot","troubleshoot"),
]


class HomePage(QWidget):
    navigate = None  # set by MainWindow

    def __init__(self, config, parent=None):
        super().__init__(parent)
        self._config = config
        self._sysinfo = SystemInfo()
        self._data = {}
        self._refreshing = False
        self._setup_ui()
        self._load_data()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._refresh_live)
        self._timer.start(5000)

    def cleanup(self):
        if hasattr(self, "_timer"):
            self._timer.stop()

    def _setup_ui(self):
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        root = QWidget()
        root.setObjectName("pageRoot")
        scroll.setWidget(root)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

        self._main = QVBoxLayout(root)
        self._main.setContentsMargins(24, 24, 24, 24)
        self._main.setSpacing(20)

        self._build_welcome()
        self._build_metrics()
        self._build_quick_actions()
        self._build_status()
        self._main.addStretch()

        self.setStyleSheet(PAGE_QSS)

    def _build_welcome(self):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)

        col = QVBoxLayout()
        user = os.environ.get("USER", os.environ.get("LOGNAME", "Kullanici"))
        title = QLabel(f"Merhaba, {user}")
        title.setObjectName("welcomeTitle")
        sub = QLabel("Linux masaüstünüz hazir. Nasil yardimci olabilirim?")
        sub.setObjectName("welcomeSub")
        col.addWidget(title)
        col.addWidget(sub)
        h.addLayout(col)
        h.addStretch()

        self._main.addWidget(w)

    def _build_metrics(self):
        card = Card("Sistem Durumu")
        grid = QGridLayout()
        grid.setSpacing(16)

        self._cpu_m   = MetricWidget("CPU",   "-", "%",  show_bar=True)
        self._ram_m   = MetricWidget("RAM",   "-", "GB", show_bar=True)
        self._disk_m  = MetricWidget("Disk",  "-", "GB", show_bar=True)
        self._uptime_m = MetricWidget("Calisma", "-", "sa")

        grid.addWidget(self._cpu_m,    0, 0)
        grid.addWidget(self._ram_m,    0, 1)
        grid.addWidget(self._disk_m,   0, 2)
        grid.addWidget(self._uptime_m, 0, 3)

        card.add_layout(grid)
        self._main.addWidget(card)

    def _build_quick_actions(self):
        sec = QLabel("HIZLI ISLEMLER")
        sec.setObjectName("sectionTitle")
        self._main.addWidget(sec)

        grid = QWidget()
        gl = QHBoxLayout(grid)
        gl.setSpacing(12)
        gl.setContentsMargins(0, 0, 0, 0)

        for label, key, _ in QUICK_ACTIONS:
            btn = QPushButton(label)
            btn.setObjectName("quickBtn")
            btn.setFixedHeight(64)
            btn.clicked.connect(lambda _, k=key: self._navigate(k))
            gl.addWidget(btn)

        self._main.addWidget(grid)

    def _build_status(self):
        self._status_card = Card("Sistem Sagligi")
        self._status_layout = QVBoxLayout()
        self._status_layout.setSpacing(6)
        self._status_card.add_layout(self._status_layout)
        self._status_label = QLabel("Kontrol ediliyor...")
        self._status_label.setObjectName("statusOk")
        self._status_layout.addWidget(self._status_label)
        self._main.addWidget(self._status_card)

    def _load_data(self):
        if self._refreshing:
            return
        self._refreshing = True
        preloader = DataPreloader.instance()
        if preloader.has("system"):
            self._on_data(preloader.get("system"))
            return
        def fetch():
            return self._sysinfo.get_all()
        run_in_thread(fetch, on_done=self._on_data, on_error=lambda _: self._reset_refreshing())

    def _reset_refreshing(self):
        self._refreshing = False

    def _on_data(self, data: dict):
        self._data = data
        self._update_metrics(data)
        self._update_status(data)
        self._refreshing = False

    def _refresh_live(self):
        if self._refreshing:
            return
        self._refreshing = True
        def fetch():
            return {
                "cpu": self._sysinfo.get_cpu_info(),
                "ram": self._sysinfo.get_ram_info(),
                "uptime": self._sysinfo.get_uptime(),
            }
        run_in_thread(fetch, on_done=self._on_live, on_error=lambda _: self._reset_refreshing())

    def _on_live(self, data: dict):
        cpu = data.get("cpu", {})
        ram = data.get("ram", {})
        up  = data.get("uptime", {})
        self._cpu_m.set_value(f"{cpu.get('percent', 0):.0f}", int(cpu.get("percent", 0)))
        self._ram_m.set_value(f"{ram.get('used_gb', 0):.1f}", int(ram.get("percent", 0)))
        self._uptime_m.set_value(f"{up.get('hours', 0)}")
        self._refreshing = False

    def _update_metrics(self, data: dict):
        cpu   = data.get("cpu", {})
        ram   = data.get("ram", {})
        disks = data.get("disks", [])
        up    = data.get("uptime", {})

        self._cpu_m.set_value(f"{cpu.get('percent', 0):.0f}", int(cpu.get("percent", 0)))
        self._ram_m.set_value(f"{ram.get('used_gb', 0):.1f}", int(ram.get("percent", 0)))

        if disks:
            root_disk = next((d for d in disks if d["mountpoint"] == "/"), disks[0])
            self._disk_m.set_value(f"{root_disk['used_gb']:.0f}", int(root_disk["percent"]))
        self._uptime_m.set_value(f"{up.get('hours', 0)}")

    def _update_status(self, data: dict):
        items = []
        updates = data.get("updates", -1)
        internet = data.get("internet", None)

        if internet is False:
            items.append(("statusErr", "Internet baglantisi yok"))
        elif internet is True:
            items.append(("statusOk", "Internet baglantisi aktif"))

        if updates > 0:
            items.append(("statusWarn", f"{updates} sistem guncellemesi mevcut"))
        elif updates == 0:
            items.append(("statusOk", "Sistem guncel"))

        for i in reversed(range(self._status_layout.count())):
            self._status_layout.itemAt(i).widget().deleteLater()

        if not items:
            lbl = QLabel("Her sey normal gorunuyor")
            lbl.setObjectName("statusOk")
            self._status_layout.addWidget(lbl)
        else:
            for obj, text in items:
                lbl = QLabel(text)
                lbl.setObjectName(obj)
                self._status_layout.addWidget(lbl)

    def _navigate(self, key: str):
        if self.navigate:
            self.navigate(key)
