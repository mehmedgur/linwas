from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QGridLayout, QProgressBar,
)
from PySide6.QtCore import Qt, QTimer

from backend.preloader import DataPreloader
from ui.components.card import Card
from ui.components.metric_widget import MetricWidget
from ui.components.status_badge import StatusBadge
from ui.components.worker import run_in_thread
from backend.system import SystemInfo
from services.network_service import NetworkService
from services.bluetooth_service import BluetoothService

PAGE_QSS = """
    QScrollArea { border: none; background: transparent; }
    QWidget#pageRoot { background: transparent; }
    #infoKey   { color: #9da5b4; font-size: 12px; }
    #infoVal   { color: #dcdfe4; font-size: 12px; font-weight: 600; }
    #sectionTitle { color: #9da5b4; font-size: 11px; font-weight: 600; letter-spacing: 1px; }
    QPushButton#refreshBtn {
        background: #282c34; border: 1px solid #3a3f4b; border-radius: 6px;
        color: #9da5b4; font-size: 12px; padding: 6px 14px;
    }
    QPushButton#refreshBtn:hover { background: #2c313a; color: #dcdfe4; }
"""


def _info_row(key: str, val: str) -> QWidget:
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 0, 0, 0)
    k = QLabel(key)
    k.setObjectName("infoKey")
    k.setFixedWidth(150)
    v = QLabel(val)
    v.setObjectName("infoVal")
    v.setWordWrap(True)
    h.addWidget(k)
    h.addWidget(v, 1)
    return w


class SystemPage(QWidget):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self._config = config
        self._sysinfo = SystemInfo()
        self._net     = NetworkService()
        self._bt      = BluetoothService()
        self._refreshing = False
        self._setup_ui()
        self._load_data()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._refresh_live)
        self._timer.start(4000)
        self.setStyleSheet(PAGE_QSS)

    def cleanup(self):
        if hasattr(self, "_timer"):
            self._timer.stop()

    def _setup_ui(self):
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        root = QWidget()
        root.setObjectName("pageRoot")
        scroll.setWidget(root)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

        self._main = QVBoxLayout(root)
        self._main.setContentsMargins(24, 24, 24, 24)
        self._main.setSpacing(20)

        # Refresh button
        top = QHBoxLayout()
        top.addStretch()
        ref = QPushButton("Yenile")
        ref.setObjectName("refreshBtn")
        ref.clicked.connect(self._load_data)
        top.addWidget(ref)
        self._main.addLayout(top)

        # Live metrics
        metrics_card = Card("Canli Metrikler")
        mg = QGridLayout()
        mg.setSpacing(16)
        self._cpu_m   = MetricWidget("CPU Kullanimi", "-", "%",  show_bar=True)
        self._ram_m   = MetricWidget("RAM",           "-", "GB", show_bar=True)
        self._disk_m  = MetricWidget("Disk (/)",      "-", "GB", show_bar=True)
        self._up_m    = MetricWidget("Calisma Suresi","-", "sa")
        mg.addWidget(self._cpu_m,  0, 0)
        mg.addWidget(self._ram_m,  0, 1)
        mg.addWidget(self._disk_m, 0, 2)
        mg.addWidget(self._up_m,   0, 3)
        metrics_card.add_layout(mg)
        self._main.addWidget(metrics_card)

        # CPU info card
        self._cpu_card = Card("Islemci")
        self._cpu_vbox = QVBoxLayout()
        self._cpu_card.add_layout(self._cpu_vbox)
        self._main.addWidget(self._cpu_card)

        # GPU card
        self._gpu_card = Card("Ekran Karti")
        self._gpu_vbox = QVBoxLayout()
        self._gpu_card.add_layout(self._gpu_vbox)
        self._main.addWidget(self._gpu_card)

        # OS info
        self._os_card = Card("Isletim Sistemi")
        self._os_vbox = QVBoxLayout()
        self._os_card.add_layout(self._os_vbox)
        self._main.addWidget(self._os_card)

        # Network card
        self._net_card = Card("Ag")
        self._net_vbox = QVBoxLayout()
        self._net_card.add_layout(self._net_vbox)
        self._main.addWidget(self._net_card)

        self._main.addStretch()

    def _load_data(self):
        preloader = DataPreloader.instance()
        if preloader.has("system"):
            self._on_data(preloader.get("system"))
        else:
            run_in_thread(self._sysinfo.get_all, on_done=self._on_data)
        if preloader.has("network"):
            self._on_net(preloader.get("network"))
        else:
            run_in_thread(self._net.get_ip_info, on_done=self._on_net)

    def _reset_refreshing(self):
        self._refreshing = False

    def _on_data(self, data: dict):
        cpu   = data.get("cpu", {})
        ram   = data.get("ram", {})
        disks = data.get("disks", [])
        gpu   = data.get("gpu", {})
        os    = data.get("os", {})
        up    = data.get("uptime", {})

        self._cpu_m.set_value(f"{cpu.get('percent', 0):.0f}", int(cpu.get("percent", 0)))
        self._ram_m.set_value(f"{ram.get('used_gb', 0):.1f}", int(ram.get("percent", 0)))
        root = next((d for d in disks if d["mountpoint"] == "/"), disks[0] if disks else {})
        if root:
            self._disk_m.set_value(f"{root.get('used_gb', 0):.0f}", int(root.get("percent", 0)))
        self._up_m.set_value(f"{up.get('hours', 0)}")

        for layout in (self._cpu_vbox, self._gpu_vbox, self._os_vbox):
            for i in reversed(range(layout.count())):
                w = layout.itemAt(i).widget()
                if w:
                    w.deleteLater()

        self._cpu_vbox.addWidget(_info_row("Model:", cpu.get("name", "-")))
        self._cpu_vbox.addWidget(_info_row("Cekirdek Sayisi:", str(cpu.get("count", "-"))))
        self._cpu_vbox.addWidget(_info_row("Frekans:", f"{cpu.get('freq_mhz', 0):.0f} MHz"))
        self._cpu_vbox.addWidget(_info_row("RAM Toplam:", f"{ram.get('total_gb', 0):.1f} GB"))

        self._gpu_vbox.addWidget(_info_row("Model:", gpu.get("name", "-")))
        if gpu.get("type") == "nvidia":
            self._gpu_vbox.addWidget(_info_row("Kullanim:", f"{gpu.get('util_percent', 0):.0f}%"))
            self._gpu_vbox.addWidget(_info_row("VRAM:", f"{gpu.get('vram_used_mb', 0):.0f}/{gpu.get('vram_total_mb', 0):.0f} MB"))

        self._os_vbox.addWidget(_info_row("Sistem:", os.get("name", "-")))
        self._os_vbox.addWidget(_info_row("Surum:", os.get("version", "-")))
        self._os_vbox.addWidget(_info_row("Kernel:", data.get("kernel", "-")))
        self._os_vbox.addWidget(_info_row("Makine Adi:", data.get("host", "-")))
        updates = data.get("updates", -1)
        up_text = f"{updates} guncelleme mevcut" if updates > 0 else "Guncel" if updates == 0 else "Kontrol edilemedi"
        self._os_vbox.addWidget(_info_row("Guncellemeler:", up_text))

        for d in disks:
            self._os_vbox.addWidget(_info_row(
                f"Disk ({d['mountpoint']}):",
                f"{d['used_gb']:.1f}/{d['total_gb']:.1f} GB (%{d['percent']:.0f})"
            ))

    def _on_net(self, ifaces: dict):
        for i in reversed(range(self._net_vbox.count())):
            w = self._net_vbox.itemAt(i).widget()
            if w:
                w.deleteLater()
        if not ifaces:
            self._net_vbox.addWidget(QLabel("Ag arayuzu bulunamadi"))
            return
        for name, info in ifaces.items():
            self._net_vbox.addWidget(_info_row(name, f"{info['ip']} ({info['state']})"))

    def _refresh_live(self):
        if self._refreshing:
            return
        self._refreshing = True
        def fetch():
            return {
                "cpu":    self._sysinfo.get_cpu_info(),
                "ram":    self._sysinfo.get_ram_info(),
                "uptime": self._sysinfo.get_uptime(),
            }
        run_in_thread(fetch, on_done=self._on_live, on_error=lambda _: self._reset_refreshing())

    def _on_live(self, d: dict):
        self._cpu_m.set_value(f"{d['cpu'].get('percent',0):.0f}", int(d['cpu'].get('percent',0)))
        self._ram_m.set_value(f"{d['ram'].get('used_gb',0):.1f}", int(d['ram'].get('percent',0)))
        self._up_m.set_value(f"{d['uptime'].get('hours',0)}")
        self._refreshing = False
