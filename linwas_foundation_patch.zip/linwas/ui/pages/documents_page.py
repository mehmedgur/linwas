from pathlib import Path
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QTextEdit, QScrollArea,
)
from PySide6.QtCore import Qt

from ui.components.card import Card
from ui.components.status_badge import StatusBadge
from ui.components.worker import run_in_thread
from backend.documents import DocumentsBackend, SUPPORTED
from services.office_service import OfficeService
from backend.command_executor import CommandExecutor
from backend.task_manager import TaskManager

PAGE_QSS = """
    QWidget { background: transparent; }
    QScrollArea { border: none; background: transparent; }
    QPushButton#mainBtn {
        background: #0078d4; color: white; border: none;
        border-radius: 8px; padding: 10px 20px; font-size: 13px;
    }
    QPushButton#mainBtn:hover { background: #106ebe; }
    QPushButton#secBtn {
        background: #3a3f4b; color: #dcdfe4; border: none;
        border-radius: 8px; padding: 10px 20px; font-size: 13px;
    }
    QTextEdit {
        background: #282c34; color: #abb2bf; border: 1px solid #2c313a;
        border-radius: 8px; font-size: 12px;
    }
    #dropZone {
        background: #21252b; border: 2px dashed #3a3f4b;
        border-radius: 12px; color: #5c6370; font-size: 14px;
    }
    #dropZone:hover { border-color: #0078d4; color: #9da5b4; }
    #infoKey { color: #9da5b4; font-size: 12px; }
    #infoVal { color: #dcdfe4; font-size: 12px; font-weight: 600; }
"""


def _row(key, val):
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 2, 0, 2)
    k = QLabel(key)
    k.setObjectName("infoKey")
    k.setFixedWidth(160)
    v = QLabel(str(val))
    v.setObjectName("infoVal")
    v.setWordWrap(True)
    h.addWidget(k)
    h.addWidget(v, 1)
    return w


class DocumentsPage(QWidget):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self._config = config
        self._docs   = DocumentsBackend()
        self._exec   = CommandExecutor()
        self._tm     = TaskManager()
        self._svc    = OfficeService(self._exec, self._tm)
        self._file_path: str | None = None
        self._setup_ui()
        self.setStyleSheet(PAGE_QSS)

    def _setup_ui(self):
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        root = QWidget()
        scroll.setWidget(root)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

        main = QVBoxLayout(root)
        main.setContentsMargins(24, 24, 24, 24)
        main.setSpacing(20)

        # File selection
        sel_card = Card("Belge Sec")
        sv = QVBoxLayout()
        info = QLabel(f"Desteklenen formatlar: {', '.join(sorted(SUPPORTED))}")
        info.setStyleSheet("color:#9da5b4;font-size:12px;")
        sv.addWidget(info)

        self._file_label = QLabel("Secilen belge: yok")
        self._file_label.setStyleSheet("color:#dcdfe4;font-size:13px;font-weight:600;")
        sv.addWidget(self._file_label)

        btn_row = QHBoxLayout()
        sel_btn = QPushButton("Belge Sec")
        sel_btn.setObjectName("secBtn")
        sel_btn.clicked.connect(self._select_file)
        btn_row.addWidget(sel_btn)

        self._analyse_btn = QPushButton("Analiz Et")
        self._analyse_btn.setObjectName("mainBtn")
        self._analyse_btn.setEnabled(False)
        self._analyse_btn.clicked.connect(self._analyse)
        btn_row.addWidget(self._analyse_btn)

        self._pdf_btn = QPushButton("PDF'e Donustur")
        self._pdf_btn.setObjectName("secBtn")
        self._pdf_btn.setEnabled(False)
        self._pdf_btn.clicked.connect(self._to_pdf)
        btn_row.addWidget(self._pdf_btn)
        btn_row.addStretch()
        sv.addLayout(btn_row)
        sel_card.add_layout(sv)
        main.addWidget(sel_card)

        # Analysis results
        self._result_card = Card("Analiz Sonucu")
        self._result_vbox = QVBoxLayout()
        placeholder = QLabel("Bir belge secerek analiz baslatin.")
        placeholder.setStyleSheet("color:#5c6370;font-size:12px;")
        self._result_vbox.addWidget(placeholder)
        self._result_card.add_layout(self._result_vbox)
        main.addWidget(self._result_card)

        # Recent files
        recent_card = Card("Son Belgeler")
        rv = QVBoxLayout()
        self._recent_vbox = rv
        recent_card.add_layout(rv)
        main.addWidget(recent_card)
        self._load_recent()

        main.addStretch()

    def _select_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Belge Sec", str(Path.home()),
            f"Belgeler (*{' *'.join(SUPPORTED)});;Tum Dosyalar (*)"
        )
        if path:
            self._file_path = path
            self._file_label.setText(f"Secilen: {Path(path).name}")
            self._analyse_btn.setEnabled(True)
            self._pdf_btn.setEnabled(Path(path).suffix.lower() in {".docx", ".doc", ".odt", ".xlsx", ".pptx"})

    def _analyse(self):
        if not self._file_path:
            return
        self._analyse_btn.setEnabled(False)
        run_in_thread(
            lambda: self._docs.analyse(self._file_path),
            on_done=self._show_results,
            on_error=lambda e: self._show_error(e)
        )

    def _show_results(self, data: dict):
        self._analyse_btn.setEnabled(True)
        for i in reversed(range(self._result_vbox.count())):
            w = self._result_vbox.itemAt(i).widget()
            if w:
                w.deleteLater()

        if "error" in data:
            self._result_vbox.addWidget(QLabel(f"Hata: {data['error']}"))
            return

        self._result_vbox.addWidget(_row("Dosya adi:",   data.get("name", "-")))
        self._result_vbox.addWidget(_row("Format:",      data.get("ext", "-")))
        self._result_vbox.addWidget(_row("Boyut:",       f"{data.get('size_kb', 0):.1f} KB"))
        self._result_vbox.addWidget(_row("MS Formati:",  "Evet" if data.get("ms_format") else "Hayir"))
        self._result_vbox.addWidget(_row("LibreOffice:", "Kurulu" if data.get("libreoffice") else "Kurulu degil"))
        self._result_vbox.addWidget(_row("Font durumu:", "Tamam" if data.get("fonts_ok") else "Eksik font var"))

        for warning in data.get("warnings", []):
            w = QLabel(f"Uyari: {warning}")
            w.setStyleSheet("color:#e5c07b;font-size:12px;")
            w.setWordWrap(True)
            self._result_vbox.addWidget(w)

        missing = data.get("missing_fonts", [])
        if missing:
            self._result_vbox.addWidget(_row("Eksik fontlar:", ", ".join(missing)))

    def _show_error(self, error: str):
        self._analyse_btn.setEnabled(True)
        for i in reversed(range(self._result_vbox.count())):
            w = self._result_vbox.itemAt(i).widget()
            if w:
                w.deleteLater()
        self._result_vbox.addWidget(QLabel(f"Hata: {error}"))

    def _to_pdf(self):
        if not self._file_path:
            return
        self._pdf_btn.setEnabled(False)
        run_in_thread(
            lambda: self._svc.convert_to_pdf(self._file_path),
            on_done=lambda r: (
                self._pdf_btn.setEnabled(True),
                self._show_pdf_result(r)
            )
        )

    def _show_pdf_result(self, result: tuple):
        ok, msg = result
        lbl = QLabel(f"PDF: {msg}" if ok else f"Donusturme hatasi: {msg}")
        lbl.setStyleSheet(f"color:{'#98c379' if ok else '#e06c75'};font-size:12px;")
        self._result_vbox.addWidget(lbl)

    def _load_recent(self):
        run_in_thread(
            self._docs.list_recent,
            on_done=self._show_recent
        )

    def _show_recent(self, files: list):
        for i in reversed(range(self._recent_vbox.count())):
            w = self._recent_vbox.itemAt(i).widget()
            if w:
                w.deleteLater()

        if not files:
            self._recent_vbox.addWidget(QLabel("Son belge bulunamadi."))
            return

        for f in files[:8]:
            row = QWidget()
            h = QHBoxLayout(row)
            h.setContentsMargins(0, 2, 0, 2)
            lbl = QLabel(f["name"])
            lbl.setStyleSheet("color:#dcdfe4;font-size:12px;")
            h.addWidget(lbl, 1)
            btn = QPushButton("Ac")
            btn.setStyleSheet("QPushButton{background:#3a3f4b;color:#dcdfe4;border:none;border-radius:4px;padding:4px 10px;font-size:11px;}")
            btn.clicked.connect(lambda _, p=f["path"]: self._open_file(p))
            h.addWidget(btn)
            self._recent_vbox.addWidget(row)

    def _open_file(self, path: str):
        self._file_path = path
        self._file_label.setText(f"Secilen: {Path(path).name}")
        self._analyse_btn.setEnabled(True)
        self._analyse()
