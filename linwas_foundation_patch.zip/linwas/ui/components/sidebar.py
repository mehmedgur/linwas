from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QFrame,
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont

SIDEBAR_QSS = """
    #sidebar {
        background: #21252b;
        border-right: 1px solid #181a1f;
    }
    #appName {
        color: #0078d4;
        font-size: 20px;
        font-weight: 800;
        letter-spacing: 3px;
    }
    #sidebarSep {
        background: #2c313a;
        max-height: 1px;
        border: none;
    }
    #navBtn {
        text-align: left;
        padding: 9px 14px;
        border: none;
        border-radius: 6px;
        color: #9da5b4;
        font-size: 13px;
        background: transparent;
    }
    #navBtn:hover  { background: #2c313a; color: #dcdfe4; }
    #navBtn:checked { background: #0078d4; color: #ffffff; }
"""

NAV_ITEMS = [
    ("Ana Sayfa",      "home"),
    ("AI Asistan",     "ai"),
    ("Sistem",         "system"),
    ("Programlar",     "programs"),
    ("Wine / EXE",     "wine"),
    ("Belgeler",       "documents"),
    ("Sorun Giderme",  "troubleshoot"),
    ("Guvenlik",       "security"),
    ("Ayarlar",        "settings"),
]


class Sidebar(QWidget):
    page_changed = Signal(int, str, str)  # index, display-name, key

    def __init__(self, pages: list, parent=None):
        super().__init__(parent)
        self.setObjectName("sidebar")
        self.setFixedWidth(205)
        self._pages = pages
        self._buttons: list[QPushButton] = []
        self._build()
        self.setStyleSheet(SIDEBAR_QSS)

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ---- header ----
        header = QWidget()
        header.setObjectName("sidebar")
        header.setFixedHeight(64)
        h = QVBoxLayout(header)
        h.setAlignment(Qt.AlignCenter)
        logo = QLabel("linwas")
        logo.setObjectName("appName")
        logo.setAlignment(Qt.AlignCenter)
        font = logo.font()
        font.setWeight(QFont.Weight.ExtraBold)
        logo.setFont(font)
        h.addWidget(logo)
        layout.addWidget(header)

        sep = QFrame()
        sep.setObjectName("sidebarSep")
        sep.setFrameShape(QFrame.Shape.HLine)
        layout.addWidget(sep)

        # ---- nav buttons ----
        nav = QWidget()
        nav.setObjectName("sidebar")
        nv = QVBoxLayout(nav)
        nv.setContentsMargins(8, 8, 8, 8)
        nv.setSpacing(2)

        settings_idx = next((i for i, (_, k, _) in enumerate(self._pages) if k == "settings"), None)

        for i, (name, key, _) in enumerate(self._pages):
            if i == settings_idx:
                nv.addStretch()
                sep2 = QFrame()
                sep2.setObjectName("sidebarSep")
                sep2.setFrameShape(QFrame.Shape.HLine)
                nv.addWidget(sep2)

            btn = QPushButton(name)
            btn.setObjectName("navBtn")
            btn.setCheckable(True)
            btn.setFixedHeight(40)
            btn.clicked.connect(lambda _, idx=i, n=name, k=key: self._select(idx, n, k))
            self._buttons.append(btn)
            nv.addWidget(btn)

        layout.addWidget(nav)
        if settings_idx is None:
            layout.addStretch()

        if self._buttons:
            self._select(0, self._pages[0][0], self._pages[0][1])

    def _select(self, index: int, name: str, key: str):
        for i, btn in enumerate(self._buttons):
            btn.setChecked(i == index)
        self.page_changed.emit(index, name, key)

    def select_key(self, key: str):
        for i, (_, k, _) in enumerate(self._pages):
            if k == key:
                self._select(i, self._pages[i][0], k)
                return
