from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QProgressBar
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont


class MetricWidget(QWidget):
    def __init__(self, label: str, value: str = "-", unit: str = "", show_bar: bool = False, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        self._label_w = QLabel(label)
        self._label_w.setObjectName("metricLabel")
        layout.addWidget(self._label_w)

        val_row = QHBoxLayout()
        self.value_label = QLabel(value)
        self.value_label.setObjectName("metricValue")
        font = self.value_label.font()
        font.setPointSize(20)
        font.setWeight(QFont.Weight.Bold)
        self.value_label.setFont(font)
        val_row.addWidget(self.value_label)

        if unit:
            ul = QLabel(unit)
            ul.setObjectName("metricUnit")
            ul.setAlignment(Qt.AlignBottom)
            val_row.addWidget(ul)
        val_row.addStretch()
        layout.addLayout(val_row)

        if show_bar:
            self.bar = QProgressBar()
            self.bar.setObjectName("metricBar")
            self.bar.setRange(0, 100)
            self.bar.setValue(0)
            self.bar.setTextVisible(False)
            self.bar.setFixedHeight(6)
            layout.addWidget(self.bar)
        else:
            self.bar = None

        self.setStyleSheet("""
            QLabel#metricLabel { color: #9da5b4; font-size: 11px; }
            QLabel#metricValue { color: #dcdfe4; }
            QLabel#metricUnit  { color: #9da5b4; font-size: 11px; margin-bottom: 4px; }
            QProgressBar#metricBar {
                border: none; border-radius: 3px; background: #3a3f4b;
            }
            QProgressBar#metricBar::chunk { border-radius: 3px; background: #0078d4; }
        """)

    def set_value(self, value: str, percent: int = -1):
        self.value_label.setText(value)
        if self.bar and percent >= 0:
            self.bar.setValue(min(100, max(0, percent)))
            color = "#e06c75" if percent > 90 else "#e5c07b" if percent > 70 else "#0078d4"
            self.bar.setStyleSheet(f"""
                QProgressBar {{border:none;border-radius:3px;background:#3a3f4b;}}
                QProgressBar::chunk {{border-radius:3px;background:{color};}}
            """)
