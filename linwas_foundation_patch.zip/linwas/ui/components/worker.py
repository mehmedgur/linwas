from PySide6.QtCore import QThread, Signal, QObject

ACTIVE_THREADS: list[QThread] = []


class Worker(QObject):
    finished = Signal(object)
    error = Signal(str)
    progress = Signal(int, str)

    def __init__(self, fn, *args, **kwargs):
        super().__init__()
        self._fn = fn
        self._args = args
        self._kwargs = kwargs

    def run(self):
        try:
            result = self._fn(*self._args, **self._kwargs)
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))


def run_in_thread(fn, *args, on_done=None, on_error=None, **kwargs):
    thread = QThread()
    worker = Worker(fn, *args, **kwargs)
    worker.moveToThread(thread)
    thread.started.connect(worker.run)

    if on_done:
        worker.finished.connect(on_done)
    if on_error:
        worker.error.connect(on_error)

    worker.finished.connect(thread.quit)
    worker.error.connect(thread.quit)
    worker.finished.connect(worker.deleteLater)
    worker.error.connect(worker.deleteLater)

    def _cleanup():
        if thread in ACTIVE_THREADS:
            ACTIVE_THREADS.remove(thread)
        thread.deleteLater()

    thread.finished.connect(_cleanup)

    ACTIVE_THREADS.append(thread)
    thread.start()
    return thread, worker


def stop_all_threads(timeout_ms: int = 3000):
    """Wait for all active threads to finish. Called on app shutdown."""
    for thread in list(ACTIVE_THREADS):
        if thread.isRunning():
            thread.quit()
            thread.wait(timeout_ms)
    ACTIVE_THREADS.clear()
