from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel
from PySide6.QtGui import QFont

CARD_STYLE = """
    Card {
        background: #282c34;
        border-radius: 8px;
        border: 1px solid #2c313a;
    }
    Card[dark="false"] {
        background: #ffffff;
        border: 1px solid #e0e0e0;
    }
    QLabel#cardTitle {
        color: #dcdfe4;
        font-size: 12px;
        font-weight: 600;
    }
"""


class Card(QFrame):
    def __init__(self, title: str = "", parent=None):
        super().__init__(parent)
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(16, 14, 16, 16)
        self._layout.setSpacing(10)
        self.setStyleSheet(CARD_STYLE)

        if title:
            lbl = QLabel(title)
            lbl.setObjectName("cardTitle")
            font = lbl.font()
            font.setPointSize(11)
            font.setWeight(QFont.Weight.Medium)
            lbl.setFont(font)
            self._layout.addWidget(lbl)

    def content_layout(self):
        return self._layout

    def add_widget(self, widget):
        self._layout.addWidget(widget)

    def add_layout(self, layout):
        self._layout.addLayout(layout)
