from PySide6.QtWidgets import QLabel
from PySide6.QtCore import Qt

COLORS = {
    "ok":      ("#61afef", "#1a3a5c"),
    "good":    ("#98c379", "#1a3a1a"),
    "warning": ("#e5c07b", "#4a3a00"),
    "error":   ("#e06c75", "#4a1a1a"),
    "info":    ("#56b6c2", "#0a2a2a"),
    "neutral": ("#9da5b4", "#2c313a"),
}


class StatusBadge(QLabel):
    def __init__(self, text: str = "", status: str = "neutral", parent=None):
        super().__init__(text, parent)
        self.setAlignment(Qt.AlignCenter)
        self.set_status(status, text)

    def set_status(self, status: str, text: str = None):
        if text is not None:
            self.setText(text)
        fg, bg = COLORS.get(status, COLORS["neutral"])
        self.setStyleSheet(f"""
            QLabel {{
                color: {fg};
                background: {bg};
                border-radius: 4px;
                padding: 2px 8px;
                font-size: 11px;
                font-weight: 600;
            }}
        """)
