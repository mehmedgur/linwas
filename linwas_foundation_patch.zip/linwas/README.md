# linwas

**Linux Yardım Merkezi** — Windows'tan Linux'a geçenler için terminal gerektirmeyen, rehberli, güvenli masaüstü uygulaması.

## Özellikler

| Modül | Açıklama |
|-------|----------|
| Ana Sayfa | CPU/RAM/Disk metrikleri, sistem sağlığı, hızlı işlemler |
| AI Asistan | Claude/OpenAI/Gemini ile doğal dil yardım |
| Sistem | Donanım bilgisi, ağ, servis durumu |
| Programlar | APT ve Flatpak paket yönetimi |
| Wine / EXE | Windows programı çalıştırma, Linux alternatif önerileri |
| Belgeler | Office dosya analizi, font kontrolü, PDF dönüştürme |
| Sorun Giderme | İnternet, ses, bluetooth, disk, servis kontrolleri |
| Güvenlik | UFW, açık port, güvenlik önerileri |
| Ayarlar | Tema, AI sağlayıcı, API key yönetimi |

## Kurulum

```bash
sudo bash setup.sh
```

## Çalıştırma

```bash
python3 main.py
```

## Gereksinimler

- Python 3.10+
- PySide6
- psutil
- İsteğe bağlı: `anthropic`, `openai`, `google-generativeai`

## Güvenlik Mimarisi

AI doğrudan sistem komutu çalıştırmaz. Akış:

```
AI öneri verir → action_planner analiz eder
→ permission_manager kullanıcıya gösterir
→ kullanıcı onay verir → command_executor çalıştırır
```

Tüm komutlar beyaz listede (whitelist) denetlenir.

## Lisans

MIT


## Snapshot politikası

- Tam snapshot alınır.
- Toplam limit: 250 MB.
- Snapshotlar 7 gün sonra silinir.
- Aynı dosyanın eski snapshotı yeni snapshot alınırken silinir.

## Log politikası

- Plaintext log tutulur.
- 7 günden eski loglar otomatik temizlenir.
