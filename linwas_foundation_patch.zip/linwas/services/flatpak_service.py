from backend.command_executor import CommandExecutor
from backend.task_manager import TaskManager


class FlatpakService:
    def __init__(self, executor: CommandExecutor, task_mgr: TaskManager):
        self._ex = executor
        self._tm = task_mgr

    def install(self, app_id: str, on_update=None) -> tuple[bool, str]:
        task = self._tm.create(f"Flatpak kuruluyor: {app_id}", on_update)
        self._tm.start(task)
        try:
            ok, out, err = self._ex.run(
                ["flatpak", "install", "-y", "--noninteractive", app_id],
                timeout=300
            )
        except Exception as e:
            self._tm.fail(task, str(e))
            return False, str(e)
        if ok:
            self._tm.finish(task, f"'{app_id}' kuruldu")
        else:
            self._tm.fail(task, err[:300])
        return ok, out + err

    def remove(self, app_id: str, on_update=None) -> tuple[bool, str]:
        task = self._tm.create(f"Flatpak kaldırılıyor: {app_id}", on_update)
        self._tm.start(task)
        try:
            ok, out, err = self._ex.run(
                ["flatpak", "remove", "-y", app_id], timeout=60
            )
        except Exception as e:
            self._tm.fail(task, str(e))
            return False, str(e)
        if ok:
            self._tm.finish(task, f"'{app_id}' kaldırıldı")
        else:
            self._tm.fail(task, err[:300])
        return ok, out + err

    def update_all(self, on_update=None) -> tuple[bool, str]:
        task = self._tm.create("Flatpak uygulamaları güncelleniyor", on_update)
        self._tm.start(task)
        try:
            ok, out, err = self._ex.run(
                ["flatpak", "update", "-y"], timeout=300
            )
        except Exception as e:
            self._tm.fail(task, str(e))
            return False, str(e)
        if ok:
            self._tm.finish(task, "Flatpak güncellendi")
        else:
            self._tm.fail(task, err[:300])
        return ok, out + err
