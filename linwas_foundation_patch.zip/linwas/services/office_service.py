from backend.documents import DocumentsBackend
from backend.command_executor import CommandExecutor
from backend.task_manager import TaskManager


class OfficeService:
    def __init__(self, executor: CommandExecutor, task_mgr: TaskManager):
        self._ex = executor
        self._tm = task_mgr
        self.docs = DocumentsBackend()

    def install_libreoffice(self, on_update=None) -> tuple[bool, str]:
        task = self._tm.create("LibreOffice kuruluyor", on_update)
        self._tm.start(task)
        try:
            ok, out, err = self._ex.run(
                ["apt-get", "install", "-y", "libreoffice"],
                use_pkexec=True, timeout=300
            )
        except Exception as e:
            self._tm.fail(task, str(e))
            return False, str(e)
        if ok:
            self._tm.finish(task, "LibreOffice kuruldu")
        else:
            self._tm.fail(task, err[:300])
        return ok, out + err

    def convert_to_pdf(self, path: str) -> tuple[bool, str]:
        return self.docs.convert_to_pdf(path)

    def analyse(self, path: str) -> dict:
        return self.docs.analyse(path)
