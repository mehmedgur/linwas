from backend.command_executor import CommandExecutor
from backend.task_manager import TaskManager, Task


class AptService:
    def __init__(self, executor: CommandExecutor, task_mgr: TaskManager):
        self._ex = executor
        self._tm = task_mgr

    def install(self, package: str, on_update=None) -> tuple[bool, str]:
        task = self._tm.create(f"Kuruluyor: {package}", on_update)
        self._tm.start(task)
        ok, out, err = True, "", ""
        try:
            ok, out, err = self._ex.run(["apt-get", "update"], use_pkexec=True, timeout=60)
            if not ok:
                self._tm.fail(task, err[:300])
                return False, err
            task.update(progress=40, message="Paket kuruluyor...")
            ok, out, err = self._ex.run(
                ["apt-get", "install", "-y", package], use_pkexec=True, timeout=120
            )
        except Exception as e:
            self._tm.fail(task, str(e))
            return False, str(e)
        if ok:
            self._tm.finish(task, f"'{package}' kuruldu")
        else:
            self._tm.fail(task, err[:300])
        return ok, out + err

    def remove(self, package: str, on_update=None) -> tuple[bool, str]:
        task = self._tm.create(f"Kaldırılıyor: {package}", on_update)
        self._tm.start(task)
        try:
            ok, out, err = self._ex.run(
                ["apt-get", "remove", "-y", package], use_pkexec=True, timeout=120
            )
        except Exception as e:
            self._tm.fail(task, str(e))
            return False, str(e)
        if ok:
            self._tm.finish(task, f"'{package}' kaldırıldı")
        else:
            self._tm.fail(task, err[:300])
        return ok, out + err

    def update(self, on_update=None) -> tuple[bool, str]:
        task = self._tm.create("Sistem güncelleniyor", on_update)
        self._tm.start(task)
        try:
            ok, out, err = self._ex.run(["apt-get", "update"], use_pkexec=True, timeout=90)
            if not ok:
                self._tm.fail(task, err[:300])
                return False, err
            task.update(progress=50, message="Paketler güncelleniyor...")
            ok, out, err = self._ex.run(
                ["apt-get", "upgrade", "-y"], use_pkexec=True, timeout=300
            )
        except Exception as e:
            self._tm.fail(task, str(e))
            return False, str(e)
        if ok:
            self._tm.finish(task, "Sistem güncellendi")
        else:
            self._tm.fail(task, err[:300])
        return ok, out + err
