import subprocess
import re


class NetworkService:
    def list_connections(self) -> list[dict]:
        try:
            r = subprocess.run(
                ["nmcli", "-t", "-f", "NAME,TYPE,STATE,DEVICE", "connection", "show", "--active"],
                capture_output=True, text=True, timeout=5
            )
            results = []
            for line in r.stdout.splitlines():
                parts = line.split(":")
                if len(parts) >= 4:
                    results.append({
                        "name":   parts[0],
                        "type":   parts[1],
                        "state":  parts[2],
                        "device": parts[3],
                    })
            return results
        except Exception:
            return []

    def list_wifi(self) -> list[dict]:
        try:
            r = subprocess.run(
                ["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY,ACTIVE", "dev", "wifi"],
                capture_output=True, text=True, timeout=8
            )
            results = []
            for line in r.stdout.splitlines():
                parts = line.split(":")
                if len(parts) >= 4 and parts[0]:
                    results.append({
                        "ssid":     parts[0],
                        "signal":   int(parts[1]) if parts[1].isdigit() else 0,
                        "security": parts[2],
                        "active":   parts[3].lower() == "yes",
                    })
            return sorted(results, key=lambda x: x["signal"], reverse=True)
        except Exception:
            return []

    def get_ip_info(self) -> dict:
        try:
            r = subprocess.run(["ip", "-brief", "addr"], capture_output=True, text=True, timeout=5)
            interfaces = {}
            for line in r.stdout.splitlines():
                parts = line.split()
                if len(parts) >= 3 and parts[0] != "lo":
                    interfaces[parts[0]] = {
                        "state": parts[1],
                        "ip":    parts[2].split("/")[0] if len(parts) > 2 else "",
                    }
            return interfaces
        except Exception:
            return {}
