from backend.wine_helper import WineHelper
from backend.command_executor import CommandExecutor
from backend.task_manager import TaskManager


class WineService:
    def __init__(self, executor: CommandExecutor, task_mgr: TaskManager):
        self._ex = executor
        self._tm = task_mgr
        self.helper = WineHelper()

    def install_wine(self, on_update=None) -> tuple[bool, str]:
        task = self._tm.create("Wine kuruluyor", on_update)
        self._tm.start(task)
        try:
            ok, out, err = self._ex.run(
                ["apt-get", "install", "-y", "wine", "winetricks"],
                use_pkexec=True, timeout=300
            )
        except Exception as e:
            self._tm.fail(task, str(e))
            return False, str(e)
        if ok:
            self._tm.finish(task, "Wine kuruldu")
        else:
            self._tm.fail(task, err[:300])
        return ok, out + err

    def run_exe(self, path: str) -> tuple[bool, str]:
        return self.helper.run_exe(path)
