import subprocess


class BluetoothService:
    def is_available(self) -> bool:
        try:
            r = subprocess.run(
                ["systemctl", "is-active", "bluetooth"],
                capture_output=True, text=True, timeout=3
            )
            return r.stdout.strip() == "active"
        except Exception:
            return False

    def list_paired(self) -> list[dict]:
        try:
            r = subprocess.run(
                ["bluetoothctl", "devices"],
                capture_output=True, text=True, timeout=5
            )
            devices = []
            for line in r.stdout.splitlines():
                # Format: Device XX:XX:XX:XX:XX:XX Name
                parts = line.strip().split(" ", 2)
                if len(parts) == 3 and parts[0] == "Device":
                    devices.append({"mac": parts[1], "name": parts[2]})
            return devices
        except Exception:
            return []
