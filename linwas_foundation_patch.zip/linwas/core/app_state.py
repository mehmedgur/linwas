"""
In-memory app state.

Only runtime/live values should stay here.
Persistent settings live in ~/.config/linwas/config.json.
"""
from __future__ import annotations

import threading
import time
from typing import Any


class AppState:
    def __init__(self):
        self._lock = threading.RLock()
        self._data: dict[str, dict[str, Any]] = {}

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            self._data[key] = {"value": value, "updated_at": time.time()}

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            item = self._data.get(key)
            return default if item is None else item["value"]

    def updated_at(self, key: str) -> float | None:
        with self._lock:
            item = self._data.get(key)
            return None if item is None else item["updated_at"]

    def all(self) -> dict[str, Any]:
        with self._lock:
            return {k: v["value"] for k, v in self._data.items()}


APP_STATE = AppState()
