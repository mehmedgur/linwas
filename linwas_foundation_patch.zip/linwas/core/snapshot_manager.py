"""
Snapshot / rollback manager for linwas.

Design decisions:
- Full snapshot, not diff.
- Snapshots are taken only before linwas changes a file.
- Maximum total snapshot size defaults to 250 MB.
- Snapshots older than 7 days are purged.
- If the same source file is snapshotted again, the older snapshot is removed.
- Snapshot metadata is user-visible through Settings / Rollback UI later.
"""
from __future__ import annotations

import json
import shutil
import time
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Literal


Recoverability = Literal["full", "partial", "none"]

CONFIG_DIR = Path.home() / ".config" / "linwas"
SNAPSHOT_DIR = CONFIG_DIR / "snapshots"
META_FILE = SNAPSHOT_DIR / "metadata.json"


@dataclass
class SnapshotRecord:
    id: str
    source_path: str
    snapshot_path: str
    action: str
    created_at: float
    size_bytes: int
    recoverability: Recoverability
    note: str = ""


class SnapshotManager:
    def __init__(self, max_total_mb: int = 250, retention_days: int = 7):
        self.max_total_bytes = max_total_mb * 1024 * 1024
        self.retention_seconds = retention_days * 24 * 60 * 60
        SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)
        self._records = self._load()

    def _load(self) -> list[SnapshotRecord]:
        if not META_FILE.exists():
            return []
        try:
            data = json.loads(META_FILE.read_text(encoding="utf-8"))
            return [SnapshotRecord(**item) for item in data]
        except Exception:
            return []

    def _save(self) -> None:
        SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)
        META_FILE.write_text(
            json.dumps([asdict(r) for r in self._records], indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    def list_snapshots(self) -> list[SnapshotRecord]:
        self.purge_expired()
        return list(self._records)

    def purge_expired(self) -> int:
        now = time.time()
        keep: list[SnapshotRecord] = []
        deleted = 0

        for rec in self._records:
            path = Path(rec.snapshot_path)
            expired = now - rec.created_at > self.retention_seconds
            missing = not path.exists()
            if expired or missing:
                self._remove_file(path)
                deleted += 1
            else:
                keep.append(rec)

        self._records = keep
        self._enforce_size_limit()
        self._save()
        return deleted

    def take_snapshot(
        self,
        source_path: str | Path,
        action: str,
        recoverability: Recoverability = "full",
        note: str = "",
    ) -> SnapshotRecord | None:
        src = Path(source_path).expanduser().resolve()
        if not src.exists() or not src.is_file():
            return None

        # Do not snapshot huge files; linwas is not a full backup tool.
        size = src.stat().st_size
        if size > self.max_total_bytes:
            return None

        # Only keep latest snapshot per source file.
        self._delete_records_for_source(str(src))

        snapshot_id = uuid.uuid4().hex[:12]
        safe_name = src.as_posix().strip("/").replace("/", "__")
        dest = SNAPSHOT_DIR / f"{snapshot_id}__{safe_name}"

        shutil.copy2(src, dest)

        rec = SnapshotRecord(
            id=snapshot_id,
            source_path=str(src),
            snapshot_path=str(dest),
            action=action,
            created_at=time.time(),
            size_bytes=size,
            recoverability=recoverability,
            note=note,
        )
        self._records.append(rec)
        self._enforce_size_limit()
        self._save()
        return rec

    def restore(self, snapshot_id: str) -> bool:
        rec = next((r for r in self._records if r.id == snapshot_id), None)
        if rec is None:
            return False
        src = Path(rec.source_path)
        snap = Path(rec.snapshot_path)
        if not snap.exists():
            return False

        # Backup current version too, so rollback itself is reversible.
        if src.exists() and src.is_file():
            current_backup = SNAPSHOT_DIR / f"{uuid.uuid4().hex[:12]}__before_restore__{src.name}"
            try:
                shutil.copy2(src, current_backup)
            except OSError:
                pass

        src.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(snap, src)
        return True

    def _delete_records_for_source(self, source: str) -> None:
        keep = []
        for rec in self._records:
            if rec.source_path == source:
                self._remove_file(Path(rec.snapshot_path))
            else:
                keep.append(rec)
        self._records = keep

    def _enforce_size_limit(self) -> None:
        total = sum(r.size_bytes for r in self._records if Path(r.snapshot_path).exists())
        if total <= self.max_total_bytes:
            return

        # Oldest first.
        self._records.sort(key=lambda r: r.created_at)
        while self._records and total > self.max_total_bytes:
            rec = self._records.pop(0)
            self._remove_file(Path(rec.snapshot_path))
            total -= rec.size_bytes

    @staticmethod
    def _remove_file(path: Path) -> None:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass


def recoverability_for_action(action_type: str) -> tuple[Recoverability, str]:
    """Human-readable rollback level proposal."""
    action = action_type.lower()
    if any(k in action for k in ["config", "networkmanager", "service", "package", "apt", "flatpak"]):
        return "full", "Tam geri alınabilir"
    if any(k in action for k in ["driver", "gpu", "wine"]):
        return "partial", "Kısmen geri alınabilir"
    return "none", "Geri alınamaz veya linwas dışında değişmiş"
