"""linwas core helpers."""
