"""
Plaintext log manager for linwas.

Policy:
- Logs live under ~/.local/share/linwas/logs
- Logs older than retention_days are deleted at app startup
- This module does not log secrets/API keys
"""
from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from datetime import datetime, timedelta


LOG_DIR = Path.home() / ".local" / "share" / "linwas" / "logs"


class LogManager:
    def __init__(self, retention_days: int = 7, max_file_mb: int = 5):
        self.retention_days = retention_days
        self.max_file_mb = max_file_mb
        LOG_DIR.mkdir(parents=True, exist_ok=True)

    def purge_old_logs(self) -> int:
        cutoff = datetime.now() - timedelta(days=self.retention_days)
        deleted = 0
        for path in LOG_DIR.glob("*.log*"):
            try:
                if datetime.fromtimestamp(path.stat().st_mtime) < cutoff:
                    path.unlink()
                    deleted += 1
            except OSError:
                pass
        return deleted

    def setup(self, level: str = "INFO") -> logging.Logger:
        logger = logging.getLogger("linwas")
        logger.setLevel(getattr(logging, level.upper(), logging.INFO))
        logger.propagate = False

        # Prevent duplicate handlers after restart/reload
        for h in list(logger.handlers):
            logger.removeHandler(h)

        fmt = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )

        app_log = LOG_DIR / "app.log"
        handler = RotatingFileHandler(
            app_log,
            maxBytes=self.max_file_mb * 1024 * 1024,
            backupCount=3,
            encoding="utf-8",
        )
        handler.setFormatter(fmt)
        logger.addHandler(handler)

        console = logging.StreamHandler()
        console.setFormatter(fmt)
        logger.addHandler(console)

        return logger


def get_log_dir() -> Path:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    return LOG_DIR
