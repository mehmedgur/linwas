# linwas Kurulum Talimatı

## 1. Temiz kurulum

Eski kalıntıları temizlemek istersen:

```bash
sudo rm -rf /opt/linwas
sudo rm -f /usr/local/bin/linwas
sudo rm -f /usr/share/applications/linwas.desktop
rm -f ~/.local/share/applications/linwas.desktop
rm -rf ~/.cache/linwas
```

Ayarları ve logları da sıfırlamak istersen:

```bash
rm -rf ~/.config/linwas
rm -rf ~/.local/share/linwas
```

## 2. Kurulum

Proje klasöründe:

```bash
sudo bash setup.sh
```

Setup sadece temel bağımlılıkları kurar:

- Python 3.10+
- PySide6
- psutil
- requests
- google-generativeai

Wine, LibreOffice, OnlyOffice gibi ağır paketler ilk kurulumda kurulmaz.

## 3. Çalıştırma

Kurulumdan sonra terminalden:

```bash
linwas
```

veya uygulama menüsünden **Linwas** arat.

Geliştirme modunda:

```bash
python3 main.py
```

## 4. Veri dizinleri

- Ayarlar: `~/.config/linwas/config.json`
- Snapshotlar: `~/.config/linwas/snapshots/`
- Loglar: `~/.local/share/linwas/logs/`

## 5. Snapshot politikası

- Tam snapshot alınır.
- Sadece değişiklik öncesi alınır.
- Toplam limit: 250 MB.
- 7 günden eski snapshotlar silinir.
- Aynı dosya için yeni snapshot alınırsa eski olan silinir.

## 6. Log politikası

- Plaintext log tutulur.
- 7 günden eski loglar otomatik temizlenir.
