import sys
from app import LinwasApp

if __name__ == "__main__":
    app = LinwasApp(sys.argv)
    sys.exit(app.exec())
