"""
Tracks background tasks with progress/status.
"""
import uuid
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable


class TaskStatus(Enum):
    PENDING  = "pending"
    RUNNING  = "running"
    DONE     = "done"
    FAILED   = "failed"
    CANCELED = "canceled"


@dataclass
class Task:
    id: str
    title: str
    status: TaskStatus = TaskStatus.PENDING
    progress: int = 0
    message: str = ""
    started_at: float = 0.0
    finished_at: float = 0.0
    error: str = ""
    on_update: Callable | None = field(default=None, repr=False)

    def update(self, progress: int = -1, message: str = "", status: TaskStatus | None = None):
        if progress >= 0:
            self.progress = min(100, progress)
        if message:
            self.message = message
        if status:
            self.status = status
        if self.on_update:
            self.on_update(self)


class TaskManager:
    def __init__(self):
        self._tasks: dict[str, Task] = {}

    def create(self, title: str, on_update: Callable | None = None) -> Task:
        task = Task(id=str(uuid.uuid4()), title=title, on_update=on_update)
        self._tasks[task.id] = task
        return task

    def start(self, task: Task):
        task.started_at = time.time()
        task.update(status=TaskStatus.RUNNING, message="Başlıyor...")

    def finish(self, task: Task, message: str = "Tamamlandı"):
        task.finished_at = time.time()
        task.update(progress=100, status=TaskStatus.DONE, message=message)

    def fail(self, task: Task, error: str):
        task.finished_at = time.time()
        task.error = error
        task.update(status=TaskStatus.FAILED, message=f"Hata: {error}")

    def get(self, task_id: str) -> Task | None:
        return self._tasks.get(task_id)

    def recent(self, n: int = 10) -> list[Task]:
        tasks = sorted(self._tasks.values(), key=lambda t: t.started_at, reverse=True)
        return tasks[:n]
