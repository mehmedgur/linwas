import subprocess
import platform
import time
import psutil


class SystemInfo:
    def get_cpu_info(self) -> dict:
        try:
            percent = psutil.cpu_percent(interval=0.3)
            count = psutil.cpu_count(logical=True)
            freq = psutil.cpu_freq()
            return {
                "name": self._cpu_name(),
                "percent": percent,
                "count": count,
                "freq_mhz": round(freq.current) if freq else 0,
            }
        except Exception:
            return {"name": "Unknown", "percent": 0, "count": 0, "freq_mhz": 0}

    def _cpu_name(self) -> str:
        try:
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.startswith("model name"):
                        return line.split(":", 1)[1].strip()
        except OSError:
            pass
        return platform.processor() or "Unknown CPU"

    def get_ram_info(self) -> dict:
        m = psutil.virtual_memory()
        return {
            "total_gb": round(m.total / 1024 ** 3, 1),
            "used_gb":  round(m.used  / 1024 ** 3, 1),
            "percent":  m.percent,
        }

    def get_disk_info(self) -> list[dict]:
        result = []
        seen = set()
        for p in psutil.disk_partitions(all=False):
            if p.device in seen or not p.fstype:
                continue
            seen.add(p.device)
            try:
                u = psutil.disk_usage(p.mountpoint)
                result.append({
                    "device":     p.device,
                    "mountpoint": p.mountpoint,
                    "fstype":     p.fstype,
                    "total_gb":   round(u.total / 1024 ** 3, 1),
                    "used_gb":    round(u.used  / 1024 ** 3, 1),
                    "percent":    u.percent,
                })
            except (PermissionError, OSError):
                pass
        return result

    def get_gpu_info(self) -> dict:
        try:
            r = subprocess.run(
                ["nvidia-smi", "--query-gpu=name,utilization.gpu,memory.used,memory.total",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=3
            )
            if r.returncode == 0:
                parts = [x.strip() for x in r.stdout.strip().split(",")]
                if len(parts) >= 4:
                    return {
                        "name": parts[0],
                        "util_percent": float(parts[1]),
                        "vram_used_mb": float(parts[2]),
                        "vram_total_mb": float(parts[3]),
                        "type": "nvidia",
                    }
        except (FileNotFoundError, subprocess.TimeoutExpired, ValueError):
            pass
        try:
            r = subprocess.run(["lspci"], capture_output=True, text=True, timeout=3)
            for line in r.stdout.splitlines():
                if any(k in line for k in ("VGA", "3D", "Display")):
                    return {"name": line.split(":")[-1].strip(), "type": "generic"}
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
        return {"name": "Bilinmiyor", "type": "unknown"}

    def get_uptime(self) -> dict:
        secs = time.time() - psutil.boot_time()
        hours = int(secs // 3600)
        minutes = int((secs % 3600) // 60)
        return {"hours": hours, "minutes": minutes}

    def get_os_info(self) -> dict:
        info = {}
        try:
            with open("/etc/os-release") as f:
                for line in f:
                    line = line.strip()
                    if "=" in line:
                        k, v = line.split("=", 1)
                        info[k] = v.strip('"')
        except OSError:
            pass
        return {
            "name":    info.get("PRETTY_NAME", platform.system()),
            "id":      info.get("ID", "linux"),
            "version": info.get("VERSION_ID", ""),
        }

    def get_kernel_version(self) -> str:
        return platform.release()

    def get_hostname(self) -> str:
        try:
            return platform.node()
        except Exception:
            return "linux"

    def get_updates_available(self) -> int:
        try:
            r = subprocess.run(
                ["apt", "list", "--upgradable"],
                capture_output=True, text=True, timeout=15, env={"LANG": "C"}
            )
            return sum(1 for l in r.stdout.splitlines() if "/" in l)
        except Exception:
            return -1

    def check_internet(self) -> bool:
        try:
            subprocess.run(
                ["ping", "-c", "1", "-W", "2", "8.8.8.8"],
                capture_output=True, timeout=5
            )
            return True
        except Exception:
            return False

    def get_all(self) -> dict:
        return {
            "cpu":     self.get_cpu_info(),
            "ram":     self.get_ram_info(),
            "disks":   self.get_disk_info(),
            "gpu":     self.get_gpu_info(),
            "uptime":  self.get_uptime(),
            "os":      self.get_os_info(),
            "kernel":  self.get_kernel_version(),
            "host":    self.get_hostname(),
            "updates": self.get_updates_available(),
            "internet": self.check_internet(),
        }
