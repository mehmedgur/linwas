import threading
from PySide6.QtCore import QObject, Signal
from ui.components.worker import run_in_thread


class DataPreloader(QObject):
    data_ready = Signal(str, object)  # (key, data)

    _instance = None
    _instance_lock = threading.Lock()

    @classmethod
    def instance(cls) -> "DataPreloader":
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls()
        return cls._instance

    def __init__(self):
        super().__init__()
        self._cache: dict = {}
        self._cache_lock = threading.Lock()

    def start(self):
        """Kick off background collection. Call once after window.show()."""
        from backend.system import SystemInfo
        from services.network_service import NetworkService

        # Fast startup-only checks. Heavy diagnosis runs only when user requests it.
        si  = SystemInfo()
        net = NetworkService()

        run_in_thread(si.get_all,        on_done=lambda d: self._store("system",  d))
        run_in_thread(net.get_ip_info,   on_done=lambda d: self._store("network", d))

    def _store(self, key: str, data):
        with self._cache_lock:
            self._cache[key] = data
        try:
            from core.app_state import APP_STATE
            APP_STATE.set(key, data)
        except Exception:
            pass
        self.data_ready.emit(key, data)

    def get(self, key, default=None):
        with self._cache_lock:
            return self._cache.get(key, default)

    def has(self, key) -> bool:
        with self._cache_lock:
            return key in self._cache
