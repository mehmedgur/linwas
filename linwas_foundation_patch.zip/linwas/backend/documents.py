import subprocess
import os
from pathlib import Path


SUPPORTED = {".docx", ".xlsx", ".pptx", ".odt", ".ods", ".odp", ".pdf", ".doc", ".xls", ".ppt"}


class DocumentsBackend:
    def analyse(self, path: str) -> dict:
        p = Path(path)
        if not p.exists():
            return {"error": "Dosya bulunamadı"}
        ext = p.suffix.lower()
        result = {
            "name":          p.name,
            "ext":           ext,
            "size_kb":       round(p.stat().st_size / 1024, 1),
            "supported":     ext in SUPPORTED,
            "ms_format":     ext in {".docx", ".xlsx", ".pptx", ".doc", ".xls", ".ppt"},
            "libreoffice":   self._lo_available(),
            "fonts_ok":      True,
            "missing_fonts": [],
            "warnings":      [],
        }
        if ext in {".docx", ".doc"}:
            result["missing_fonts"] = self._check_fonts_docx(path)
        if not result["libreoffice"] and result["ms_format"]:
            result["warnings"].append("LibreOffice kurulu değil — dosyayı açmak için kurmanız gerekiyor.")
        if result["missing_fonts"]:
            result["fonts_ok"] = False
            result["warnings"].append(f"Eksik fontlar: {', '.join(result['missing_fonts'])}")
        return result

    def _lo_available(self) -> bool:
        for cmd in ("libreoffice", "soffice"):
            try:
                subprocess.run([cmd, "--version"], capture_output=True, timeout=3)
                return True
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass
        return False

    def _check_fonts_docx(self, path: str) -> list[str]:
        try:
            import zipfile
            import xml.etree.ElementTree as ET
            fonts_in_doc = set()
            with zipfile.ZipFile(path) as z:
                for name in z.namelist():
                    if name.endswith(".xml"):
                        try:
                            tree = ET.fromstring(z.read(name))
                            for elem in tree.iter():
                                for attr in elem.attrib:
                                    if "font" in attr.lower():
                                        val = elem.attrib[attr]
                                        if val and len(val) < 80:
                                            fonts_in_doc.add(val)
                        except ET.ParseError:
                            pass
            system_fonts = self._get_system_fonts()
            return [f for f in fonts_in_doc if f.lower() not in system_fonts]
        except Exception:
            return []

    def _get_system_fonts(self) -> set[str]:
        try:
            r = subprocess.run(["fc-list", ":family"], capture_output=True, text=True, timeout=5)
            return {line.strip().lower() for line in r.stdout.splitlines() if line.strip()}
        except Exception:
            return set()

    def convert_to_pdf(self, path: str, output_dir: str = "") -> tuple[bool, str]:
        p = Path(path)
        if not p.exists():
            return False, "Dosya bulunamadı"
        out = output_dir or str(p.parent)
        for cmd in ("libreoffice", "soffice"):
            try:
                r = subprocess.run(
                    [cmd, "--headless", "--convert-to", "pdf", "--outdir", out, str(p)],
                    capture_output=True, text=True, timeout=60
                )
                if r.returncode == 0:
                    pdf = Path(out) / (p.stem + ".pdf")
                    return True, str(pdf)
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass
        return False, "LibreOffice bulunamadı"

    def list_recent(self, n: int = 10) -> list[dict]:
        home = Path.home()
        candidates = []
        for folder in ("Documents", "Downloads", "Desktop", "Belgeler", "İndirilenler", "."):
            d = home / folder
            if d.is_dir():
                for f in d.iterdir():
                    if f.suffix.lower() in SUPPORTED:
                        try:
                            candidates.append((f.stat().st_mtime, str(f)))
                        except OSError:
                            pass
        candidates.sort(reverse=True)
        return [{"path": p, "name": Path(p).name} for _, p in candidates[:n]]
