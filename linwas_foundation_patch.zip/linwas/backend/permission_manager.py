"""
Security gate: shows the user what will happen before anything runs.
Returns True only if the user explicitly approves.
"""
from dataclasses import dataclass, field
from typing import Callable


@dataclass
class ActionPlan:
    title: str
    description: str
    commands: list[list[str]]
    requires_sudo: bool = False
    risk_level: str = "low"   # low | medium | high
    warnings: list[str] = field(default_factory=list)


class PermissionManager:
    """
    The UI layer must set `approval_callback` to a function that
    displays the plan to the user and returns True/False.
    """

    def __init__(self):
        self.approval_callback: Callable[[ActionPlan], bool] | None = None

    def request_approval(self, plan: ActionPlan) -> bool:
        if self.approval_callback is None:
            return False
        return self.approval_callback(plan)

    def build_install_plan(self, package: str, manager: str = "apt") -> ActionPlan:
        if manager == "flatpak":
            cmds = [["flatpak", "install", "-y", package]]
            sudo = False
        else:
            cmds = [
                ["apt-get", "update"],
                ["apt-get", "install", "-y", package],
            ]
            sudo = True
        return ActionPlan(
            title=f"'{package}' kurulsun mu?",
            description=f"{manager.upper()} üzerinden '{package}' paketi kurulacak.",
            commands=cmds,
            requires_sudo=sudo,
            risk_level="low",
        )

    def build_remove_plan(self, package: str, manager: str = "apt") -> ActionPlan:
        if manager == "flatpak":
            cmds = [["flatpak", "remove", "-y", package]]
            sudo = False
        else:
            cmds = [["apt-get", "remove", "-y", package]]
            sudo = True
        return ActionPlan(
            title=f"'{package}' kaldırılsın mı?",
            description=f"'{package}' sisteminizden kaldırılacak.",
            commands=cmds,
            requires_sudo=sudo,
            risk_level="medium",
        )

    def build_service_plan(self, service: str, action: str) -> ActionPlan:
        return ActionPlan(
            title=f"Servis: {service} → {action}",
            description=f"'{service}' servisi {action} yapılacak.",
            commands=[["systemctl", action, service]],
            requires_sudo=True,
            risk_level="medium" if action in ("stop", "disable") else "low",
        )

    def build_custom_plan(
        self,
        title: str,
        description: str,
        commands: list[list[str]],
        requires_sudo: bool = False,
        risk_level: str = "low",
        warnings: list[str] | None = None,
    ) -> ActionPlan:
        return ActionPlan(
            title=title,
            description=description,
            commands=commands,
            requires_sudo=requires_sudo,
            risk_level=risk_level,
            warnings=warnings or [],
        )
