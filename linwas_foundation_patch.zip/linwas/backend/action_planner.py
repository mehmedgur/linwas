"""
Converts AI suggestions into ActionPlan objects for PermissionManager.
"""
from backend.permission_manager import ActionPlan


class ActionPlanner:
    def from_ai_response(self, ai_action: dict) -> ActionPlan | None:
        if not ai_action or not ai_action.get("action"):
            return None
        commands = ai_action.get("commands", [])
        if not commands:
            return None
        return ActionPlan(
            title=ai_action.get("title", "İşlem"),
            description=ai_action.get("description", ""),
            commands=commands,
            requires_sudo=ai_action.get("requires_sudo", False),
            risk_level=ai_action.get("risk_level", "low"),
            warnings=ai_action.get("warnings", []),
        )

    def from_package_install(self, package: str, manager: str = "apt") -> ActionPlan:
        if manager == "flatpak":
            return ActionPlan(
                title=f"'{package}' kurulsun mu?",
                description=f"Flatpak üzerinden '{package}' kurulacak.",
                commands=[["flatpak", "install", "-y", package]],
                requires_sudo=False,
                risk_level="low",
            )
        return ActionPlan(
            title=f"'{package}' kurulsun mu?",
            description=f"APT üzerinden '{package}' kurulacak.",
            commands=[["apt-get", "update"], ["apt-get", "install", "-y", package]],
            requires_sudo=True,
            risk_level="low",
        )

    def from_package_remove(self, package: str) -> ActionPlan:
        return ActionPlan(
            title=f"'{package}' kaldırılsın mı?",
            description=f"'{package}' sisteminizden kaldırılacak.",
            commands=[["apt-get", "remove", "-y", package]],
            requires_sudo=True,
            risk_level="medium",
        )

    def from_system_update(self) -> ActionPlan:
        return ActionPlan(
            title="Sistem güncellensin mi?",
            description="Tüm kurulu paketler güncellenecek.",
            commands=[["apt-get", "update"], ["apt-get", "upgrade", "-y"]],
            requires_sudo=True,
            risk_level="low",
        )
