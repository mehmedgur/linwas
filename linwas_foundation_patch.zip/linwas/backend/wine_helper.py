import subprocess
from pathlib import Path

LINUX_ALTERNATIVES = {
    "photoshop":   ("GIMP",            "gimp",   "flatpak"),
    "illustrator": ("Inkscape",        "inkscape", "apt"),
    "office":      ("LibreOffice",     "libreoffice", "apt"),
    "word":        ("LibreOffice Writer", "libreoffice", "apt"),
    "excel":       ("LibreOffice Calc",  "libreoffice", "apt"),
    "powerpoint":  ("LibreOffice Impress", "libreoffice", "apt"),
    "notepad++":   ("Kate",            "kate", "apt"),
    "vlc":         ("VLC",             "vlc", "apt"),
    "winrar":      ("File Roller",     "file-roller", "apt"),
    "7zip":        ("7-Zip (p7zip)",   "p7zip-full", "apt"),
    "steam":       ("Steam",           "steam", "apt"),
    "discord":     ("Discord",         "discord", "flatpak"),
    "spotify":     ("Spotify",         "spotify", "flatpak"),
    "chrome":      ("Chromium",        "chromium-browser", "apt"),
    "firefox":     ("Firefox",         "firefox", "apt"),
    "skype":       ("Skype",           "skype", "flatpak"),
    "zoom":        ("Zoom",            "zoom", "flatpak"),
    "teams":       ("Microsoft Teams", "com.microsoft.Teams", "flatpak"),
}


class WineHelper:
    def is_wine_installed(self) -> bool:
        try:
            subprocess.run(["wine", "--version"], capture_output=True, timeout=3)
            return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def wine_version(self) -> str:
        try:
            r = subprocess.run(["wine", "--version"], capture_output=True, text=True, timeout=3)
            return r.stdout.strip()
        except Exception:
            return ""

    def run_exe(self, exe_path: str) -> tuple[bool, str]:
        p = Path(exe_path)
        if not p.exists():
            return False, "Dosya bulunamadı"
        if not self.is_wine_installed():
            return False, "Wine kurulu değil"
        try:
            r = subprocess.run(
                ["wine", str(p)],
                capture_output=True, text=True, timeout=30,
                cwd=str(p.parent)
            )
            if r.returncode == 0:
                return True, "Program başlatıldı"
            return False, r.stderr[:500] or r.stdout[:500]
        except subprocess.TimeoutExpired:
            return True, "Program başlatıldı (zaman aşımı — büyük ihtimalle çalışıyor)"
        except Exception as e:
            return False, str(e)

    def suggest_alternative(self, exe_name: str) -> dict | None:
        name_lower = exe_name.lower().replace(".exe", "")
        for keyword, (alt_name, pkg, mgr) in LINUX_ALTERNATIVES.items():
            if keyword in name_lower:
                return {"name": alt_name, "package": pkg, "manager": mgr}
        return None

    def get_wine_prefix_info(self) -> dict:
        prefix = Path.home() / ".wine"
        return {
            "exists":  prefix.exists(),
            "path":    str(prefix),
            "size_mb": self._dir_size_mb(prefix) if prefix.exists() else 0,
        }

    def _dir_size_mb(self, path: Path) -> float:
        total = 0
        try:
            for f in path.rglob("*"):
                if f.is_file():
                    total += f.stat().st_size
        except OSError:
            pass
        return round(total / 1024 ** 2, 1)
