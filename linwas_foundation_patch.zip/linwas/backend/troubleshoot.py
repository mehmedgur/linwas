import subprocess
import psutil
from pathlib import Path


class TroubleshootBackend:
    def check_internet(self) -> dict:
        ok = self._ping("8.8.8.8")
        dns = self._ping("google.com")
        return {
            "internet": ok,
            "dns":      dns,
            "status":   "ok" if (ok and dns) else "warning" if ok else "error",
            "message":  "Bağlantı normal" if (ok and dns)
                        else "İnternet var ama DNS çalışmıyor" if ok
                        else "İnternet bağlantısı yok",
        }

    def _ping(self, host: str) -> bool:
        try:
            r = subprocess.run(
                ["ping", "-c", "1", "-W", "2", host],
                capture_output=True, timeout=5
            )
            return r.returncode == 0
        except Exception:
            return False

    def check_disk_space(self) -> list[dict]:
        issues = []
        for p in psutil.disk_partitions(all=False):
            try:
                u = psutil.disk_usage(p.mountpoint)
                if u.percent > 90:
                    issues.append({
                        "mountpoint": p.mountpoint,
                        "percent":    u.percent,
                        "free_gb":    round(u.free / 1024 ** 3, 1),
                        "severity":   "error" if u.percent > 95 else "warning",
                        "message":    f"{p.mountpoint} diski %{u.percent:.0f} dolu",
                    })
            except (PermissionError, OSError):
                pass
        return issues

    def check_failed_services(self) -> list[dict]:
        try:
            r = subprocess.run(
                ["systemctl", "list-units", "--state=failed", "--no-legend", "--no-pager"],
                capture_output=True, text=True, timeout=8
            )
            failed = []
            for line in r.stdout.splitlines():
                parts = line.split()
                if parts:
                    failed.append({"service": parts[0], "state": "failed"})
            return failed
        except Exception:
            return []

    def check_updates(self) -> dict:
        try:
            r = subprocess.run(
                ["apt", "list", "--upgradable"],
                capture_output=True, text=True, timeout=15,
                env={"LANG": "C", "PATH": "/usr/bin:/bin"}
            )
            count = sum(1 for l in r.stdout.splitlines() if "/" in l)
            return {
                "count":   count,
                "status":  "warning" if count > 0 else "ok",
                "message": f"{count} güncelleme mevcut" if count else "Sistem güncel",
            }
        except Exception:
            return {"count": -1, "status": "neutral", "message": "Kontrol edilemedi"}

    def check_audio(self) -> dict:
        try:
            r = subprocess.run(["pactl", "info"], capture_output=True, text=True, timeout=5)
            ok = r.returncode == 0
            return {
                "status":  "ok" if ok else "error",
                "message": "Ses sistemi çalışıyor" if ok else "PulseAudio/PipeWire bulunamadı",
            }
        except FileNotFoundError:
            return {"status": "warning", "message": "pactl bulunamadı — ses kontrol edilemiyor"}

    def check_bluetooth(self) -> dict:
        try:
            r = subprocess.run(
                ["systemctl", "is-active", "bluetooth"],
                capture_output=True, text=True, timeout=5
            )
            active = r.stdout.strip() == "active"
            return {
                "status":  "ok" if active else "warning",
                "message": "Bluetooth servisi aktif" if active else "Bluetooth servisi kapalı",
            }
        except Exception:
            return {"status": "neutral", "message": "Bluetooth durumu bilinmiyor"}

    def get_journal_errors(self, n: int = 20) -> list[str]:
        try:
            r = subprocess.run(
                ["journalctl", "-p", "err", "-n", str(n), "--no-pager", "--output=short"],
                capture_output=True, text=True, timeout=8
            )
            return r.stdout.splitlines()
        except Exception:
            return []

    def run_all_checks(self) -> dict:
        return {
            "internet":  self.check_internet(),
            "disk":      self.check_disk_space(),
            "services":  self.check_failed_services(),
            "updates":   self.check_updates(),
            "audio":     self.check_audio(),
            "bluetooth": self.check_bluetooth(),
        }
