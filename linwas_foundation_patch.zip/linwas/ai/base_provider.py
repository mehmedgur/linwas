from abc import ABC, abstractmethod
from typing import Iterator


class BaseAIProvider(ABC):
    @abstractmethod
    def validate_key(self, api_key: str) -> bool:
        pass

    @abstractmethod
    def chat(self, api_key: str, model_name: str, messages: list[dict], system: str = "") -> str:
        pass

    @abstractmethod
    def stream(self, api_key: str, model_name: str, messages: list[dict], system: str = "") -> Iterator[str]:
        pass
