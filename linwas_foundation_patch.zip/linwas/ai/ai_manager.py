"""
AIManager: provider seçimi, mesaj geçmişi, sistem prompt'u, action JSON parse.
Eski AIRouter'ın yerini alır.
"""
import json
from typing import Iterator

from ai.providers import GoogleGeminiProvider, SUPPORTED_MODELS

SYSTEM_PROMPT = """Sen 'Linwas' adlı bir Linux masaüstü yardımcısının AI asistanısın.
Kullanıcı Windows'tan Linux'a geçiyor veya Linux'ta yeniyse onlara yardım ediyorsun.

Görevin:
1. Kullanıcının sorusunu anla
2. Hangi kategoriye girdiğini belirle: sistem, paket, belge, wine, sorun-giderme, guvenlik, genel
3. Eğer bir işlem gerekiyorsa, JSON formatında action planı öner
4. Teknik terimleri Türkçe/anlaşılır şekilde açıkla
5. Hiçbir zaman doğrudan sistem komutu çalıştırmazsın — sadece öneri yaparsın

Action planı formatı (eğer işlem gerekiyorsa):
{
  "action": true,
  "category": "paket|sistem|belge|wine|sorun-giderme|guvenlik",
  "title": "Ne yapılacak",
  "description": "Açıklama",
  "commands": [["komut", "arg1", "arg2"]],
  "requires_sudo": false,
  "risk_level": "low|medium|high"
}

Eğer sadece bilgi veriyorsan action: false yap.
Yanıtını HER ZAMAN şu formatta ver:
AÇIKLAMA: <kullanıcıya açıklama>
---
JSON: <json veya null>"""


class AIManager:
    def __init__(self, config_instance):
        self.config = config_instance
        self._providers = {
            "gemini": GoogleGeminiProvider(),
        }
        self._history: list[dict] = []

    def reset(self):
        self._history.clear()

    @property
    def history(self) -> list[dict]:
        return list(self._history)

    def get_active_provider_name(self) -> str:
        return self.config.get("ai_provider", "").lower()

    def get_active_model_name(self) -> str:
        return self.config.get("ai_model", "")

    def is_ready(self) -> bool:
        return all([
            self.get_active_provider_name() in self._providers,
            self.get_active_model_name(),
            self._get_api_key(),
        ])

    def _get_api_key(self) -> str:
        provider_name = self.get_active_provider_name()
        if not provider_name:
            return ""
        return self.config.get(f"{provider_name}_api_key", "")

    def _resolve(self) -> tuple:
        provider_name = self.get_active_provider_name()
        if not provider_name or provider_name not in self._providers:
            raise RuntimeError("Geçerli bir AI sağlayıcı seçilmedi.")
        model = self.get_active_model_name()
        if not model:
            raise RuntimeError("Model seçilmedi.")
        api_key = self._get_api_key()
        if not api_key:
            raise RuntimeError(f"{provider_name.upper()} API anahtarı bulunamadı.")
        return self._providers[provider_name], api_key, model

    def ask(self, message: str) -> tuple[str, dict | None]:
        provider, api_key, model = self._resolve()
        self._history.append({"role": "user", "content": message})
        try:
            raw = provider.chat(api_key, model, self._history, system=SYSTEM_PROMPT)
        except Exception as e:
            self._history.pop()
            return f"AI hatası: {e}", None
        self._history.append({"role": "assistant", "content": raw})
        return self._parse(raw)

    def stream_ask(self, message: str) -> Iterator[str]:
        provider, api_key, model = self._resolve()
        self._history.append({"role": "user", "content": message})
        collected = []
        try:
            for chunk in provider.stream(api_key, model, self._history, system=SYSTEM_PROMPT):
                collected.append(chunk)
                yield chunk
        except Exception as e:
            self._history.pop()
            yield f"\n[Hata: {e}]"
            return
        full = "".join(collected)
        self._history.append({"role": "assistant", "content": full})

    @staticmethod
    def parse_response(raw: str) -> tuple[str, dict | None]:
        return AIManager._parse(raw)

    @staticmethod
    def _parse(raw: str) -> tuple[str, dict | None]:
        explanation = raw
        action = None
        if "---" in raw and "JSON:" in raw:
            parts = raw.split("---", 1)
            explanation = (
                parts[0]
                .replace("AÇIKLAMA:", "")
                .replace("ACIKLAMA:", "")
                .strip()
            )
            json_part = parts[1].replace("JSON:", "").strip()
            if json_part.lower() not in ("null", "none", ""):
                try:
                    parsed = json.loads(json_part)
                    if parsed.get("action"):
                        action = parsed
                except json.JSONDecodeError:
                    pass
        return explanation, action
