import importlib
from typing import Iterator

from ai.base_provider import BaseAIProvider


class GoogleGeminiProvider(BaseAIProvider):
    def validate_key(self, api_key: str) -> bool:
        try:
            genai = importlib.import_module("google.generativeai")
            genai.configure(api_key=api_key)
            list(genai.list_models())
            return True
        except Exception:
            return False

    def _get_model(self, api_key: str, model_name: str, system: str):
        genai = importlib.import_module("google.generativeai")
        genai.configure(api_key=api_key)
        kwargs = {}
        if system:
            kwargs["system_instruction"] = system
        return genai.GenerativeModel(model_name, **kwargs)

    def _to_gemini(self, messages: list[dict]) -> list[dict]:
        role_map = {"user": "user", "assistant": "model"}
        return [
            {"role": role_map.get(m["role"], "user"), "parts": [m["content"]]}
            for m in messages
        ]

    def chat(self, api_key: str, model_name: str, messages: list[dict], system: str = "") -> str:
        model = self._get_model(api_key, model_name, system)
        chat = model.start_chat(history=self._to_gemini(messages[:-1]))
        resp = chat.send_message(messages[-1]["content"])
        return resp.text

    def stream(self, api_key: str, model_name: str, messages: list[dict], system: str = "") -> Iterator[str]:
        model = self._get_model(api_key, model_name, system)
        chat = model.start_chat(history=self._to_gemini(messages[:-1]))
        for chunk in chat.send_message(messages[-1]["content"], stream=True):
            if chunk.text:
                yield chunk.text


SUPPORTED_MODELS = {
    "gemini": [
        "gemini-2.0-flash",
        "gemini-1.5-pro",
        "gemini-1.5-flash",
    ],
}
