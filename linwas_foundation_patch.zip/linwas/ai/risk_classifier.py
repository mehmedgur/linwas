"""
Komutları otomatik çalıştırılabilir (düşük risk) ve onay gerektiren (yüksek risk)
olarak sınıflandırır. AI'nın 'risk_level' beyanına GÜVENMEZ — komutun kendisine bakar.
"""

LOW_RISK_PREFIXES: list[list[str]] = [
    ["apt", "list"],
    ["apt", "search"],
    ["apt-cache", "search"],
    ["dpkg", "-l"],
    ["dpkg", "--list"],
    ["flatpak", "list"],
    ["flatpak", "search"],
    ["systemctl", "status"],
    ["systemctl", "list-units"],
    ["systemctl", "list-unit-files"],
    ["ufw", "status"],
    ["lsblk"],
    ["lspci"],
    ["lsusb"],
    ["df"],
    ["free"],
    ["ping", "-c"],
    ["fc-list"],
    ["nmcli", "device"],
    ["nmcli", "connection", "show"],
    ["bluetoothctl", "devices"],
    ["bluetoothctl", "list"],
    ["journalctl", "-n"],
    ["xdg-open"],
]


def is_low_risk(cmd: list[str], requires_sudo: bool) -> bool:
    if requires_sudo:
        return False
    if not cmd:
        return False
    for prefix in LOW_RISK_PREFIXES:
        if cmd[:len(prefix)] == prefix:
            return True
    return False


def all_low_risk(commands: list[list[str]], requires_sudo: bool) -> bool:
    if not commands:
        return False
    return all(is_low_risk(c, requires_sudo) for c in commands)
