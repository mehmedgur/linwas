#!/usr/bin/env bash
set -euo pipefail

INSTALL_DIR="/opt/linwas"
LAUNCHER="/usr/local/bin/linwas"
DESKTOP_FILE="/usr/share/applications/linwas.desktop"
ICON_DIR="/usr/share/icons/hicolor/scalable/apps"
ICON_FILE="$ICON_DIR/linwas.svg"
PIXMAP_FILE="/usr/share/pixmaps/linwas.svg"

echo "================================================"
echo "  linwas — Linux Yardim Merkezi Kurulum Scripti"
echo "================================================"
echo

# ── 1. Root kontrolu ────────────────────────────────
if [ "$EUID" -ne 0 ]; then
    echo "[HATA] Bu script root olarak calistirilmalidir."
    echo "       sudo bash setup.sh"
    exit 1
fi

# ── 2. Python kontrolu ──────────────────────────────
python_bin=""
for cmd in python3.12 python3.11 python3.10 python3; do
    if command -v "$cmd" &>/dev/null; then
        ver=$("$cmd" -c "import sys; print(sys.version_info >= (3,10))")
        if [ "$ver" = "True" ]; then
            python_bin="$cmd"
            break
        fi
    fi
done

if [ -z "$python_bin" ]; then
    echo "[HATA] Python 3.10+ bulunamadi."
    echo "       sudo apt install python3.11"
    exit 1
fi
echo "[OK] Python: $($python_bin --version)"

# ── 3. pip ──────────────────────────────────────────
if ! "$python_bin" -m pip --version &>/dev/null; then
    echo "pip kuruluyor..."
    apt-get install -y python3-pip
fi

# ── 4. PySide6 ──────────────────────────────────────
echo
echo "PySide6 kontrol ediliyor..."
if ! "$python_bin" -c "import PySide6" &>/dev/null; then
    echo "PySide6 kuruluyor... (bu biraz zaman alabilir)"
    apt-get install -y python3-pyside6.qtwidgets python3-pyside6.qtcore python3-pyside6.qtgui 2>/dev/null || \
    "$python_bin" -m pip install PySide6
fi
echo "[OK] PySide6"

# ── 5. psutil ───────────────────────────────────────
if ! "$python_bin" -c "import psutil" &>/dev/null; then
    echo "psutil kuruluyor..."
    apt-get install -y python3-psutil 2>/dev/null || "$python_bin" -m pip install psutil
fi
echo "[OK] psutil"

# ── 6. requests ─────────────────────────────────────
if ! "$python_bin" -c "import requests" &>/dev/null; then
    echo "requests kuruluyor..."
    apt-get install -y python3-requests 2>/dev/null || "$python_bin" -m pip install requests
fi
echo "[OK] requests"

# ── 7. Google Gemini SDK ────────────────────────────
if ! "$python_bin" -c "import google.generativeai" &>/dev/null; then
    echo "google-generativeai kuruluyor..."
    "$python_bin" -m pip install google-generativeai
fi
echo "[OK] google-generativeai"

# ── 8. Dosyalari /opt/linwas'a kopyala ──────────────
echo
echo "Dosyalar $INSTALL_DIR dizinine kopyalaniyor..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$INSTALL_DIR"

if command -v rsync &>/dev/null; then
    rsync -a --delete \
        --exclude='.git' \
        --exclude='__pycache__' \
        --exclude='*.pyc' \
        --exclude='.env' \
        "$SCRIPT_DIR/" "$INSTALL_DIR/"
else
    cp -r "$SCRIPT_DIR/." "$INSTALL_DIR/"
    find "$INSTALL_DIR" -name '__pycache__' -type d -exec rm -rf {} + 2>/dev/null || true
    find "$INSTALL_DIR" -name '*.pyc' -delete 2>/dev/null || true
fi

chown -R root:root "$INSTALL_DIR"
chmod -R 755 "$INSTALL_DIR"
echo "[OK] Dosyalar: $INSTALL_DIR"

# ── 9. Ikon (SVG) ───────────────────────────────────
ICON_NAME="utilities-system-monitor"
if [ -f "$INSTALL_DIR/assets/icon.svg" ]; then
    mkdir -p "$ICON_DIR"
    cp "$INSTALL_DIR/assets/icon.svg" "$ICON_FILE"
    cp "$INSTALL_DIR/assets/icon.svg" "$PIXMAP_FILE"
    chmod 644 "$ICON_FILE" "$PIXMAP_FILE"
    ICON_NAME="linwas"
    echo "[OK] Ikon kuruldu"
elif [ -f "$INSTALL_DIR/assets/icon.png" ]; then
    cp "$INSTALL_DIR/assets/icon.png" /usr/share/pixmaps/linwas.png
    ICON_NAME="linwas"
fi

# ── 10. /usr/local/bin/linwas launcher ──────────────
cat > "$LAUNCHER" <<LAUNCHER_EOF
#!/usr/bin/env bash
cd "$INSTALL_DIR"
exec "$python_bin" "$INSTALL_DIR/main.py" "\$@"
LAUNCHER_EOF
chmod +x "$LAUNCHER"
echo "[OK] Launcher: $LAUNCHER"

# ── 11. Sistem geneli .desktop dosyasi ──────────────
cat > "$DESKTOP_FILE" <<DESKTOP_EOF
[Desktop Entry]
Name=Linwas
GenericName=Linux Yardim Merkezi
Comment=Windows'tan Linux'a gecis icin yardim merkezi
Exec=$LAUNCHER %U
Icon=$ICON_NAME
Terminal=false
Type=Application
Categories=System;Settings;Utility;
Keywords=linux;sistem;yardim;ai;
StartupNotify=true
StartupWMClass=linwas
DESKTOP_EOF
chmod 644 "$DESKTOP_FILE"
echo "[OK] Desktop girisi: $DESKTOP_FILE"

# ── 12. Desktop & ikon onbellegini guncelle ─────────
if command -v update-desktop-database &>/dev/null; then
    update-desktop-database /usr/share/applications 2>/dev/null || true
    echo "[OK] Desktop veritabani guncellendi"
fi
if command -v gtk-update-icon-cache &>/dev/null; then
    gtk-update-icon-cache -f /usr/share/icons/hicolor 2>/dev/null || true
fi

echo
echo "================================================"
echo "  Kurulum tamamlandi!"
echo
echo "  Baslatmak icin:"
echo "    Terminal       : linwas"
echo "    Uygulama menusu: Linwas (Sistem / Yardimci Programlar)"
echo
echo "  Kaldirmak icin:"
echo "    sudo rm -rf $INSTALL_DIR $LAUNCHER $DESKTOP_FILE $ICON_FILE $PIXMAP_FILE"
echo "================================================"
