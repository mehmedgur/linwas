import json
from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "linwas"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULTS = {
    "theme": "dark",
    "language": "tr",
    "ai_provider": "",
    "ai_model": "",
    "gemini_api_key": "",
    "window_width": 1100,
    "window_height": 720,
    "log_level": "INFO",
    "recent_actions": [],
    "show_tips": True,
}


class Config:
    def __init__(self):
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        self._data = dict(DEFAULTS)
        self._load()

    def _load(self):
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE) as f:
                    self._data.update(json.load(f))
            except (json.JSONDecodeError, OSError):
                pass

    def save(self):
        try:
            with open(CONFIG_FILE, "w") as f:
                json.dump(self._data, f, indent=2, ensure_ascii=False)
        except OSError:
            pass

    def get(self, key, default=None):
        return self._data.get(key, default if default is not None else DEFAULTS.get(key))

    def set(self, key, value):
        self._data[key] = value
        self.save()

    def __getitem__(self, key):
        return self._data.get(key, DEFAULTS.get(key))

    def __setitem__(self, key, value):
        self.set(key, value)
