import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QPalette, QColor, QFont
from config import Config
from ui.main_window import MainWindow

DARK = {
    QPalette.ColorRole.Window: "#1e2127",
    QPalette.ColorRole.WindowText: "#dcdfe4",
    QPalette.ColorRole.Base: "#282c34",
    QPalette.ColorRole.AlternateBase: "#21252b",
    QPalette.ColorRole.ToolTipBase: "#21252b",
    QPalette.ColorRole.ToolTipText: "#dcdfe4",
    QPalette.ColorRole.Text: "#dcdfe4",
    QPalette.ColorRole.Button: "#282c34",
    QPalette.ColorRole.ButtonText: "#dcdfe4",
    QPalette.ColorRole.BrightText: "#ffffff",
    QPalette.ColorRole.Link: "#0078d4",
    QPalette.ColorRole.Highlight: "#0078d4",
    QPalette.ColorRole.HighlightedText: "#ffffff",
    QPalette.ColorRole.PlaceholderText: "#5c6370",
}

LIGHT = {
    QPalette.ColorRole.Window: "#f3f3f3",
    QPalette.ColorRole.WindowText: "#1a1a1a",
    QPalette.ColorRole.Base: "#ffffff",
    QPalette.ColorRole.AlternateBase: "#f0f0f0",
    QPalette.ColorRole.ToolTipBase: "#ffffff",
    QPalette.ColorRole.ToolTipText: "#1a1a1a",
    QPalette.ColorRole.Text: "#1a1a1a",
    QPalette.ColorRole.Button: "#e8e8e8",
    QPalette.ColorRole.ButtonText: "#1a1a1a",
    QPalette.ColorRole.BrightText: "#000000",
    QPalette.ColorRole.Link: "#0078d4",
    QPalette.ColorRole.Highlight: "#0078d4",
    QPalette.ColorRole.HighlightedText: "#ffffff",
    QPalette.ColorRole.PlaceholderText: "#888888",
}


class LinwasApp(QApplication):
    def __init__(self, argv):
        super().__init__(argv)
        self.config = Config()
        self.setApplicationName("linwas")
        self.setApplicationDisplayName("Linwas")
        self.setOrganizationName("linwas")
        self.setStyle("Fusion")

        font = QFont("Segoe UI", 10)
        self.setFont(font)

        self._apply_theme(self.config.get("theme", "dark"))

        self.window = MainWindow(self.config)
        self.window.show()
        self.window.start_background_services()

    def _apply_theme(self, theme: str):
        palette = QPalette()
        colors = DARK if theme == "dark" else LIGHT
        for role, hex_color in colors.items():
            palette.setColor(role, QColor(hex_color))
        self.setPalette(palette)
