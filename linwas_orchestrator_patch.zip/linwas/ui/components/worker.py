from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Any

from PySide6.QtCore import QThread, Signal, QObject, QMutex


@dataclass
class ThreadRecord:
    thread: QThread
    worker: QObject


ACTIVE_THREADS: list[ThreadRecord] = []
_ACTIVE_LOCK = QMutex()


class Worker(QObject):
    finished = Signal(object)
    error = Signal(str)
    progress = Signal(int, str)

    def __init__(self, fn: Callable, *args, **kwargs):
        super().__init__()
        self._fn = fn
        self._args = args
        self._kwargs = kwargs

    def run(self):
        try:
            result = self._fn(*self._args, **self._kwargs)
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))


def _append_record(record: ThreadRecord) -> None:
    _ACTIVE_LOCK.lock()
    try:
        ACTIVE_THREADS.append(record)
    finally:
        _ACTIVE_LOCK.unlock()


def _remove_record(record: ThreadRecord) -> None:
    _ACTIVE_LOCK.lock()
    try:
        if record in ACTIVE_THREADS:
            ACTIVE_THREADS.remove(record)
    finally:
        _ACTIVE_LOCK.unlock()


def run_in_thread(fn, *args, on_done=None, on_error=None, **kwargs):
    """Run a callable in QThread and keep strong references until finished.

    This prevents the classic Qt crash:
    'QThread: Destroyed while thread is still running'.
    """
    thread = QThread()
    worker = Worker(fn, *args, **kwargs)
    record = ThreadRecord(thread=thread, worker=worker)

    worker.moveToThread(thread)
    thread.started.connect(worker.run)

    if on_done:
        worker.finished.connect(on_done)
    if on_error:
        worker.error.connect(on_error)

    worker.finished.connect(thread.quit)
    worker.error.connect(thread.quit)
    worker.finished.connect(worker.deleteLater)
    worker.error.connect(worker.deleteLater)

    def _cleanup():
        _remove_record(record)
        thread.deleteLater()

    thread.finished.connect(_cleanup)
    _append_record(record)
    thread.start()
    return record


def stop_all_threads(timeout_ms: int = 3000):
    """Ask all background threads to finish during application shutdown."""
    _ACTIVE_LOCK.lock()
    try:
        records = list(ACTIVE_THREADS)
    finally:
        _ACTIVE_LOCK.unlock()

    for record in records:
        thread = record.thread
        if thread.isRunning():
            thread.quit()
            thread.wait(timeout_ms)

    _ACTIVE_LOCK.lock()
    try:
        ACTIVE_THREADS.clear()
    finally:
        _ACTIVE_LOCK.unlock()
