from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QScrollArea, QComboBox,
)
from PySide6.QtCore import Qt, Signal, QThread, QObject

from ui.components.card import Card
from ai.ai_manager import AIManager
from ai.providers import SUPPORTED_MODELS as PROVIDER_MODELS
from ai.risk_classifier import all_low_risk
from backend.action_planner import ActionPlanner
from backend.permission_manager import ActionPlan
from backend.command_executor import CommandExecutor, ExecutionError

PAGE_QSS = """
    QScrollArea { border: none; background: transparent; }
    QWidget#pageRoot { background: transparent; }
    #chatBubbleUser {
        background: #0078d4; color: white;
        border-radius: 8px; padding: 10px 14px; font-size: 13px;
    }
    #chatBubbleAI {
        background: #282c34; color: #dcdfe4;
        border-radius: 8px; padding: 10px 14px; font-size: 13px;
        border: 1px solid #3a3f4b;
    }
    #chatInput {
        background: #282c34; color: #dcdfe4; border: 1px solid #3a3f4b;
        border-radius: 8px; padding: 10px 14px; font-size: 13px;
    }
    #chatInput:focus { border-color: #0078d4; }
    #sendBtn {
        background: #0078d4; color: white; border: none;
        border-radius: 8px; padding: 10px 20px; font-size: 13px; font-weight: 600;
    }
    #sendBtn:hover { background: #106ebe; }
    #sendBtn:disabled { background: #3a3f4b; color: #5c6370; }
    QComboBox {
        background: #282c34; color: #dcdfe4; border: 1px solid #3a3f4b;
        border-radius: 6px; padding: 6px 10px;
    }
    QLineEdit {
        background: #282c34; color: #dcdfe4; border: 1px solid #3a3f4b;
        border-radius: 6px; padding: 6px 10px;
    }
    #hintLabel { color: #5c6370; font-size: 12px; font-style: italic; }
    #noKeyLabel { color: #e5c07b; font-size: 12px; }
"""

SUGGESTIONS = [
    "Ekran parlakligini nasil ayarlaririm?",
    "Firefox nasil kurulur?",
    "Sistem neden yavasladi?",
    "Wi-Fi baglantim kesildi, neden?",
    "Windows dosyalarimi Linux'ta acabilir miyim?",
    "Ses calmiyor, ne yapmaliyim?",
]


class StreamWorker(QObject):
    chunk = Signal(str)
    finished = Signal(str)
    error = Signal(str)

    def __init__(self, manager: AIManager, message: str):
        super().__init__()
        self._manager = manager
        self._msg = message

    def run(self):
        collected = []
        try:
            for chunk in self._manager.stream_ask(self._msg):
                collected.append(chunk)
                self.chunk.emit(chunk)
            self.finished.emit("".join(collected))
        except Exception as e:
            self.error.emit(str(e))


class ExecWorker(QObject):
    finished = Signal(bool, str, str, list)  # success, stdout, stderr, cmd
    error = Signal(str, list)

    def __init__(self, executor: CommandExecutor, cmd: list, use_pkexec: bool = False):
        super().__init__()
        self._executor = executor
        self._cmd = cmd
        self._use_pkexec = use_pkexec

    def run(self):
        try:
            ok, out, err = self._executor.run(self._cmd, use_pkexec=self._use_pkexec)
            self.finished.emit(ok, out, err, self._cmd)
        except ExecutionError as e:
            self.error.emit(str(e), self._cmd)


class AIPage(QWidget):
    request_approval = Signal(object)  # ActionPlan

    def __init__(self, config, parent=None):
        super().__init__(parent)
        self._config = config
        self._manager: AIManager = AIManager(config)
        self._planner = ActionPlanner()
        self._executor = CommandExecutor()
        self._stream_thread: QThread | None = None
        self._stream_worker: StreamWorker | None = None
        self._exec_threads: list[QThread] = []
        self._pending_action: dict | None = None
        self._setup_ui()
        self.setStyleSheet(PAGE_QSS)

    def cleanup(self):
        if self._stream_thread and self._stream_thread.isRunning():
            self._stream_thread.quit()
            self._stream_thread.wait(3000)
        for t in list(self._exec_threads):
            if t.isRunning():
                t.quit()
                t.wait(2000)

    # ──────────────────────────────────────────────
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # Provider config row
        layout.addWidget(self._build_config_bar())

        # Chat area
        self._chat_area = QWidget()
        self._chat_area.setObjectName("pageRoot")
        self._chat_vbox = QVBoxLayout(self._chat_area)
        self._chat_vbox.setSpacing(10)
        self._chat_vbox.setAlignment(Qt.AlignTop)
        self._chat_vbox.addStretch()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setWidget(self._chat_area)
        layout.addWidget(scroll, 1)
        self._scroll = scroll

        # Suggestions
        layout.addWidget(self._build_suggestions())

        # Input row
        layout.addWidget(self._build_input_row())

    def _build_config_bar(self) -> QWidget:
        card = Card()
        h = QHBoxLayout()
        h.setSpacing(12)

        h.addWidget(QLabel("Saglayici:"))
        self._provider_combo = QComboBox()
        self._provider_combo.addItems(["Secin...", "gemini"])
        self._provider_combo.currentTextChanged.connect(self._on_provider_change)
        h.addWidget(self._provider_combo)

        h.addWidget(QLabel("Model:"))
        self._model_combo = QComboBox()
        self._model_combo.setMinimumWidth(180)
        h.addWidget(self._model_combo)

        h.addWidget(QLabel("API Key:"))
        self._key_input = QLineEdit()
        self._key_input.setEchoMode(QLineEdit.Password)
        self._key_input.setPlaceholderText("sk-...")
        self._key_input.setMinimumWidth(200)
        h.addWidget(self._key_input)

        save_btn = QPushButton("Kaydet")
        save_btn.clicked.connect(self._save_config)
        h.addWidget(save_btn)

        h.addStretch()
        card.add_layout(h)

        # Restore saved values
        saved_provider = self._config.get("ai_provider", "")
        if saved_provider:
            idx = self._provider_combo.findText(saved_provider)
            if idx >= 0:
                self._provider_combo.setCurrentIndex(idx)
        saved_model = self._config.get("ai_model", "")
        if saved_model and self._model_combo.count() > 0:
            idx = self._model_combo.findText(saved_model)
            if idx >= 0:
                self._model_combo.setCurrentIndex(idx)
        saved_key = self._config.get(f"{saved_provider}_api_key", "") if saved_provider else ""
        if saved_key:
            self._key_input.setText(saved_key)

        return card

    def _build_suggestions(self) -> QWidget:
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(8)
        for text in SUGGESTIONS:
            btn = QPushButton(text)
            btn.setObjectName("hintLabel")
            btn.setStyleSheet("""
                QPushButton { background:#21252b; border:1px solid #2c313a; border-radius:12px;
                              color:#9da5b4; font-size:11px; padding:4px 10px; }
                QPushButton:hover { border-color:#0078d4; color:#dcdfe4; }
            """)
            btn.clicked.connect(lambda _, t=text: self._send_message(t))
            h.addWidget(btn)
        h.addStretch()
        return w

    def _build_input_row(self) -> QWidget:
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(10)

        self._input = QLineEdit()
        self._input.setObjectName("chatInput")
        self._input.setPlaceholderText("Bir sey sorun... (orn: 'Firefox nasil kurulur?')")
        self._input.setFixedHeight(44)
        self._input.returnPressed.connect(self._on_send)
        h.addWidget(self._input, 1)

        self._send_btn = QPushButton("Gonder")
        self._send_btn.setObjectName("sendBtn")
        self._send_btn.setFixedHeight(44)
        self._send_btn.clicked.connect(self._on_send)
        h.addWidget(self._send_btn)

        clear_btn = QPushButton("Temizle")
        clear_btn.setFixedHeight(44)
        clear_btn.setStyleSheet("QPushButton{background:#3a3f4b;color:#dcdfe4;border:none;border-radius:8px;padding:10px 14px;}")
        clear_btn.clicked.connect(self._clear_chat)
        h.addWidget(clear_btn)

        return w

    # ──────────────────────────────────────────────
    def _on_provider_change(self, provider: str):
        self._model_combo.clear()
        if provider in PROVIDER_MODELS:
            self._model_combo.addItems(PROVIDER_MODELS[provider])
            saved_key = self._config.get(f"{provider}_api_key", "")
            if saved_key:
                self._key_input.setText(saved_key)

    def _save_config(self):
        provider = self._provider_combo.currentText()
        model    = self._model_combo.currentText()
        key      = self._key_input.text().strip()
        if provider in PROVIDER_MODELS:
            self._config.set("ai_provider", provider)
            self._config.set("ai_model",    model)
            self._config.set(f"{provider}_api_key", key)
            self._add_bubble("Ayarlar kaydedildi. Artik soru sorabilirsiniz.", is_user=False)

    def _on_send(self):
        text = self._input.text().strip()
        if not text:
            return
        self._input.clear()
        self._send_message(text)

    def _send_message(self, text: str):
        if self._stream_thread and self._stream_thread.isRunning():
            return

        if not self._manager.is_ready():
            self._add_bubble(text, is_user=True)
            self._add_bubble(
                "AI yapilandirmasi eksik. Lutfen saglayici, model ve API key girin, ardından 'Kaydet' tiklayin.",
                is_user=False, is_error=True
            )
            return

        self._add_bubble(text, is_user=True)
        self._send_btn.setEnabled(False)
        ai_bubble = self._add_bubble("...", is_user=False, streaming=True)

        worker = StreamWorker(self._manager, text)
        thread = QThread()
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.chunk.connect(lambda c, b=ai_bubble: self._append_chunk(b, c))
        worker.finished.connect(lambda full, b=ai_bubble: self._on_stream_done(b, full))
        worker.error.connect(lambda e, b=ai_bubble: self._on_stream_error(b, e))
        worker.finished.connect(thread.quit)
        worker.error.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        worker.error.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.start()
        self._stream_thread = thread
        self._stream_worker = worker

    def _add_bubble(self, text: str, is_user: bool, is_error: bool = False, streaming: bool = False) -> QLabel:
        bubble = QLabel(text)
        bubble.setWordWrap(True)
        bubble.setTextInteractionFlags(Qt.TextSelectableByMouse)
        bubble.setObjectName("chatBubbleUser" if is_user else "chatBubbleAI")
        if is_error:
            bubble.setStyleSheet("QLabel{background:#4a1a1a;color:#e06c75;border-radius:8px;padding:10px 14px;font-size:13px;}")

        row = QHBoxLayout()
        if is_user:
            row.addStretch()
            row.addWidget(bubble)
        else:
            row.addWidget(bubble)
            row.addStretch()

        self._chat_vbox.insertLayout(self._chat_vbox.count() - 1, row)
        self._scroll.verticalScrollBar().setValue(self._scroll.verticalScrollBar().maximum())
        return bubble

    def _append_chunk(self, bubble: QLabel, chunk: str):
        current = bubble.text()
        if current == "...":
            bubble.setText(chunk)
        else:
            bubble.setText(current + chunk)
        self._scroll.verticalScrollBar().setValue(self._scroll.verticalScrollBar().maximum())

    def _on_stream_done(self, bubble: QLabel, full: str):
        self._send_btn.setEnabled(True)
        self._stream_thread = None
        self._stream_worker = None
        explanation, ai_action = AIManager.parse_response(full)
        bubble.setText(explanation)
        if not ai_action:
            return
        plan = self._planner.from_ai_response(ai_action)
        if not plan:
            return
        # Centralized pipeline: AIPage only emits intent.
        # Orchestrator decides permission and execution.
        self._show_action_prompt(plan)

    def _auto_execute(self, plan: ActionPlan):
        self._add_bubble(
            f"Otomatik calistiriliyor: {plan.title}",
            is_user=False,
        )
        for cmd in plan.commands:
            self._run_command_async(cmd, use_pkexec=False)

    def _run_command_async(self, cmd: list, use_pkexec: bool):
        bubble = self._add_bubble(f"$ {' '.join(cmd)}\nCalisiyor...", is_user=False)
        worker = ExecWorker(self._executor, cmd, use_pkexec=use_pkexec)
        thread = QThread()
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.finished.connect(
            lambda ok, out, err, c, b=bubble: self._on_exec_done(b, c, ok, out, err)
        )
        worker.error.connect(
            lambda msg, c, b=bubble: self._on_exec_error(b, c, msg)
        )
        worker.finished.connect(thread.quit)
        worker.error.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        worker.error.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(lambda t=thread: self._exec_threads.remove(t) if t in self._exec_threads else None)
        self._exec_threads.append(thread)
        thread.start()

    def _on_exec_done(self, bubble: QLabel, cmd: list, ok: bool, stdout: str, stderr: str):
        prefix = "OK" if ok else "HATA"
        output = (stdout or stderr or "").strip()
        if len(output) > 2000:
            output = output[:2000] + "\n... (kisaltildi)"
        bubble.setText(f"$ {' '.join(cmd)}\n[{prefix}]\n{output}")
        if not ok:
            bubble.setStyleSheet(
                "QLabel{background:#4a1a1a;color:#e06c75;border-radius:8px;padding:10px 14px;font-size:13px;}"
            )

    def _on_exec_error(self, bubble: QLabel, cmd: list, msg: str):
        bubble.setText(f"$ {' '.join(cmd)}\n[HATA] {msg}")
        bubble.setStyleSheet(
            "QLabel{background:#4a1a1a;color:#e06c75;border-radius:8px;padding:10px 14px;font-size:13px;}"
        )

    def _on_stream_error(self, bubble: QLabel, error: str):
        bubble.setText(f"Hata: {error}")
        bubble.setStyleSheet("QLabel{background:#4a1a1a;color:#e06c75;border-radius:8px;padding:10px 14px;font-size:13px;}")
        self._send_btn.setEnabled(True)
        self._stream_thread = None
        self._stream_worker = None

    def _show_action_prompt(self, plan: ActionPlan):
        self.request_approval.emit(plan)

    def append_system_message(self, message: str):
        self._add_bubble(message, is_user=False)

    def _clear_chat(self):
        for i in reversed(range(self._chat_vbox.count())):
            item = self._chat_vbox.itemAt(i)
            if item.layout():
                for j in reversed(range(item.layout().count())):
                    w = item.layout().itemAt(j).widget()
                    if w:
                        w.deleteLater()
                self._chat_vbox.removeItem(item)
        self._manager.reset()
