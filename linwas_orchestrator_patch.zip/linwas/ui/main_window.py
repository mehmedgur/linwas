from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QStackedWidget, QLabel, QFrame,
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

from ui.components.sidebar import Sidebar
from ui.pages.home_page import HomePage
from ui.pages.ai_page import AIPage
from ui.pages.system_page import SystemPage
from ui.pages.programs_page import ProgramsPage
from ui.pages.wine_page import WinePage
from ui.pages.documents_page import DocumentsPage
from ui.pages.troubleshoot_page import TroubleshootPage
from ui.pages.security_page import SecurityPage
from ui.pages.settings_page import SettingsPage
from core.orchestrator import Orchestrator

PAGES = [
    ("Ana Sayfa",     "home",        HomePage),
    ("AI Asistan",    "ai",          AIPage),
    ("Sistem",        "system",      SystemPage),
    ("Programlar",    "programs",    ProgramsPage),
    ("Wine / EXE",    "wine",        WinePage),
    ("Belgeler",      "documents",   DocumentsPage),
    ("Sorun Giderme", "troubleshoot",TroubleshootPage),
    ("Guvenlik",      "security",    SecurityPage),
    ("Ayarlar",       "settings",    SettingsPage),
]

WINDOW_QSS = """
    QMainWindow { background: #1e2127; }
    #content    { background: #1e2127; }
    #titleBar   { background: #21252b; border-bottom: 1px solid #181a1f; }
    #pageTitle  { color: #dcdfe4; font-size: 15px; font-weight: 600; }
"""


class MainWindow(QMainWindow):
    def __init__(self, config):
        super().__init__()
        self._config = config
        self.setWindowTitle("Linwas — Linux Yardim Merkezi")
        self.setMinimumSize(900, 580)
        self.resize(config.get("window_width", 1100), config.get("window_height", 720))
        self._build()
        self.setStyleSheet(WINDOW_QSS)

    def _build(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Sidebar
        self._sidebar = Sidebar(PAGES)
        self._sidebar.page_changed.connect(self._on_page)
        layout.addWidget(self._sidebar)

        # Right side
        right = QWidget()
        right.setObjectName("content")
        rv = QVBoxLayout(right)
        rv.setContentsMargins(0, 0, 0, 0)
        rv.setSpacing(0)

        # Title bar
        self._title_bar = self._make_title_bar()
        rv.addWidget(self._title_bar)

        # Page stack
        self._stack = QStackedWidget()
        self._page_map: dict[str, QWidget] = {}

        for name, key, PageClass in PAGES:
            page = PageClass(self._config)
            self._page_map[key] = page
            self._stack.addWidget(page)

        # Wire home → navigate
        home: HomePage = self._page_map["home"]
        home.navigate = self._navigate_to_key

        # Central orchestration: page signals -> permission -> executor -> state
        self.orchestrator = Orchestrator(self, self._page_map, self._config)
        self.orchestrator.status_changed.connect(self._on_status_changed)

        rv.addWidget(self._stack)
        layout.addWidget(right, 1)

    def _make_title_bar(self) -> QWidget:
        bar = QWidget()
        bar.setObjectName("titleBar")
        bar.setFixedHeight(52)
        h = QHBoxLayout(bar)
        h.setContentsMargins(24, 0, 24, 0)

        self._page_title = QLabel("Ana Sayfa")
        self._page_title.setObjectName("pageTitle")
        font = self._page_title.font()
        font.setWeight(QFont.Weight.Medium)
        self._page_title.setFont(font)
        h.addWidget(self._page_title)
        h.addStretch()
        return bar

    def _on_page(self, index: int, name: str, key: str):
        self._stack.setCurrentIndex(index)
        self._page_title.setText(name)

    def _navigate_to_key(self, key: str):
        self._sidebar.select_key(key)

    def start_background_services(self):
        if hasattr(self, "orchestrator"):
            self.orchestrator.start()

    def _on_status_changed(self, message: str):
        if message and message != "Hazır":
            self.statusBar().showMessage(message)
        else:
            self.statusBar().clearMessage()

    def _show_approval(self, plan):
        # Backward-compatible path; new code uses Orchestrator directly.
        if hasattr(self, "orchestrator"):
            self.orchestrator.handle_action_plan(plan)

    def closeEvent(self, event):
        self._config.set("window_width",  self.width())
        self._config.set("window_height", self.height())

        if hasattr(self, "orchestrator"):
            try:
                self.orchestrator.shutdown()
            except Exception:
                pass

        for page in self._page_map.values():
            if hasattr(page, "cleanup"):
                try:
                    page.cleanup()
                except Exception:
                    pass

        from ui.components.worker import stop_all_threads
        stop_all_threads(timeout_ms=3000)

        super().closeEvent(event)
