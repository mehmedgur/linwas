"""Central in-memory state/cache for linwas runtime data."""
from __future__ import annotations

from PySide6.QtCore import QObject, Signal
from threading import RLock
from typing import Any


class AppState(QObject):
    """Small observable cache shared by the UI and orchestrator."""

    changed = Signal(str, object)  # key, value

    def __init__(self):
        super().__init__()
        self._lock = RLock()
        self._data: dict[str, Any] = {}

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            self._data[key] = value
        self.changed.emit(key, value)

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._data.get(key, default)

    def has(self, key: str) -> bool:
        with self._lock:
            return key in self._data

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return dict(self._data)
