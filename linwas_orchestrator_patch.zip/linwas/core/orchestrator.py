"""Application orchestration layer.

The orchestrator connects UI signals to backend services. Pages should render
and emit intent; command execution, permission prompts, preloaded data and
cross-page routing are handled here.
"""
from __future__ import annotations

from typing import Any

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QMessageBox

from backend.command_executor import CommandExecutor, ExecutionError
from backend.permission_manager import PermissionManager, ActionPlan
from backend.preloader import DataPreloader
from core.app_state import AppState
from ui.components.worker import run_in_thread
from ui.dialogs.approval_dialog import ApprovalDialog


class Orchestrator(QObject):
    status_changed = Signal(str)

    def __init__(self, main_window, pages: dict[str, Any], config):
        super().__init__(main_window)
        self.window = main_window
        self.pages = pages
        self.config = config
        self.state = AppState()
        self.executor = CommandExecutor()
        self.permission_manager = PermissionManager()
        self.preloader = DataPreloader.instance()

        self.permission_manager.approval_callback = self.ask_approval
        self._wire_pages()
        self._wire_preloader()

    def start(self) -> None:
        """Start lightweight background data collection."""
        self.preloader.start()

    def shutdown(self) -> None:
        """Detach preloader callbacks and let page cleanup happen in MainWindow."""
        try:
            self.preloader.data_ready.disconnect(self._on_preloaded_data)
        except (TypeError, RuntimeError):
            pass

    # ------------------------------------------------------------------
    # Wiring
    # ------------------------------------------------------------------
    def _wire_pages(self) -> None:
        ai_page = self.pages.get("ai")
        if ai_page is not None and hasattr(ai_page, "request_approval"):
            try:
                ai_page.request_approval.disconnect()
            except (TypeError, RuntimeError):
                pass
            ai_page.request_approval.connect(self.handle_action_plan)

        # Optional integration point for pages that want app-state updates.
        for page in self.pages.values():
            if hasattr(page, "set_orchestrator"):
                try:
                    page.set_orchestrator(self)
                except Exception:
                    pass

    def _wire_preloader(self) -> None:
        try:
            self.preloader.data_ready.disconnect(self._on_preloaded_data)
        except (TypeError, RuntimeError):
            pass
        self.preloader.data_ready.connect(self._on_preloaded_data)

    # ------------------------------------------------------------------
    # Data distribution
    # ------------------------------------------------------------------
    def _on_preloaded_data(self, key: str, data: object) -> None:
        self.state.set(key, data)
        for page in self.pages.values():
            if hasattr(page, "on_preloaded_data"):
                try:
                    page.on_preloaded_data(key, data)
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # Permission and command execution
    # ------------------------------------------------------------------
    def ask_approval(self, plan: ActionPlan) -> bool:
        dlg = ApprovalDialog(plan, self.window)
        return dlg.exec() == dlg.DialogCode.Accepted

    def handle_action_plan(self, plan: ActionPlan) -> None:
        """Central AI/planner -> permission -> executor pipeline."""
        if plan is None:
            return
        if not self.permission_manager.request_approval(plan):
            self._notify_page("ai", "İşlem iptal edildi.")
            return
        self.execute_plan(plan)

    def execute_plan(self, plan: ActionPlan) -> None:
        self.status_changed.emit(f"Çalıştırılıyor: {plan.title}")

        def do_execute():
            results = []
            for cmd in plan.commands:
                ok, out, err = self.executor.run(
                    cmd,
                    use_pkexec=plan.requires_sudo,
                    timeout=180,
                )
                results.append({"cmd": cmd, "ok": ok, "stdout": out, "stderr": err})
            return results

        def on_done(results):
            success = all(item.get("ok") for item in results)
            self.status_changed.emit("Hazır")
            self._notify_page("ai", self._format_execution_result(results))
            title = "İşlem tamamlandı" if success else "İşlem tamamlandı ama hata var"
            QMessageBox.information(self.window, title, self._brief_result(results))

        def on_error(message: str):
            self.status_changed.emit("Hazır")
            self._notify_page("ai", f"[HATA] {message}")
            QMessageBox.warning(self.window, "İşlem başarısız", message)

        run_in_thread(do_execute, on_done=on_done, on_error=on_error)

    def run_command(self, cmd: list[str], *, use_pkexec: bool = False, timeout: int = 120):
        """Low-level central command API for future page refactors."""
        try:
            return self.executor.run(cmd, use_pkexec=use_pkexec, timeout=timeout)
        except ExecutionError as exc:
            return False, "", str(exc)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _notify_page(self, key: str, message: str) -> None:
        page = self.pages.get(key)
        if page is not None and hasattr(page, "append_system_message"):
            try:
                page.append_system_message(message)
            except Exception:
                pass

    @staticmethod
    def _format_execution_result(results: list[dict]) -> str:
        lines = []
        for item in results:
            cmd = " ".join(item.get("cmd", []))
            status = "OK" if item.get("ok") else "HATA"
            output = (item.get("stdout") or item.get("stderr") or "").strip()
            if len(output) > 1600:
                output = output[:1600] + "\n... (kısaltıldı)"
            lines.append(f"$ {cmd}\n[{status}]\n{output}".rstrip())
        return "\n\n".join(lines)

    @staticmethod
    def _brief_result(results: list[dict]) -> str:
        failed = [r for r in results if not r.get("ok")]
        if not failed:
            return "Tüm komutlar başarıyla tamamlandı."
        return f"{len(failed)} komut başarısız oldu. Ayrıntılar AI sayfasına yazıldı."
