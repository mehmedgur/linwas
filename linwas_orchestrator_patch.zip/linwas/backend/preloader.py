from __future__ import annotations

import shutil
import threading
from PySide6.QtCore import QObject, Signal
from ui.components.worker import run_in_thread


class DataPreloader(QObject):
    """Lightweight startup data cache.

    Heavy checks should not run at startup. Pages may request full scans later.
    """

    data_ready = Signal(str, object)  # (key, data)

    _instance = None
    _instance_lock = threading.Lock()

    @classmethod
    def instance(cls) -> "DataPreloader":
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls()
        return cls._instance

    def __init__(self):
        super().__init__()
        self._cache: dict = {}
        self._cache_lock = threading.Lock()
        self._started = False

    def start(self):
        """Kick off background collection. Safe to call more than once."""
        with self._cache_lock:
            if self._started:
                return
            self._started = True

        from backend.system import SystemInfo
        from services.network_service import NetworkService
        from backend.troubleshoot import TroubleshootBackend

        si = SystemInfo()
        net = NetworkService()
        ts = TroubleshootBackend()

        run_in_thread(si.get_all, on_done=lambda d: self._store("system", d))
        run_in_thread(net.get_ip_info, on_done=lambda d: self._store("network", d))
        run_in_thread(lambda: self._quick_troubleshoot(ts), on_done=lambda d: self._store("troubleshoot", d))
        run_in_thread(self._capabilities, on_done=lambda d: self._store("capabilities", d))

    def _quick_troubleshoot(self, ts: "TroubleshootBackend") -> dict:
        """Only fast checks for startup. Full scan remains user-triggered."""
        return {
            "internet": ts.check_internet(),
            "disk": ts.check_disk_space(),
            "audio": ts.check_audio(),
            "bluetooth": ts.check_bluetooth(),
            "updates": {"status": "neutral", "message": "Tam kontrol için tarama başlatın", "count": -1},
            "services": [],
        }

    def _capabilities(self) -> dict:
        return {
            "apt": bool(shutil.which("apt") or shutil.which("apt-get")),
            "flatpak": bool(shutil.which("flatpak")),
            "wine": bool(shutil.which("wine")),
            "libreoffice": bool(shutil.which("libreoffice") or shutil.which("soffice")),
            "ufw": bool(shutil.which("ufw")),
            "nmcli": bool(shutil.which("nmcli")),
            "bluetoothctl": bool(shutil.which("bluetoothctl")),
        }

    def _store(self, key: str, data):
        with self._cache_lock:
            self._cache[key] = data
        self.data_ready.emit(key, data)

    def get(self, key, default=None):
        with self._cache_lock:
            return self._cache.get(key, default)

    def has(self, key) -> bool:
        with self._cache_lock:
            return key in self._cache

    def snapshot(self) -> dict:
        with self._cache_lock:
            return dict(self._cache)
