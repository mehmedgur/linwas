"""
Whitelist-based command executor.
AI and UI layers call this — never subprocess directly with arbitrary input.
"""
import subprocess
import shlex
import os
from typing import Optional

# Each entry: (prefix_tokens, allow_sudo)
WHITELIST: list[tuple[list[str], bool]] = [
    (["apt-get", "install"],          True),
    (["apt-get", "remove"],           True),
    (["apt-get", "purge"],            True),
    (["apt-get", "update"],           True),
    (["apt-get", "upgrade"],          True),
    (["apt-get", "autoremove"],       True),
    (["apt", "install"],              True),
    (["apt", "remove"],               True),
    (["apt", "purge"],                True),
    (["apt", "update"],               True),
    (["apt", "upgrade"],              True),
    (["apt", "list"],                 False),
    (["flatpak", "install"],          False),
    (["flatpak", "remove"],           False),
    (["flatpak", "update"],           False),
    (["flatpak", "list"],             False),
    (["flatpak", "search"],           False),
    (["dpkg", "-i"],                  True),
    (["dpkg", "--install"],           True),
    (["dpkg", "-l"],                  False),
    (["systemctl", "start"],          True),
    (["systemctl", "stop"],           True),
    (["systemctl", "restart"],        True),
    (["systemctl", "status"],         False),
    (["systemctl", "enable"],         True),
    (["systemctl", "disable"],        True),
    (["nmcli"],                       False),
    (["bluetoothctl"],                False),
    (["ufw", "status"],               False),
    (["ufw", "enable"],               True),
    (["ufw", "disable"],              True),
    (["ufw", "allow"],                True),
    (["ufw", "deny"],                 True),
    (["libreoffice", "--headless"],   False),
    (["soffice", "--headless"],       False),
    (["wine"],                        False),
    (["winetricks"],                  False),
    (["lsblk"],                       False),
    (["lspci"],                       False),
    (["lsusb"],                       False),
    (["df"],                          False),
    (["free"],                        False),
    (["journalctl"],                  False),
    (["ip"],                          False),
    (["pactl"],                       False),
    (["apt-cache"],                   False),
    (["ping", "-c"],                  False),
    (["fc-list"],                     False),
    (["fc-cache"],                    False),
    (["update-fc-cache"],             False),
    (["xdg-open"],                    False),
]

BLOCKED_PATTERNS = [
    "rm -rf", "mkfs", "dd if=", "fdisk", "parted",
    "> /dev", "| bash", "| sh", "curl.*|", "wget.*|",
    "chmod 777 /", "chown root /",
]


class ExecutionError(Exception):
    pass


class CommandExecutor:
    def is_allowed(self, cmd: list[str]) -> bool:
        if not cmd:
            return False
        cmd_str = shlex.join(cmd).lower()
        for pattern in BLOCKED_PATTERNS:
            if pattern in cmd_str:
                return False
        for prefix, _ in WHITELIST:
            if cmd[:len(prefix)] == prefix:
                return True
        return False

    def run(
        self,
        cmd: list[str],
        use_pkexec: bool = False,
        timeout: int = 60,
        cwd: Optional[str] = None,
    ) -> tuple[bool, str, str]:
        if not self.is_allowed(cmd):
            raise ExecutionError(f"Komut beyaz listede değil: {shlex.join(cmd)}")

        full_cmd = (["pkexec"] + cmd) if use_pkexec else cmd

        try:
            r = subprocess.run(
                full_cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=cwd,
                env={**os.environ, "DEBIAN_FRONTEND": "noninteractive"},
            )
            return r.returncode == 0, r.stdout, r.stderr
        except subprocess.TimeoutExpired:
            raise ExecutionError(f"Komut zaman aşımına uğradı ({timeout}s)")
        except FileNotFoundError:
            raise ExecutionError(f"Komut bulunamadı: {cmd[0]}")

    def run_stream(self, cmd: list[str], use_pkexec: bool = False, timeout: int = 120):
        if not self.is_allowed(cmd):
            raise ExecutionError(f"Komut beyaz listede değil: {shlex.join(cmd)}")
        full_cmd = (["pkexec"] + cmd) if use_pkexec else cmd
        with subprocess.Popen(
            full_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            env={**os.environ, "DEBIAN_FRONTEND": "noninteractive"},
        ) as proc:
            for line in proc.stdout:
                yield line.rstrip()
