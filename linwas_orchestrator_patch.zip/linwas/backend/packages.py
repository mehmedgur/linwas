import subprocess
import os
import re


class PackageManager:
    def apt_search(self, query: str, limit: int = 30) -> list[dict]:
        try:
            r = subprocess.run(
                ["apt-cache", "search", query],
                capture_output=True, text=True, timeout=10
            )
            results = []
            for line in r.stdout.splitlines()[:limit]:
                if " - " in line:
                    name, desc = line.split(" - ", 1)
                    results.append({"name": name.strip(), "description": desc.strip(), "manager": "apt"})
            return results
        except Exception:
            return []

    def apt_list_installed(self) -> list[dict]:
        try:
            r = subprocess.run(
                ["dpkg", "-l"],
                capture_output=True, text=True, timeout=15
            )
            results = []
            for line in r.stdout.splitlines():
                if line.startswith("ii"):
                    parts = line.split()
                    if len(parts) >= 3:
                        results.append({
                            "name":    parts[1],
                            "version": parts[2],
                            "manager": "apt",
                        })
            return results
        except Exception:
            return []

    def apt_show(self, package: str) -> dict:
        try:
            r = subprocess.run(
                ["apt-cache", "show", package],
                capture_output=True, text=True, timeout=8
            )
            info = {}
            for line in r.stdout.splitlines():
                if ":" in line:
                    k, _, v = line.partition(":")
                    info[k.strip()] = v.strip()
            return info
        except Exception:
            return {}

    def apt_upgradable(self) -> list[dict]:
        try:
            r = subprocess.run(
                ["apt", "list", "--upgradable"],
                capture_output=True, text=True, timeout=15,
                env={**os.environ, "LANG": "C"}
            )
            results = []
            for line in r.stdout.splitlines():
                if "/" in line:
                    name = line.split("/")[0]
                    results.append({"name": name, "manager": "apt"})
            return results
        except Exception:
            return []

    def flatpak_list(self) -> list[dict]:
        try:
            r = subprocess.run(
                ["flatpak", "list", "--columns=application,name,version"],
                capture_output=True, text=True, timeout=10
            )
            results = []
            for line in r.stdout.splitlines():
                parts = line.split("\t")
                if len(parts) >= 2:
                    results.append({
                        "id":      parts[0],
                        "name":    parts[1] if len(parts) > 1 else parts[0],
                        "version": parts[2] if len(parts) > 2 else "",
                        "manager": "flatpak",
                    })
            return results
        except Exception:
            return []

    def flatpak_search(self, query: str, limit: int = 20) -> list[dict]:
        try:
            r = subprocess.run(
                ["flatpak", "search", "--columns=application,name,description", query],
                capture_output=True, text=True, timeout=15
            )
            results = []
            for line in r.stdout.splitlines()[:limit]:
                parts = line.split("\t")
                if len(parts) >= 2:
                    results.append({
                        "id":          parts[0],
                        "name":        parts[1] if len(parts) > 1 else parts[0],
                        "description": parts[2] if len(parts) > 2 else "",
                        "manager":     "flatpak",
                    })
            return results
        except Exception:
            return []

    def is_flatpak_available(self) -> bool:
        try:
            subprocess.run(["flatpak", "--version"], capture_output=True, timeout=3)
            return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def is_package_installed(self, name: str) -> bool:
        try:
            r = subprocess.run(
                ["dpkg", "-s", name],
                capture_output=True, text=True, timeout=5
            )
            return "Status: install ok installed" in r.stdout
        except Exception:
            return False
