from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QTextEdit, QLineEdit, QPushButton, QLabel

class ChatPage(QWidget):
    def __init__(self, ai_engine):
        super().__init__()
        self.ai = ai_engine
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        
        self.title = QLabel("Gemini Yapay Zeka Asistanı")
        self.title.setStyleSheet("font-size: 16px; font-weight: bold; padding: 5px;")
        layout.addWidget(self.title)

        self.chat_area = QTextEdit()
        self.chat_area.setReadOnly(True)
        layout.addWidget(self.chat_area)

        input_layout = QHBoxLayout()
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Linux hakkında bir soru sorun...")
        self.input_field.returnPressed.connect(self.send_message)
        
        self.send_btn = QPushButton("Gönder")
        self.send_btn.clicked.connect(self.send_message)
        
        input_layout.addWidget(self.input_field)
        input_layout.addWidget(self.send_btn)
        layout.addLayout(input_layout)

    def send_message(self):
        text = self.input_field.text().strip()
        if not text:
            return

        self.chat_area.append(f"<b>Kullanıcı:</b> {text}\n")
        self.input_field.clear()
        self.send_btn.setEnabled(False)
        
        response = self.ai.ask(text)
        
        self.chat_area.append(f"<b>Gemini:</b> {response}\n")
        self.chat_area.append("-" * 40 + "\n")
        self.send_btn.setEnabled(True)
