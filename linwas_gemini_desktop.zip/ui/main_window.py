from PySide6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QListWidget, QStackedWidget, QLabel
from ui.chat_page import ChatPage

class MainWindow(QMainWindow):
    def __init__(self, app_instance):
        super().__init__()
        self.app = app_instance
        self.setWindowTitle("Linwas — Linux Yardım Merkezi")
        self.resize(self.app.config.get("window_width"), self.app.config.get("window_height"))
        self.init_ui()

    def init_ui(self):
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        
        layout = QHBoxLayout(main_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.sidebar = QListWidget()
        self.sidebar.setFixedWidth(200)
        self.sidebar.addItems(["Ana Sayfa", "Gemini Asistan", "Sistem", "Ayarlar"])
        self.sidebar.currentRowChanged.connect(self.display_page)
        layout.addWidget(self.sidebar)

        self.pages = QStackedWidget()
        layout.addWidget(self.pages)

        self.page_home = QLabel("Linwas Projesine Hoş Geldiniz.\n\nGemini tabanlı Linux masaüstü uygulaması.")
        self.page_home.setStyleSheet("font-size: 14px; padding: 20px;")
        
        self.page_chat = ChatPage(self.app.ai_engine)
        self.page_system = QLabel("Sistem Modülü (CPU/RAM/Donanım Metrikleri)")
        self.page_system.setStyleSheet("padding: 20px;")
        self.page_settings = QLabel("Ayarlar Modülü (API Key Yönetimi)")
        self.page_settings.setStyleSheet("padding: 20px;")

        self.pages.addWidget(self.page_home)
        self.pages.addWidget(self.page_chat)
        self.pages.addWidget(self.page_system)
        self.pages.addWidget(self.page_settings)

    def display_page(self, index):
        self.pages.setCurrentIndex(index)
