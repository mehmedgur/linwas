import sys
from app import LinwasApp
from ui.main_window import MainWindow

if __name__ == "__main__":
    app = LinwasApp(sys.argv)
    window = MainWindow(app)
    window.show()
    sys.exit(app.exec())
