import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QPalette, QColor, QFont
from config import Config
from ai_core import GeminiEngine

DARK_PALETTE = {
    QPalette.ColorRole.Window: "#1e2127",
    QPalette.ColorRole.WindowText: "#dcdfe4",
    QPalette.ColorRole.Base: "#282c34",
    QPalette.ColorRole.AlternateBase: "#21252b",
    QPalette.ColorRole.Text: "#dcdfe4",
    QPalette.ColorRole.Button: "#282c34",
    QPalette.ColorRole.ButtonText: "#dcdfe4",
    QPalette.ColorRole.Highlight: "#0078d4",
    QPalette.ColorRole.HighlightedText: "#ffffff",
}

class LinwasApp(QApplication):
    def __init__(self, argv):
        super().__init__(argv)
        self.config = Config()
        self.ai_engine = GeminiEngine(self.config)
        
        self.setApplicationName("linwas")
        self.setApplicationDisplayName("Linwas")
        self.setStyle("Fusion")
        self.setFont(QFont("Segoe UI", 10))
        self.apply_theme()

    def apply_theme(self):
        palette = QPalette()
        for role, color_hex in DARK_PALETTE.items():
            palette.setColor(role, QColor(color_hex))
        self.setPalette(palette)
