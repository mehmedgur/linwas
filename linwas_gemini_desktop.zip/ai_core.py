import importlib

SUPPORTED_GEMINI_MODELS = [
    "gemini-3.1-pro-preview",
    "gemini-3.5-flash",
    "gemini-3.1-flash-lite"
]

class GeminiEngine:
    def __init__(self, config_instance):
        self.config = config_instance

    def _get_client(self):
        api_key = self.config.get("gemini_api_key", "")
        if not api_key:
            raise ValueError("Google AI Studio API anahtarı Ayarlar'da tanımlanmamış.")
        
        genai = importlib.import_module("google.generativeai")
        genai.configure(api_key=api_key)
        return genai

    def validate_key(self, api_key: str) -> bool:
        try:
            genai = importlib.import_module("google.generativeai")
            genai.configure(api_key=api_key)
            model = genai.GenerativeModel("gemini-3.1-flash-lite")
            model.generate_content("ping", generation_config={"max_output_tokens": 5})
            return True
        except Exception:
            return False

    def ask(self, prompt: str) -> str:
        try:
            genai = self._get_client()
            model_name = self.config.get("ai_model", "gemini-3.5-flash")
            
            system_instruction = (
                "Sen Linwas projesinin özel yapay zeka asistanısın. "
                "Linux dünyasına yeni geçen kullanıcılara rehberlik ediyorsun. "
                "Verdiğin yanıtlar kısa, hiyerarşik yapıda ve net olmalıdır. "
                "Doğrudan tehlikeli komutlar önerme, güvenliği ön planda tut."
            )
            
            model = genai.GenerativeModel(
                model_name=model_name,
                system_instruction=system_instruction
            )
            
            response = model.generate_content(prompt)
            return response.text
        except Exception as e:
            return f"Gemini API Hatası: {str(e)}"
